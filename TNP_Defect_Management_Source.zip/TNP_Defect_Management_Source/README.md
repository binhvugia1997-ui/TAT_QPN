# TNP Defect Management System — source tách file

Được tách trực tiếp từ file `Theo dõi TAT hệ thống TNP.html`, không thay đổi logic nghiệp vụ.

## Cấu trúc

- `index.html` — cấu trúc giao diện HTML
- `css/app.css` — toàn bộ CSS của ứng dụng
- `js/app.js` — JavaScript nghiệp vụ/UI/data của ứng dụng
- `js/vendor/xlsx.full.min.js` — SheetJS được nhúng trong file gốc, dùng đọc Excel/CSV offline

## Chạy development

Mở `index.html` trực tiếp hoặc chạy bằng local HTTP server. Chưa có installer/portable/EXE.

## Lưu ý

Đây là bước tách source vật lý, chưa refactor `app.js` thành các module business/database/UI để tránh làm thay đổi hành vi của bản gốc. Bước tiếp theo có thể tách `app.js` theo kiến trúc module sau khi kiểm tra bản tách này chạy tương đương file gốc.
