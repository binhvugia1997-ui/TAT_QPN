const BASE_DATA = [
{
"id": 1,
"no": "31",
"mgmtNo": "260702006-VOC",
"registeredDate": "2026-07-02",
"writtenBy": "gupta.n",
"status": "Đợi đối sách",
"plant": "SIEL",
"title": "SM-A276B I/Molding Rear Antenna lift up - Left A276_Rear_Antenna_uplifted_GH98-51112A_NR_n78_RX_Fail",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112A",
"partName": "ASSY CASE-REAR;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Bong antenna bên trái",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "gupta.n",
"approver": "ajay.patyal",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "IPC",
"locatedCorp": "SEV"
},
{
"id": 2,
"no": "32",
"mgmtNo": "260702005-VOC",
"registeredDate": "2026-07-02",
"writtenBy": "gupta.n",
"status": "Đợi đối sách",
"plant": "SIEL",
"title": "BSM-A276B I/Molding Front Hole Block A276_Screw_hole_block_GH98-51170A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51170A",
"partName": "ASSY CASE-FRONT_V3;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-A27-5g ALL NRM",
"model": "BSM-A276B/1R6D",
"defectDetails": "Hole Block",
"sampleQty": null,
"defectQty": 2,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "gupta.n",
"approver": "ajay.patyal",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "IPC",
"locatedCorp": "SEV"
},
{
"id": 3,
"no": "27",
"mgmtNo": "260703199",
"registeredDate": "2026-07-03",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 4,
"no": "28",
"mgmtNo": "260703100",
"registeredDate": "2026-07-03",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Không có marking kiểm soát",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Không có marking kiểm soát",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 5,
"no": "29",
"mgmtNo": "260703084-VOC",
"registeredDate": "2026-07-03",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A175F I/Molding Rear Sứt mẻ Kiểm tra đầu chuyền _ GH98-50512C _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50512C",
"partName": "ASSY CASE-REAR_LB;SM-A175F,OPEN,LIGHT BL",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17",
"model": "SM-A175F_EUR_XX",
"defectDetails": "Sứt mẻ",
"sampleQty": null,
"defectQty": 33,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 6,
"no": "30",
"mgmtNo": "260703039",
"registeredDate": "2026-07-03",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lỗi sơn bond",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lỗi sơn bond",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 7,
"no": "26",
"mgmtNo": "260704064",
"registeredDate": "2026-07-04",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837B",
"partName": "ASSY CASE-REAR_ZA;SM-A165F,OPEN,GRAY",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-11",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 8,
"no": "21",
"mgmtNo": "260706112-VOC",
"registeredDate": "2026-07-06",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 46,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-13",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 9,
"no": "22",
"mgmtNo": "260706110-VOC",
"registeredDate": "2026-07-06",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 37,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-13",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 10,
"no": "23",
"mgmtNo": "260706108-VOC",
"registeredDate": "2026-07-06",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 66,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-13",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 11,
"no": "24",
"mgmtNo": "260706073-VOC",
"registeredDate": "2026-07-06",
"writtenBy": "the.thuy",
"status": "Đợi đối sách",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Hằn Main _ 20260620_003 _ Hằn rear dị vật sơn _ GH98-51112B",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112B",
"partName": "ASSY CASE-REAR_ZB;SM-A276B,OPEN,BLUE",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Hằn",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-13",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 12,
"no": "25",
"mgmtNo": "260706017",
"registeredDate": "2026-07-06",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Lỗi lồi",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi lồi",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-13",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 13,
"no": "17",
"mgmtNo": "260707265",
"registeredDate": "2026-07-07",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Mụn Sơn",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837B",
"partName": "ASSY CASE-REAR_ZA;SM-A165F,OPEN,GRAY",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Mụn Sơn",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 14,
"no": "18",
"mgmtNo": "260707245",
"registeredDate": "2026-07-07",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Dị vật sơn",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Dị vật sơn",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 15,
"no": "19",
"mgmtNo": "260707213",
"registeredDate": "2026-07-07",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Lõm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lõm",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 16,
"no": "20",
"mgmtNo": "260707117",
"registeredDate": "2026-07-07",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Chấm mụn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Chấm mụn",
"sampleQty": 250,
"defectQty": 2,
"defectRate": 0.8,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 17,
"no": "8",
"mgmtNo": "260708181",
"registeredDate": "2026-07-08",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Difference Color Limit",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Difference Color Limit",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 18,
"no": "9",
"mgmtNo": "260708145-VOC",
"registeredDate": "2026-07-08",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837A",
"partName": "ASSY CASE-REAR_ZK;SM-A165F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 52,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 19,
"no": "10",
"mgmtNo": "260708131-VOC",
"registeredDate": "2026-07-08",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Sứt mẻ Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Sứt mẻ",
"sampleQty": null,
"defectQty": 7,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 20,
"no": "11",
"mgmtNo": "260708061-VOC",
"registeredDate": "2026-07-08",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 9,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 21,
"no": "12",
"mgmtNo": "260708060-VOC",
"registeredDate": "2026-07-08",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 38,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 22,
"no": "13",
"mgmtNo": "260708058-VOC",
"registeredDate": "2026-07-08",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A175F I/Molding Rear Vết đâm Kiểm tra đầu chuyền _ GH98-50512C _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50512C",
"partName": "ASSY CASE-REAR_LB;SM-A175F,OPEN,LIGHT BL",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17",
"model": "SM-A175F_EUR_XX",
"defectDetails": "Vết đâm",
"sampleQty": null,
"defectQty": 25,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 23,
"no": "14",
"mgmtNo": "260708053-VOC",
"registeredDate": "2026-07-08",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 57,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 24,
"no": "15",
"mgmtNo": "260708027",
"registeredDate": "2026-07-08",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lõm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lõm",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 25,
"no": "16",
"mgmtNo": "260708023",
"registeredDate": "2026-07-08",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Difference Color Limit",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Difference Color Limit",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-15",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 26,
"no": "1",
"mgmtNo": "260709043-VOC",
"registeredDate": "2026-07-09",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Kẹt tape Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Kẹt tape",
"sampleQty": null,
"defectQty": 8,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 27,
"no": "2",
"mgmtNo": "260709042-VOC",
"registeredDate": "2026-07-09",
"writtenBy": "ngoc.pt2",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A165F I/Molding Front Thiếu tape Kiểm tra đầu chuyền _ GH98-49834A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49834A",
"partName": "ASSY CASE-FRONT;SM-A165F,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Thiếu tape",
"sampleQty": null,
"defectQty": 12,
"defectRate": null,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 28,
"no": "3",
"mgmtNo": "260709034",
"registeredDate": "2026-07-09",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Sứt mẻ",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958C",
"partName": "ASSY CASE-FRONT_A253D_ZB;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Sứt mẻ",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 29,
"no": "4",
"mgmtNo": "260709027",
"registeredDate": "2026-07-09",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Biến dạng",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Biến dạng",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 30,
"no": "5",
"mgmtNo": "260709021",
"registeredDate": "2026-07-09",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Dị vật sơn",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Dị vật sơn",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 31,
"no": "6",
"mgmtNo": "260709018",
"registeredDate": "2026-07-09",
"writtenBy": "tue.ptm",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-F976U Deco Front Lõm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lõm",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": null,
"reason2": null,
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 32,
"no": "7",
"mgmtNo": "260709006",
"registeredDate": "2026-07-09",
"writtenBy": "vu.hoai",
"status": "Đợi đối sách",
"plant": "SEV",
"title": "SM-A175N I/Molding Rear Loang SM-A175-Rear- Lỗi sơn ,hằn ,loang ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50512A",
"partName": "ASSY CASE-REAR;SM-A175F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17",
"model": "SM-A175N_KOR_KX",
"defectDetails": "Loang",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": null,
"reason2": null,
"inspector": "tien.trung",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-16",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 33,
"no": "33",
"mgmtNo": "260703008",
"registeredDate": "2026-07-03",
"writtenBy": "pham.thao",
"status": "Đợi xét",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Lệch Tape GH98-51112D_INTOPS VIETNAM (DT1C)_QM26076210",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112D",
"partName": "ASSY CASE-REAR_LI;SM-A276B,OPEN,LIGHT PI",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Lệch Tape",
"sampleQty": 20,
"defectQty": 1,
"defectRate": 5,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "ha.conghoat",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-10",
"completedDate": "2026-07-08",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 34,
"no": "34",
"mgmtNo": "260702122",
"registeredDate": "2026-07-02",
"writtenBy": "tue.ptm",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-F976U Deco Front Vết đâm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Vết đâm",
"sampleQty": 250,
"defectQty": 1,
"defectRate": 0.4,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-09",
"completedDate": "2026-07-08",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 35,
"no": "35",
"mgmtNo": "260702121",
"registeredDate": "2026-07-02",
"writtenBy": "tue.ptm",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang sơn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang sơn",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-09",
"completedDate": "2026-07-08",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 36,
"no": "36",
"mgmtNo": "260702119-VOC",
"registeredDate": "2026-07-02",
"writtenBy": "ngoc.pt2",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837A",
"partName": "ASSY CASE-REAR_ZK;SM-A165F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 35,
"defectRate": null,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-09",
"completedDate": "2026-07-08",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 37,
"no": "37",
"mgmtNo": "260702062",
"registeredDate": "2026-07-02",
"writtenBy": "tue.ptm",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-F976U Deco Front Vết đâm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Vết đâm",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-09",
"completedDate": "2026-07-08",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 38,
"no": "38",
"mgmtNo": "260701122",
"registeredDate": "2026-07-01",
"writtenBy": "tue.ptm",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước cạnh ngoài",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước cạnh ngoài",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-08",
"completedDate": "2026-07-06",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 39,
"no": "39",
"mgmtNo": "260701056-VOC",
"registeredDate": "2026-07-01",
"writtenBy": "ngoc.pt2",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu Main _ GH61-22194A _ DT1C",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": null,
"defectQty": 60,
"defectRate": null,
"reason1": "Vật liệu",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-08",
"completedDate": "2026-07-07",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 40,
"no": "40",
"mgmtNo": "260626136-VOC",
"registeredDate": "2026-06-26",
"writtenBy": "the.thuy",
"status": "Đợi xét",
"plant": "SEVT",
"title": "SM-F976U Bracket Cong vênh SM-F976_ Bracket cong vênh _20262506_INTOPS_GH98-51252A",
"occurPlace": "Inhouse (Glass)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51252A",
"partName": "ASSY BRACKET-MAIN CAM;SM-F976U,VZW,BLACK",
"partGroup": "Bracket",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Cong vênh",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Phương pháp",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 41,
"no": "41",
"mgmtNo": "260626096",
"registeredDate": "2026-06-26",
"writtenBy": "vu.hoai",
"status": "Đợi xét",
"plant": "SEV",
"title": "SM-F976U Deco Front Loang sơn SM-F976-Front deco-loang sơn,lệch tape ,hằn ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Loang sơn",
"sampleQty": 500,
"defectQty": 4,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "lien.ng",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 42,
"no": "42",
"mgmtNo": "260624140-VOC",
"registeredDate": "2026-06-24",
"writtenBy": "the.thuy",
"status": "Đợi xét",
"plant": "SEVT",
"title": "SM-A576B I/Molding Front Xước Sub Tech _ 20260623_002 _ Worst xước  , mẻ _ GH98-50890A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50890A",
"partName": "ASSY CASE-FRONT;SM-A576B,OPEN,GRAY",
"partGroup": "I/Molding Front",
"project": "Galaxy-A57-5g",
"model": "SM-A576B_EUR_XX",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 6,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 43,
"no": "43",
"mgmtNo": "260624139-VOC",
"registeredDate": "2026-06-24",
"writtenBy": "the.thuy",
"status": "Đợi xét",
"plant": "SEVT",
"title": "SM-A176B_EUR_XX I/Molding Rear Chấm mụn Sub Tech _ 20260623_001 _ Worst mụn , hằn , xước  _ GH98-50510A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50510A",
"partName": "ASSY CASE-REAR;SM-A176B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17-5g",
"model": "SM-A176B_EUR_XX",
"defectDetails": "Chấm mụn",
"sampleQty": null,
"defectQty": 7,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": null,
"approver": "the.thuy",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 44,
"no": "44",
"mgmtNo": "260702128-VOC",
"registeredDate": "2026-07-02",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837A",
"partName": "ASSY CASE-REAR_ZK;SM-A165F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 8,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-09",
"completedDate": "2026-07-08",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 45,
"no": "45",
"mgmtNo": "260701155",
"registeredDate": "2026-07-01",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F966U Bracket Biến dạng",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50307A",
"partName": "ASSY BRACKET-REAR MAIN TOP;SM-F966U,OPEN",
"partGroup": "Bracket",
"project": "Q7",
"model": "SM-F966U_NA_VZW",
"defectDetails": "Biến dạng",
"sampleQty": 20,
"defectQty": 1,
"defectRate": 5,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-08",
"completedDate": "2026-07-07",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 46,
"no": "46",
"mgmtNo": "260701109-VOC",
"registeredDate": "2026-07-01",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Chấm mụn Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Chấm mụn",
"sampleQty": null,
"defectQty": 73,
"defectRate": null,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-08",
"completedDate": "2026-07-07",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 47,
"no": "47",
"mgmtNo": "260701107-VOC",
"registeredDate": "2026-07-01",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 29,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-08",
"completedDate": "2026-07-08",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 48,
"no": "48",
"mgmtNo": "260701061-VOC",
"registeredDate": "2026-07-01",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Cong vênh Kiểm tra đầu chuyền _ GH98-49958B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Cong vênh",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Vật liệu",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-08",
"completedDate": "2026-07-07",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 49,
"no": "49",
"mgmtNo": "260701029",
"registeredDate": "2026-07-01",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F976U Deco Front Loang đen",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Loang đen",
"sampleQty": 250,
"defectQty": 4,
"defectRate": 1.6,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-08",
"completedDate": "2026-07-07",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 50,
"no": "50",
"mgmtNo": "260701028",
"registeredDate": "2026-07-01",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F976U Deco Front Biến dạng",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Biến dạng",
"sampleQty": 250,
"defectQty": 2,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-08",
"completedDate": "2026-07-07",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 51,
"no": "51",
"mgmtNo": "260630007",
"registeredDate": "2026-06-30",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear [외관] NG LOGO",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "[외관] NG LOGO",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-07",
"completedDate": "2026-07-06",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 52,
"no": "52",
"mgmtNo": "260629153",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F976U Deco Front Lẫn vật liệu cũ",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lẫn vật liệu cũ",
"sampleQty": 250,
"defectQty": 1,
"defectRate": 0.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 53,
"no": "53",
"mgmtNo": "260629125-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 50,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 54,
"no": "54",
"mgmtNo": "260629105-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F Deco Camera Bụi Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Bụi",
"sampleQty": null,
"defectQty": 90,
"defectRate": null,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 55,
"no": "55",
"mgmtNo": "260629049",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A175F I/Molding Rear Nhăn Sơn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50512A",
"partName": "ASSY CASE-REAR;SM-A175F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17",
"model": "SM-A175F_EUR_XX",
"defectDetails": "Nhăn Sơn",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 56,
"no": "56",
"mgmtNo": "260629029",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F976U Deco Front RIB đứt gãy",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "RIB đứt gãy",
"sampleQty": 500,
"defectQty": 2,
"defectRate": 0.4,
"reason1": "Máy móc",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 57,
"no": "57",
"mgmtNo": "260627060",
"registeredDate": "2026-06-27",
"writtenBy": "thu.dt8",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F976U Deco Front Lỗi sai chi tiết (lẫn hàng)",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi sai chi tiết (lẫn hàng)",
"sampleQty": 500,
"defectQty": 1,
"defectRate": 0.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-04",
"completedDate": "2026-07-03",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 58,
"no": "58",
"mgmtNo": "260627048",
"registeredDate": "2026-06-27",
"writtenBy": "thu.dt8",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Dị vật",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837B",
"partName": "ASSY CASE-REAR_ZA;SM-A165F,OPEN,GRAY",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Dị vật",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Vật liệu",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-04",
"completedDate": "2026-07-03",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 59,
"no": "59",
"mgmtNo": "260626118-VOC",
"registeredDate": "2026-06-26",
"writtenBy": "ngoc.pt2",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 55,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 60,
"no": "60",
"mgmtNo": "260626110",
"registeredDate": "2026-06-26",
"writtenBy": "thu.dt8",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Crack",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837A",
"partName": "ASSY CASE-REAR_ZK;SM-A165F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Rạn",
"sampleQty": 125,
"defectQty": 5,
"defectRate": 4,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 61,
"no": "61",
"mgmtNo": "260622110",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Đợi duyệt",
"plant": "SEV",
"title": "SM-F976U Deco Front NG khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "NG khác màu",
"sampleQty": 500,
"defectQty": 3,
"defectRate": 0.6,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "dung.huu",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-08",
"completedDate": "2026-07-05",
"tatDays": "13",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 62,
"no": "62",
"mgmtNo": "260622017-VOC",
"registeredDate": "2026-06-22",
"writtenBy": "the.thuy",
"status": "Đợi duyệt",
"plant": "SEVT",
"title": "SM-X306B_EUR_XX I/Molding Rear WPC Hansol _ 20260620_001 _ Fail WPC _ Intops VN _ GH98-49066A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49066A",
"partName": "ASSY CASE-REAR_EUR;SM-X306B,EUR,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-Tab-Active5",
"model": "SM-X306B_EUR_XX",
"defectDetails": "WPC",
"sampleQty": null,
"defectQty": 4,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "the.thuy",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-29",
"completedDate": "2026-06-27",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 63,
"no": "63",
"mgmtNo": "260622016-VOC",
"registeredDate": "2026-06-22",
"writtenBy": "the.thuy",
"status": "Đợi duyệt",
"plant": "SEVT",
"title": "SM-X306B_EUR_XX I/Molding Rear Lỗi kích thước Hansol _ 20260620_002 _ Khó, không cắm được earjack phone _ Intops VN _ GH98-49066A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49066A",
"partName": "ASSY CASE-REAR_EUR;SM-X306B,EUR,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-Tab-Active5",
"model": "SM-X306B_EUR_XX",
"defectDetails": "Lỗi kích thước",
"sampleQty": null,
"defectQty": 10,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "the.thuy",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-29",
"completedDate": "2026-06-27",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 64,
"no": "64",
"mgmtNo": "260619023-VOC",
"registeredDate": "2026-06-19",
"writtenBy": "the.thuy",
"status": "Đợi duyệt",
"plant": "SEVT",
"title": "SM-A276B_EUR_XX I/Molding Front GAP Main _ 20260617_008 _ Hở GAP giữa rear và front _ GH98-51170A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51170A",
"partName": "ASSY CASE-FRONT_V3;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "GAP",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "the.thuy",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-26",
"completedDate": "2026-06-25",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 65,
"no": "65",
"mgmtNo": "260619022-VOC",
"registeredDate": "2026-06-19",
"writtenBy": "the.thuy",
"status": "Đợi duyệt",
"plant": "SEVT",
"title": "SM-A276B_EUR_XX I/Molding Front Thiếu linh kiện Sub Tech _ 20260616_002 _ NG NGOẠI QUAN _ GH98-51170A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51170A",
"partName": "ASSY CASE-FRONT_V3;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Thiếu linh kiện",
"sampleQty": null,
"defectQty": 6,
"defectRate": null,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "the.thuy",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-26",
"completedDate": "2026-06-25",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 66,
"no": "66",
"mgmtNo": "260616046",
"registeredDate": "2026-06-16",
"writtenBy": "pham.thao",
"status": "Đợi duyệt",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Dị vật GH98-51112C_INTOPS VIETNAM (DT1C )_QM26065510",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112C",
"partName": "ASSY CASE-REAR_LG;SM-A276B,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Dị vật",
"sampleQty": 20,
"defectQty": 1,
"defectRate": 5,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "ha.conghoat",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-06-23",
"completedDate": "2026-06-22",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 67,
"no": "67",
"mgmtNo": "260702112-VOC",
"registeredDate": "2026-07-02",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 69,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 68,
"no": "68",
"mgmtNo": "260701088-VOC",
"registeredDate": "2026-07-01",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Mechanical(etc) Lỗi kích thước Outsourcing _ GH61-22185A _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22185A",
"partName": "CASE-VOL KEY FPCB BRACKET;PA+GF50%,SM-F9",
"partGroup": "Mechanical(etc)",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi kích thước",
"sampleQty": null,
"defectQty": 7,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 69,
"no": "69",
"mgmtNo": "260701058-VOC",
"registeredDate": "2026-07-01",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Chưa CNC Kiểm tra đầu chuyền _ GH61-22194A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Chưa CNC",
"sampleQty": null,
"defectQty": 17,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-14",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 70,
"no": "70",
"mgmtNo": "260629129-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 50,
"defectRate": null,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 71,
"no": "71",
"mgmtNo": "260629110-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Chấm mụn Kiểm tra đầu chuyền _ GH98-49837B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837B",
"partName": "ASSY CASE-REAR_ZA;SM-A165F,OPEN,GRAY",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Chấm mụn",
"sampleQty": null,
"defectQty": 36,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 72,
"no": "72",
"mgmtNo": "260629107-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-A253D I/Molding Front WPT Fail Outsourcing _ GH98-49958A _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "WPT Fail",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-09",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 73,
"no": "73",
"mgmtNo": "260629102-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lỗi kênh Outsourcing _ GH98-49958A _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lỗi kênh",
"sampleQty": null,
"defectQty": 8,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 74,
"no": "74",
"mgmtNo": "260629101-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Sứt mẻ Kiểm tra đầu chuyền _ GH98-49958B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Sứt mẻ",
"sampleQty": null,
"defectQty": 6,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-11",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 75,
"no": "75",
"mgmtNo": "260629058",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Biến dạng",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Biến dạng",
"sampleQty": 250,
"defectQty": 2,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-11",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 76,
"no": "76",
"mgmtNo": "260629055",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Lõm mặt A",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lõm mặt A",
"sampleQty": 250,
"defectQty": 2,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-11",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 77,
"no": "77",
"mgmtNo": "260629031",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Lệch",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lệch",
"sampleQty": 500,
"defectQty": 2,
"defectRate": 0.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-11",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 78,
"no": "78",
"mgmtNo": "260626052",
"registeredDate": "2026-06-26",
"writtenBy": "thu.dt8",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 500,
"defectQty": 3,
"defectRate": 0.6,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "SD",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 79,
"no": "79",
"mgmtNo": "260626049",
"registeredDate": "2026-06-26",
"writtenBy": "thu.dt8",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 500,
"defectQty": 2,
"defectRate": 0.4,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 80,
"no": "80",
"mgmtNo": "260625034",
"registeredDate": "2026-06-25",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 500,
"defectQty": 4,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 81,
"no": "81",
"mgmtNo": "260625007",
"registeredDate": "2026-06-25",
"writtenBy": "vdung.ng",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F9760 Deco Front Xước mặt A Xước , Khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F9760_CHN_CHC",
"defectDetails": "Xước mặt A",
"sampleQty": 500,
"defectQty": 2,
"defectRate": 0.4,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-09",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 82,
"no": "82",
"mgmtNo": "260624168",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front NG khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "NG khác màu",
"sampleQty": 500,
"defectQty": 2,
"defectRate": 0.4,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "Y",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 83,
"no": "83",
"mgmtNo": "260624113",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 500,
"defectQty": 4,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 84,
"no": "84",
"mgmtNo": "260624027",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front NG khác màu",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "NG khác màu",
"sampleQty": 500,
"defectQty": 7,
"defectRate": 1.4,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 85,
"no": "85",
"mgmtNo": "260624021",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Difference Color Limit",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Difference Color Limit",
"sampleQty": 500,
"defectQty": 4,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "Y",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 86,
"no": "86",
"mgmtNo": "260623081",
"registeredDate": "2026-06-23",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Difference Color Limit",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Difference Color Limit",
"sampleQty": 500,
"defectQty": 4,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "SD",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 87,
"no": "87",
"mgmtNo": "260623080",
"registeredDate": "2026-06-23",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 500,
"defectQty": 1,
"defectRate": 0.2,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "Y",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 88,
"no": "88",
"mgmtNo": "260623002",
"registeredDate": "2026-06-23",
"writtenBy": "vdung.ng",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F9760 Deco Front Difference Color Limit NG khác màu , burr , hằn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F9760_CHN_CHC",
"defectDetails": "Difference Color Limit",
"sampleQty": 500,
"defectQty": 3,
"defectRate": 0.6,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 89,
"no": "89",
"mgmtNo": "260622126",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front NG khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "NG khác màu",
"sampleQty": 500,
"defectQty": 6,
"defectRate": 1.2,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 90,
"no": "90",
"mgmtNo": "260622050",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Mụn Sơn",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Mụn Sơn",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-10",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 91,
"no": "91",
"mgmtNo": "260622039",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Rejected (xét)",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 250,
"defectQty": 6,
"defectRate": 2.4,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": null,
"issueYN": "N",
"claimYN": null,
"reoccur3M": "N",
"dueDate": "2026-07-09",
"completedDate": null,
"tatDays": null,
"tatCompliance": null,
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 92,
"no": "92",
"mgmtNo": "260629099-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 35,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 93,
"no": "93",
"mgmtNo": "260629083-VOC",
"registeredDate": "2026-06-29",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A176B I/Molding Rear Hằn Main _ 20260627_001 _ Hằn Rear _ GH98-50510A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50510A",
"partName": "ASSY CASE-REAR;SM-A176B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17-5g",
"model": "SM-A176B_EUR_XX",
"defectDetails": "Hằn",
"sampleQty": null,
"defectQty": 40,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vu.xuan",
"approvalDate": "2026-06-30",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-06-29",
"tatDays": "0",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 94,
"no": "94",
"mgmtNo": "260629035",
"registeredDate": "2026-06-29",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Lệch Tape",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Lệch Tape",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Máy móc",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 95,
"no": "95",
"mgmtNo": "260626142",
"registeredDate": "2026-06-26",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Mixing Defect SM-F976-Front deco main -Mixxing hàng trước cải tiến ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi lẫn hàng (mixing)",
"sampleQty": 500,
"defectQty": 2,
"defectRate": 0.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "Y",
"dueDate": "2026-07-03",
"completedDate": "2026-07-03",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 96,
"no": "96",
"mgmtNo": "260626131-VOC",
"registeredDate": "2026-06-26",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A176B I/Molding Rear Hằn Main _ 20260625_003 _ Sứt rear cùng 1 vị trí  _ GH98-50510A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50510A",
"partName": "ASSY CASE-REAR;SM-A176B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17-5g",
"model": "SM-A176B_EUR_XX",
"defectDetails": "Hằn",
"sampleQty": null,
"defectQty": 155,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-06-30",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-06-29",
"tatDays": "3",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 97,
"no": "97",
"mgmtNo": "260626122",
"registeredDate": "2026-06-26",
"writtenBy": "thu.dt8",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Nhám sơn",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958C",
"partName": "ASSY CASE-FRONT_A253D_ZB;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Nhám sơn",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-07-03",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 98,
"no": "98",
"mgmtNo": "260626111-VOC",
"registeredDate": "2026-06-26",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 26,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 99,
"no": "99",
"mgmtNo": "260626105",
"registeredDate": "2026-06-26",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Lệch Tape Deco Front SM-Front deco-gẫy chân T-Rib,NG tape",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lệch Tape Deco Front",
"sampleQty": 500,
"defectQty": 6,
"defectRate": 1.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 100,
"no": "100",
"mgmtNo": "260626051",
"registeredDate": "2026-06-26",
"writtenBy": "thu.dt8",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lỗi lẹm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lỗi lẹm",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": "Máy móc",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-07-02",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 101,
"no": "101",
"mgmtNo": "260625078",
"registeredDate": "2026-06-25",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F966U Deco Front Loang SM-F966-Deco sub -loang,biến dạng,NG tape ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50320A",
"partName": "ASSY CASE-FRONT DECO SUB;SM-F966U,US,BLA",
"partGroup": "Deco Front",
"project": "Q7",
"model": "SM-F966U_NA_VZW",
"defectDetails": "Loang",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-02",
"completedDate": "2026-07-02",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 102,
"no": "102",
"mgmtNo": "260625074-VOC",
"registeredDate": "2026-06-25",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Mechanical(etc) Lõm Kiểm tra đầu chuyền _ GH98-51128A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51128A",
"partName": "ASSY COVER-HOLDER CTC MAIN;SM-F976U,VZW,",
"partGroup": "Mechanical(etc)",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lõm",
"sampleQty": null,
"defectQty": 102,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-02",
"completedDate": "2026-07-01",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 103,
"no": "103",
"mgmtNo": "260625071-VOC",
"registeredDate": "2026-06-25",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Lỗi lẫn hàng (mixing) Kiểm tra đầu chuyền _ GH61-22194A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi lẫn hàng (mixing)",
"sampleQty": null,
"defectQty": 50,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-02",
"completedDate": "2026-07-01",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 104,
"no": "104",
"mgmtNo": "260625033",
"registeredDate": "2026-06-25",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Biến dạng",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Biến dạng",
"sampleQty": 125,
"defectQty": 4,
"defectRate": 3.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-02",
"completedDate": "2026-07-01",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 105,
"no": "105",
"mgmtNo": "260624167",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Lỗi lẫn hàng (mixing)",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi lẫn hàng (mixing)",
"sampleQty": 500,
"defectQty": 4,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-01",
"completedDate": "2026-07-01",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 106,
"no": "106",
"mgmtNo": "260624165",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Lỗi lẫn hàng (mixing)",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi lẫn hàng (mixing)",
"sampleQty": 1920,
"defectQty": 8,
"defectRate": 0.42,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-01",
"completedDate": "2026-07-01",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 107,
"no": "107",
"mgmtNo": "260624142-VOC",
"registeredDate": "2026-06-24",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Ngoại quan (vết đâm) Kiểm tra đầu chuyền _ GH98-51070A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Ngoại quan (vết đâm)",
"sampleQty": null,
"defectQty": 118,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 108,
"no": "108",
"mgmtNo": "260624131-VOC",
"registeredDate": "2026-06-24",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 37,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-07",
"completedDate": "2026-07-05",
"tatDays": "11",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 109,
"no": "109",
"mgmtNo": "260624130-VOC",
"registeredDate": "2026-06-24",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A175F I/Molding Front Lệch Rubber Kiểm tra đầu chuyền _ GH98-50513A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50513A",
"partName": "ASSY BRACKET-A176B;SM-A176B,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-A17",
"model": "SM-A175F_EUR_XX",
"defectDetails": "Lệch Rubber",
"sampleQty": null,
"defectQty": 8,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 110,
"no": "110",
"mgmtNo": "260624115",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Loang",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Loang",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-01",
"completedDate": "2026-06-29",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 111,
"no": "111",
"mgmtNo": "260624009",
"registeredDate": "2026-06-24",
"writtenBy": "vdung.ng",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A175F I/Molding Rear Chấm mụn",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50512A",
"partName": "ASSY CASE-REAR;SM-A175F,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A17",
"model": "SM-A175F_EUR_XX",
"defectDetails": "Chấm mụn",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 112,
"no": "112",
"mgmtNo": "260623068-VOC",
"registeredDate": "2026-06-23",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 90,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-28",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 113,
"no": "113",
"mgmtNo": "260623055-VOC",
"registeredDate": "2026-06-23",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 43,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-29",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 114,
"no": "114",
"mgmtNo": "260623053-VOC",
"registeredDate": "2026-06-23",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 54,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-28",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 115,
"no": "115",
"mgmtNo": "260623051-VOC",
"registeredDate": "2026-06-23",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 39,
"defectRate": null,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-29",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 116,
"no": "116",
"mgmtNo": "260623048-VOC",
"registeredDate": "2026-06-23",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Go/No JIG Kiểm tra đầu chuyền _ GH98-49958B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Go/No JIG",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Vật liệu",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-29",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 117,
"no": "117",
"mgmtNo": "260623046-VOC",
"registeredDate": "2026-06-23",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 63,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-28",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 118,
"no": "118",
"mgmtNo": "260623016",
"registeredDate": "2026-06-24",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Dị vật sơn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Dị vật sơn",
"sampleQty": 125,
"defectQty": 1,
"defectRate": 0.8,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 119,
"no": "119",
"mgmtNo": "260623012",
"registeredDate": "2026-06-23",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Nhăn Sơn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Nhăn Sơn",
"sampleQty": 500,
"defectQty": 5,
"defectRate": 1,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-08",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-07",
"completedDate": "2026-07-07",
"tatDays": "14",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 120,
"no": "120",
"mgmtNo": "260623001",
"registeredDate": "2026-06-23",
"writtenBy": "vdung.ng",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Burr Burr , Đâm , rách màng loa",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Burr",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-29",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 121,
"no": "121",
"mgmtNo": "260622108",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Biến dạng",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Biến dạng",
"sampleQty": 500,
"defectQty": 6,
"defectRate": 1.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-29",
"completedDate": "2026-06-29",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 122,
"no": "122",
"mgmtNo": "260622104",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Loang trắng",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Loang trắng",
"sampleQty": 500,
"defectQty": 10,
"defectRate": 2,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-06",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-29",
"completedDate": "2026-06-29",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 123,
"no": "123",
"mgmtNo": "260622098-VOC",
"registeredDate": "2026-06-22",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F Deco Camera Xước Kiểm tra đầu chuyền _ GH98-49836A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49836A",
"partName": "ASSY DECO-CAMERA;SM-A165F,OPEN,BLACK",
"partGroup": "Deco Camera",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 50,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-29",
"completedDate": "2026-06-28",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 124,
"no": "124",
"mgmtNo": "260622043",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Khác màu",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Khác màu",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-09",
"completedDate": "2026-07-05",
"tatDays": "13",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 125,
"no": "125",
"mgmtNo": "260622035",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Thiếu nhựa",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958C",
"partName": "ASSY CASE-FRONT_A253D_ZB;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Thiếu nhựa",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-06",
"completedDate": "2026-07-05",
"tatDays": "13",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 126,
"no": "126",
"mgmtNo": "260622018",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Loang",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Loang",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-29",
"completedDate": "2026-06-28",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 127,
"no": "127",
"mgmtNo": "260622015",
"registeredDate": "2026-06-22",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976B Deco Front RIB đứt gãy",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976B_EUR_XX",
"defectDetails": "RIB đứt gãy",
"sampleQty": 250,
"defectQty": 5,
"defectRate": 2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-06",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-29",
"completedDate": "2026-06-29",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 128,
"no": "128",
"mgmtNo": "260621008",
"registeredDate": "2026-06-21",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Lỗi lệch SM-F976-DECO SUB- Lệch tape ,loang,gẫy chân rip,mẻ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lỗi lệch",
"sampleQty": 250,
"defectQty": 5,
"defectRate": 2,
"reason1": "Máy móc",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-28",
"completedDate": "2026-06-26",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 129,
"no": "129",
"mgmtNo": "260621007",
"registeredDate": "2026-06-21",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "BSM-A165F I/Molding Rear Loang mặt B SM-A165-REAR-Loang,mụn phím ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837B",
"partName": "ASSY CASE-REAR_ZA;SM-A165F,OPEN,GRAY",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16 ALL LTE",
"model": "BSM-A165F/1R4",
"defectDetails": "Loang mặt B",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-28",
"completedDate": "2026-06-26",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 130,
"no": "130",
"mgmtNo": "260621006",
"registeredDate": "2026-06-21",
"writtenBy": "lt.trang1",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Dị vật GH98-51112D_INTOPS VIETNAM( DT1C )_QM26065718",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112D",
"partName": "ASSY CASE-REAR_LI;SM-A276B,OPEN,LIGHT PI",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Dị vật",
"sampleQty": 20,
"defectQty": 1,
"defectRate": 5,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "ha.conghoat",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-28",
"completedDate": "2026-06-26",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 131,
"no": "131",
"mgmtNo": "260621005",
"registeredDate": "2026-06-21",
"writtenBy": "thu.dt8",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976B Deco Front Scratch",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976B_EUR_XX",
"defectDetails": "Scratch",
"sampleQty": 250,
"defectQty": 5,
"defectRate": 2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-28",
"completedDate": "2026-06-26",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 132,
"no": "132",
"mgmtNo": "260620021",
"registeredDate": "2026-06-20",
"writtenBy": "vdung.ng",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Loang mặt B",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958C",
"partName": "ASSY CASE-FRONT_A253D_ZB;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Loang mặt B",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-27",
"completedDate": "2026-06-26",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 133,
"no": "133",
"mgmtNo": "260620009",
"registeredDate": "2026-06-20",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "BSM-A253Z I/Molding Front Dị vật sơn SM-A253-FrORNT- Dị vật sơn , hằn ,NG tape ",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958C",
"partName": "ASSY CASE-FRONT_A253D_ZB;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g ALL NRM",
"model": "BSM-A253Z/6R4",
"defectDetails": "Dị vật sơn",
"sampleQty": 125,
"defectQty": 4,
"defectRate": 3.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-27",
"completedDate": "2026-06-25",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 134,
"no": "134",
"mgmtNo": "260619094-VOC",
"registeredDate": "2026-06-19",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front WPT Fail Outsourcing _ GH98-49958B _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "WPT Fail",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-26",
"completedDate": "2026-06-24",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 135,
"no": "135",
"mgmtNo": "260619093-VOC",
"registeredDate": "2026-06-19",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lỗi lẫn hàng (mixing) Kiểm tra đầu chuyền _ GH98-49958B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lỗi lẫn hàng (mixing)",
"sampleQty": null,
"defectQty": 22,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-26",
"completedDate": "2026-06-25",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 136,
"no": "136",
"mgmtNo": "260619056-VOC",
"registeredDate": "2026-06-19",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 50,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-07",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-06",
"completedDate": "2026-07-04",
"tatDays": "15",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 137,
"no": "137",
"mgmtNo": "260619016-VOC",
"registeredDate": "2026-06-19",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước Kiểm tra đầu chuyền _ GH98-49958B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 15,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-26",
"completedDate": "2026-06-26",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 138,
"no": "138",
"mgmtNo": "260618169",
"registeredDate": "2026-06-18",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front RIB đứt gãy",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "RIB đứt gãy",
"sampleQty": 250,
"defectQty": 2,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-25",
"completedDate": "2026-06-22",
"tatDays": "4",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 139,
"no": "139",
"mgmtNo": "260618134",
"registeredDate": "2026-06-18",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Burr",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Burr",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-25",
"completedDate": "2026-06-25",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 140,
"no": "140",
"mgmtNo": "260618119-VOC",
"registeredDate": "2026-06-18",
"writtenBy": "hao.nt1",
"status": "Hoàn thành",
"plant": "SEV",
"title": "BSM-F976N Tape Kênh tape SMD _ GH02-28169A _ DT1C",
"occurPlace": "SMD",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH02-28169A",
"partName": "TAPE ABSORBER-DEF_F976U;SM-F976U,CONDUCT",
"partGroup": "Tape",
"project": "Q8 ALL NRM",
"model": "BSM-F976N/2R1",
"defectDetails": "Kênh tape",
"sampleQty": null,
"defectQty": 5,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "vanan.ng",
"approver": "dhung.chu",
"approvalDate": "2026-06-29",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-25",
"completedDate": "2026-06-25",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 141,
"no": "141",
"mgmtNo": "260618053-VOC",
"registeredDate": "2026-06-18",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Sứt mẻ Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Sứt mẻ",
"sampleQty": null,
"defectQty": 10,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-25",
"completedDate": "2026-06-24",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 142,
"no": "142",
"mgmtNo": "260618052-VOC",
"registeredDate": "2026-06-18",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 12,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-25",
"completedDate": "2026-06-24",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 143,
"no": "143",
"mgmtNo": "260618048-VOC",
"registeredDate": "2026-06-18",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX730 I/Molding Front thấp phím OQC (Etc) _ GH98-50647A _ DT1C",
"occurPlace": "OQC (Etc)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50647A",
"partName": "ASSY CASE-FRONT US;EF-DX730,US,PC+GF,BLA",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S11",
"model": "EF-DX730",
"defectDetails": "thấp phím",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "tr.ngoc.duy",
"approver": "xuanhai.ph",
"approvalDate": "2026-07-02",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-25",
"completedDate": "2026-06-25",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 144,
"no": "144",
"mgmtNo": "260618043",
"registeredDate": "2026-06-18",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX710 I/Molding Front (-) Lỗi gãy vật liệu",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-48567A",
"partName": "ASSY CASE-FRONT US;EF-DX710,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S9",
"model": "EF-DX710",
"defectDetails": "(-) Lỗi gãy vật liệu",
"sampleQty": 20,
"defectQty": 1,
"defectRate": 5,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "xuanhai.ph",
"approvalDate": "2026-07-02",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-07-01",
"completedDate": "2026-06-30",
"tatDays": "12",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 145,
"no": "145",
"mgmtNo": "260618010",
"registeredDate": "2026-06-18",
"writtenBy": "thu.dt8",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front 센서 Scratch",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "센서 Scratch",
"sampleQty": 250,
"defectQty": 2,
"defectRate": 0.8,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-25",
"completedDate": "2026-06-24",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 146,
"no": "146",
"mgmtNo": "260618007",
"registeredDate": "2026-06-18",
"writtenBy": "vu.hoai",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976N Deco Front Lệch Tape SM-F976-Deco sub-lệch tape ,loang,biến  dạng",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976N_KOR_KX",
"defectDetails": "Lệch Tape",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-25",
"completedDate": "2026-06-24",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 147,
"no": "147",
"mgmtNo": "260617140-VOC",
"registeredDate": "2026-06-17",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX930 I/Molding Front Sứt mẻ Kiểm tra đầu chuyền _ GH98-50644A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50644A",
"partName": "ASSY CASE-FRONT US;EF-DX930,US,PC+GF,BLA",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S11-Ultra",
"model": "EF-DX930",
"defectDetails": "Sứt mẻ",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "tr.ngoc.duy",
"approver": "xuanhai.ph",
"approvalDate": "2026-06-30",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-24",
"completedDate": "2026-06-23",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 148,
"no": "148",
"mgmtNo": "260617138-VOC",
"registeredDate": "2026-06-17",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 56,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-07-03",
"completedDate": "2026-07-01",
"tatDays": "14",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 149,
"no": "149",
"mgmtNo": "260617134",
"registeredDate": "2026-06-17",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Lõm",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lõm",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-24",
"completedDate": "2026-06-22",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 150,
"no": "150",
"mgmtNo": "260617128",
"registeredDate": "2026-06-17",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX730 I/Molding Front Kênh linh kiện",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50647A",
"partName": "ASSY CASE-FRONT US;EF-DX730,US,PC+GF,BLA",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S11",
"model": "EF-DX730",
"defectDetails": "Kênh linh kiện",
"sampleQty": 50,
"defectQty": 1,
"defectRate": 2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "xuanhai.ph",
"approvalDate": "2026-06-30",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-24",
"completedDate": "2026-06-23",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 151,
"no": "151",
"mgmtNo": "260617047-VOC",
"registeredDate": "2026-06-17",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-X306B I/Molding Rear WPC Hansol _ 20260610_002 _ Fail WPC _ Intops VN _ GH98-49066A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49066A",
"partName": "ASSY CASE-REAR_EUR;SM-X306B,EUR,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-Tab-Active5",
"model": "SM-X306B_EUR_XX",
"defectDetails": "WPC",
"sampleQty": null,
"defectQty": 10,
"defectRate": null,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-24",
"completedDate": "2026-06-23",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 152,
"no": "152",
"mgmtNo": "260617046-VOC",
"registeredDate": "2026-06-17",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A576B I/Molding Front Sứt mẻ Sub Tech _ 20260615_001 _ worst mẻ chân boss vit _ GH98-50890B",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50890B",
"partName": "ASSY CASE-FRONT_DB;SM-A576B,OPEN,DARK BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A57-5g",
"model": "SM-A576B_EUR_XX",
"defectDetails": "Sứt mẻ",
"sampleQty": null,
"defectQty": 4,
"defectRate": null,
"reason1": "Vật liệu",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-24",
"completedDate": "2026-06-24",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 153,
"no": "153",
"mgmtNo": "260617039",
"registeredDate": "2026-06-17",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Loang góc",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Loang góc",
"sampleQty": 250,
"defectQty": 1,
"defectRate": 0.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-24",
"completedDate": "2026-06-22",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 154,
"no": "154",
"mgmtNo": "260617011-VOC",
"registeredDate": "2026-06-17",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front WPT Fail Outsourcing _ GH98-49958A _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "WPT Fail",
"sampleQty": null,
"defectQty": 6,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-24",
"completedDate": "2026-06-23",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 155,
"no": "155",
"mgmtNo": "260616067-VOC",
"registeredDate": "2026-06-16",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước Kiểm tra đầu chuyền _ GH98-49958B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 12,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-23",
"completedDate": "2026-06-22",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 156,
"no": "156",
"mgmtNo": "260616066-VOC",
"registeredDate": "2026-06-16",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Mechanical(etc) Lệch Tape Kiểm tra đầu chuyền _ GH98-51128A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51128A",
"partName": "ASSY COVER-HOLDER CTC MAIN;SM-F976U,VZW,",
"partGroup": "Mechanical(etc)",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Lệch Tape",
"sampleQty": null,
"defectQty": 4,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-27",
"completedDate": "2026-06-27",
"tatDays": "11",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 157,
"no": "157",
"mgmtNo": "260616035",
"registeredDate": "2026-06-16",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX930 I/Molding Front Dị vật sơn",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50644A",
"partName": "ASSY CASE-FRONT US;EF-DX930,US,PC+GF,BLA",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S11-Ultra",
"model": "EF-DX930",
"defectDetails": "Dị vật sơn",
"sampleQty": 50,
"defectQty": 1,
"defectRate": 2,
"reason1": "Máy móc",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "xuanhai.ph",
"approvalDate": "2026-06-30",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-23",
"completedDate": "2026-06-20",
"tatDays": "4",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 158,
"no": "158",
"mgmtNo": "260616034",
"registeredDate": "2026-06-16",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Vết đâm",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Vết đâm",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-23",
"completedDate": "2026-06-20",
"tatDays": "4",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 159,
"no": "159",
"mgmtNo": "260616025-VOC",
"registeredDate": "2026-06-16",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-X306B I/Molding Rear Grip sensor Hansol _ 20260612_003 _ NG RF Coaxial Cable check  ( Grip CAP Main CH3) _ Intops VN _ GH98-49066A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49066A",
"partName": "ASSY CASE-REAR_EUR;SM-X306B,EUR,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-Tab-Active5",
"model": "SM-X306B_EUR_XX",
"defectDetails": "Grip sensor",
"sampleQty": null,
"defectQty": 5,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-23",
"completedDate": "2026-06-22",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 160,
"no": "160",
"mgmtNo": "260616020",
"registeredDate": "2026-06-16",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Bong FPCB",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Bong FPCB",
"sampleQty": 125,
"defectQty": 2,
"defectRate": 1.6,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-27",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-23",
"completedDate": "2026-06-20",
"tatDays": "4",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 161,
"no": "161",
"mgmtNo": "260616008",
"registeredDate": "2026-06-16",
"writtenBy": "yh1024.cho",
"status": "Hoàn thành",
"plant": "HQ",
"title": "SM-F976U I/Molding Rear 부자재 누락 SM-F976 REAR MAIN TOP 스펀지 누락",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51132A",
"partName": "ASSY COVER-REAR MAIN TOP;SM-F976U,VZW,BL",
"partGroup": "I/Molding Rear",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Subsidiary material missing",
"sampleQty": null,
"defectQty": 2,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "yh1024.cho",
"approver": "yh1024.cho",
"approvalDate": "2026-06-30",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-30",
"completedDate": "2026-06-29",
"tatDays": "13",
"tatCompliance": "Y",
"transactionType": "IPC",
"locatedCorp": "SEV"
},
{
"id": 162,
"no": "162",
"mgmtNo": "260615138",
"registeredDate": "2026-06-15",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Bẩn mực",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Bẩn mực",
"sampleQty": 125,
"defectQty": 5,
"defectRate": 4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-27",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-22",
"completedDate": "2026-06-20",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 163,
"no": "163",
"mgmtNo": "260615133-VOC",
"registeredDate": "2026-06-15",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 32,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-22",
"completedDate": "2026-06-18",
"tatDays": "3",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 164,
"no": "164",
"mgmtNo": "260615132-VOC",
"registeredDate": "2026-06-15",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Xước Kiểm tra đầu chuyền _ GH98-49837B _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837B",
"partName": "ASSY CASE-REAR_ZA;SM-A165F,OPEN,GRAY",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 21,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-22",
"completedDate": "2026-06-18",
"tatDays": "3",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 165,
"no": "165",
"mgmtNo": "260615042-VOC",
"registeredDate": "2026-06-15",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "BSM-G556B I/Molding Front WPT Fail Hansol _ 20260611_003 _ Fail WPC tại main _  Intops VN _ GH98-49052A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49052A",
"partName": "ASSY CASE-REAR;SM-G556B,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-Xcover7 ALL NRM",
"model": "BSM-G556B/1R6D",
"defectDetails": "WPT Fail",
"sampleQty": null,
"defectQty": 10,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-22",
"completedDate": "2026-06-19",
"tatDays": "4",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 166,
"no": "166",
"mgmtNo": "260615041-VOC",
"registeredDate": "2026-06-15",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-X306B I/Molding Front Kênh Key Hansol _ 20260611_001 _ Nghiêng phím Hot key _ Intops VN  _ GH98-49067A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49067A",
"partName": "ASSY CASE-REAR_NA;SM-X308U,XAA,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-Active5",
"model": "SM-X306B_EUR_XX",
"defectDetails": "Kênh Key",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-22",
"completedDate": "2026-06-19",
"tatDays": "4",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 167,
"no": "167",
"mgmtNo": "260615040-VOC",
"registeredDate": "2026-06-15",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Xước Sub Tech _ 20260611_001 _ NG ngoại quan _ GH98-51112B",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112B",
"partName": "ASSY CASE-REAR_ZB;SM-A276B,OPEN,BLUE",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 11,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-22",
"completedDate": "2026-06-20",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 168,
"no": "168",
"mgmtNo": "260615037-VOC",
"registeredDate": "2026-06-15",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Nhám sơn Main _ 20260610_004 _ Toolmark _ GH98-51112A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112A",
"partName": "ASSY CASE-REAR;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Nhám sơn",
"sampleQty": null,
"defectQty": 7,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-22",
"completedDate": "2026-06-20",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 169,
"no": "169",
"mgmtNo": "260613022-VOC",
"registeredDate": "2026-06-13",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Dị vật Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Dị vật",
"sampleQty": null,
"defectQty": 41,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-20",
"completedDate": "2026-06-19",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 170,
"no": "170",
"mgmtNo": "260613011",
"registeredDate": "2026-06-13",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Dị vật tape",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Dị vật tape",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-26",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-20",
"completedDate": "2026-06-19",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 171,
"no": "171",
"mgmtNo": "260612124-VOC",
"registeredDate": "2026-06-12",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lỗi lẹm Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lỗi lẹm",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-27",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-19",
"completedDate": "2026-06-18",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 172,
"no": "172",
"mgmtNo": "260612121-VOC",
"registeredDate": "2026-06-12",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Xước Kiểm tra đầu chuyền _ GH98-49958A _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Xước",
"sampleQty": null,
"defectQty": 12,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-29",
"completedDate": "2026-06-29",
"tatDays": "17",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 173,
"no": "173",
"mgmtNo": "260612027-VOC",
"registeredDate": "2026-06-12",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Bẩn Main _ 20260610_007 _ Bẩn Rear _ GH98-51112B",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112B",
"partName": "ASSY CASE-REAR_ZB;SM-A276B,OPEN,BLUE",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Bẩn",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-19",
"completedDate": "2026-06-18",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 174,
"no": "174",
"mgmtNo": "260612026-VOC",
"registeredDate": "2026-06-12",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear NG vít Main _ 20260610_005 _ Tịt lỗ vit _ GH98-51112A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112A",
"partName": "ASSY CASE-REAR;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "NG vít",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-19",
"completedDate": "2026-06-18",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 175,
"no": "175",
"mgmtNo": "260612025-VOC",
"registeredDate": "2026-06-12",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear loang bẩn Main _ 20260609_005 _ Bẩn  Trong Rear _ GH98-51112D",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112D",
"partName": "ASSY CASE-REAR_LI;SM-A276B,OPEN,LIGHT PI",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "loang bẩn",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-19",
"completedDate": "2026-06-18",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 176,
"no": "176",
"mgmtNo": "260612002",
"registeredDate": "2026-06-12",
"writtenBy": "lt.trang1",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-F731U Deco Front Biến dạng GH98-48294A_INTOPS VIETNAM (DT1C)_QM26065373",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-48294A",
"partName": "ASSY DECO-FRONT BTM_ZA;SM-F731U,OPEN,BLA",
"partGroup": "Deco Front",
"project": "B5",
"model": "SM-F731U",
"defectDetails": "Biến dạng",
"sampleQty": 20,
"defectQty": 1,
"defectRate": 5,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "ha.conghoat",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-19",
"completedDate": "2026-06-18",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 177,
"no": "177",
"mgmtNo": "260611102",
"registeredDate": "2026-06-11",
"writtenBy": "s.ningsih",
"status": "Hoàn thành",
"plant": "SEIN",
"title": "BSM-F976U1 I/Molding Rear Missing tape and Missing Tape",
"occurPlace": "IQC Fail (Mass production)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51132A",
"partName": "ASSY COVER-REAR MAIN TOP;SM-F976U,VZW,BL",
"partGroup": "I/Molding Rear",
"project": "Q8 ALL NRM",
"model": "BSM-F976U1/2R1",
"defectDetails": "Thiếu tape",
"sampleQty": 20,
"defectQty": 3,
"defectRate": 15,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "zainudin.23",
"approver": "januar.ev",
"approvalDate": "2026-06-22",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N_ lần đầu tiên",
"dueDate": "2026-06-25",
"completedDate": "2026-06-19",
"tatDays": "8",
"tatCompliance": "Y",
"transactionType": "IPC",
"locatedCorp": "SEV"
},
{
"id": 178,
"no": "178",
"mgmtNo": "260611060-VOC",
"registeredDate": "2026-06-11",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A165F I/Molding Rear Loang Kiểm tra đầu chuyền _ GH98-49837D _ DT1C",
"occurPlace": "Kiểm tra đầu chuyền",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49837D",
"partName": "ASSY CASE-REAR_LG;SM-A165F,OPEN,LIGHT GR",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A16",
"model": "SM-A165F_SEA_XXV",
"defectDetails": "Loang",
"sampleQty": null,
"defectQty": 66,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-26",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-18",
"completedDate": "2026-06-17",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 179,
"no": "179",
"mgmtNo": "260611033",
"registeredDate": "2026-06-11",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Burr",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Burr",
"sampleQty": 125,
"defectQty": 3,
"defectRate": 2.4,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-26",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-18",
"completedDate": "2026-06-17",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 180,
"no": "180",
"mgmtNo": "260611029",
"registeredDate": "2026-06-11",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Biến dạng Chốt",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH61-22194A",
"partName": "CASE-FRONT DECO MAIN;PA+GF55%,SM-F976U,B",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Biến dạng Chốt",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-27",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-18",
"completedDate": "2026-06-17",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 181,
"no": "181",
"mgmtNo": "260611008",
"registeredDate": "2026-06-11",
"writtenBy": "lt.trang1",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Sứt mẻ GH98-51112B_INTOPS VIETNAM(DT1C)_QM26065339",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112B",
"partName": "ASSY CASE-REAR_ZB;SM-A276B,OPEN,BLUE",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Sứt mẻ",
"sampleQty": 20,
"defectQty": 2,
"defectRate": 10,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "ha.conghoat",
"approvalDate": "2026-07-03",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-18",
"completedDate": "2026-06-17",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 182,
"no": "182",
"mgmtNo": "260610089-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front Lỗi kênh OQC (Etc) _ GH98-49958A _ DT1C",
"occurPlace": "OQC (Etc)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "Lỗi kênh",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-15",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-13",
"tatDays": "3",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 183,
"no": "183",
"mgmtNo": "260610088-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front WPT Fail Outsourcing _ GH98-49958A _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958A",
"partName": "ASSY CASE-FRONT_A253D_ZK;SM-A253D,JPN,BL",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "WPT Fail",
"sampleQty": null,
"defectQty": 6,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-29",
"completedDate": "2026-06-29",
"tatDays": "19",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 184,
"no": "184",
"mgmtNo": "260610085-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Bẩn Main _ 20260609_002 _ Bẩn  Trong Rear _ GH98-51112D",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112D",
"partName": "ASSY CASE-REAR_LI;SM-A276B,OPEN,LIGHT PI",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Bẩn",
"sampleQty": null,
"defectQty": 3,
"defectRate": null,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-15",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 185,
"no": "185",
"mgmtNo": "260610084-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Ngoại quan (lớp in) Main _ 20260607_001 _ Tool Mask Case Rear _ GH98-51112A",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112A",
"partName": "ASSY CASE-REAR;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Ngoại quan (lớp in)",
"sampleQty": null,
"defectQty": 30,
"defectRate": null,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-15",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 186,
"no": "186",
"mgmtNo": "260610083-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Rear Bong sơn Main _ 20260606_001 _  Bong sơn thành Rear mặt C _ GH98-51112B",
"occurPlace": "Main",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51112B",
"partName": "ASSY CASE-REAR_ZB;SM-A276B,OPEN,BLUE",
"partGroup": "I/Molding Rear",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Bong sơn",
"sampleQty": null,
"defectQty": 30,
"defectRate": null,
"reason1": "Con người",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-16",
"tatDays": "6",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 187,
"no": "187",
"mgmtNo": "260610082-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "the.thuy",
"status": "Hoàn thành",
"plant": "SEVT",
"title": "SM-A276B I/Molding Front Burr Sub Tech _ 20260605_001 _ NG ngoại quan _ GH98-51170A",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51170A",
"partName": "ASSY CASE-FRONT_V3;SM-A276B,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-A27-5g",
"model": "SM-A276B_EUR_XX",
"defectDetails": "Burr",
"sampleQty": null,
"defectQty": 4,
"defectRate": null,
"reason1": "Vật liệu",
"reason2": "Đào tạo không tốt",
"inspector": "the.thuy",
"approver": "vanlong.le",
"approvalDate": "2026-07-01",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-15",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 188,
"no": "188",
"mgmtNo": "260610040-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-A253D I/Molding Front CNC Lẹm OQC (Etc) _ GH98-49958B _ DT1C",
"occurPlace": "OQC (Etc)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-49958B",
"partName": "ASSY CASE-FRONT_A253D_LB;SM-A253D,JPN,LI",
"partGroup": "I/Molding Front",
"project": "Galaxy-A25e-5g",
"model": "SM-A253D_JPN_DCM",
"defectDetails": "CNC Lẹm",
"sampleQty": null,
"defectQty": 1,
"defectRate": null,
"reason1": "Phương pháp",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-26",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-17",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 189,
"no": "189",
"mgmtNo": "260610028-VOC",
"registeredDate": "2026-06-10",
"writtenBy": "ngoc.pt2",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX730 I/Molding Front Cong vênh Outsourcing _ GH98-50649A _ DT1C",
"occurPlace": "Outsourcing",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-50649A",
"partName": "ASSY CASE-FRONT UK;EF-DX730,UK,PC+GF,BLA",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S11",
"model": "EF-DX730",
"defectDetails": "Cong vênh",
"sampleQty": null,
"defectQty": 9,
"defectRate": null,
"reason1": "Con người",
"reason2": "Kĩ năng thao tác không tốt",
"inspector": "tr.ngoc.duy",
"approver": "xuanhai.ph",
"approvalDate": "2026-06-25",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-17",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 190,
"no": "190",
"mgmtNo": "260610021",
"registeredDate": "2026-06-10",
"writtenBy": "tue.ptm",
"status": "Hoàn thành",
"plant": "SEV",
"title": "EF-DX710 I/Molding Front Mẻ Front",
"occurPlace": "IQC Fail (RMA)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-48567A",
"partName": "ASSY CASE-FRONT US;EF-DX710,OPEN,BLACK",
"partGroup": "I/Molding Front",
"project": "Galaxy-Tab-S9",
"model": "EF-DX710",
"defectDetails": "Mẻ Front",
"sampleQty": 20,
"defectQty": 2,
"defectRate": 10,
"reason1": "Môi trường",
"reason2": "Tạp chât / Dị vật",
"inspector": "tr.ngoc.duy",
"approver": "xuanhai.ph",
"approvalDate": "2026-06-25",
"issueYN": "N",
"claimYN": "N/A",
"reoccur3M": "N/A",
"dueDate": "2026-06-17",
"completedDate": "2026-06-15",
"tatDays": "5",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
},
{
"id": 191,
"no": "191",
"mgmtNo": "260610002",
"registeredDate": "2026-06-10",
"writtenBy": "ngoc.nt5",
"status": "Hoàn thành",
"plant": "SEV",
"title": "SM-F976U Deco Front Xước mặt A DT1C",
"occurPlace": "IQC Fail (preliminary inspection)",
"supplier": "Công Ty TNHH INTOPS Việt Nam",
"vendorGroup": "INTOPS",
"partCode": "GH98-51070A",
"partName": "ASSY DECO-FRONT DECO SUB;SM-F976U,VZW,BL",
"partGroup": "Deco Front",
"project": "Q8",
"model": "SM-F976U_NA_VZW",
"defectDetails": "Xước mặt A",
"sampleQty": 250,
"defectQty": 3,
"defectRate": 1.2,
"reason1": "Máy móc",
"reason2": "Đào tạo không tốt",
"inspector": "trung.tien",
"approver": "viet.toan",
"approvalDate": "2026-06-26",
"issueYN": "N",
"claimYN": "N",
"reoccur3M": "N",
"dueDate": "2026-06-17",
"completedDate": "2026-06-17",
"tatDays": "7",
"tatCompliance": "Y",
"transactionType": "Local",
"locatedCorp": "SEV"
}
];
/* ============ Constants & meta lookups ============ */
const STATUS_META = {
  'Hoàn thành':        { gloss:'Completed',               cls:'badge-complete' },
  'Đợi đối sách':      { gloss:'Awaiting countermeasure',  cls:'badge-pending'  },
  'Đợi duyệt':         { gloss:'Awaiting approval',        cls:'badge-review'   },
  'Đợi xét':           { gloss:'Awaiting review',          cls:'badge-review'   },
  'Rejected (xét)':    { gloss:'Rejected',                 cls:'badge-rejected' },
};
function statusMeta(s){ return STATUS_META[s] || { gloss: s || 'Unspecified', cls:'badge-unknown' }; }
const REASON_GLOSS = {
  'Máy móc':'Machine', 'Con người':'Man', 'Môi trường':'Environment',
  'Vật liệu':'Material', 'Phương pháp':'Method'
};
const STATUS_OPTIONS = ['Hoàn thành','Đợi đối sách','Đợi duyệt','Đợi xét','Rejected (xét)'];
const REASON_OPTIONS = ['Máy móc','Con người','Môi trường','Vật liệu','Phương pháp'];

const todayStr = () => new Date().toISOString().slice(0,10);
function daysUntil(dateStr){
  if(!dateStr) return null;
  const d = new Date(dateStr+'T00:00:00');
  const t = new Date(); t.setHours(0,0,0,0);
  return Math.round((d-t)/86400000);
}
function fmtDate(s){ return s || '—'; }
function esc(s){
  if(s===null||s===undefined) return '';
  return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

/* ============ Duplicate detection ============ */
// A record's identity fingerprint. Prefer the management number (unique in
// the source system); fall back to a composite key for rows that lack one.
function recordFingerprint(r){
  const mgmt = (r.mgmtNo || '').trim().toLowerCase();
  if(mgmt) return 'mn:'+mgmt;
  return ['fp', r.registeredDate, r.plant, r.partCode, r.title, r.defectQty]
    .map(v=>String(v||'').trim().toLowerCase()).join('|');
}

/* ============ i18n ============ */
const I18N = {
en: {
  appTitle:'TNP Defect Management System', appSubtitle:'INTOPS mechanical parts · consolidated defect & countermeasure tracker',
  searchPlaceholder:'Search title, part, model, mgmt no, MQIS code...',
  addFile:'Add file', exportCsv:'Export CSV', newDefect:'+ New defect',
  filters:'Filters', registeredDate:'Registered date', month:'Month', plant:'Plant',
  modelProject:'Model line / Project', model:'Model', partGroup:'Part group', defectCode:'Defect code (part code)',
  occurPlace:'Process / occurrence location', reason1:'Defect type (root cause)', status:'Countermeasure status',
  clearFilters:'Clear all filters',
  kpiTotal:'Total defects (filtered)', kpiTotalSub:'{n} in full database',
  kpiOpen:'Open corrective actions', kpiOpenSub:'{n} completed',
  kpiOverdue:'Overdue actions', kpiOverdueSub:'past deadline, not closed',
  kpiOnTime:'On-time closure rate', kpiOnTimeSub:'of {n} closed w/ due date',
  kpiToday:'Today', kpiTodaySub:'reference date for TAT calc',
  tabRecords:'Records', tabAnalysis:'Analysis', tabCorrective:'Corrective actions', tabTat:'TAT Monitoring', tabReject:'Rejected',
  tatHeading:'TAT Monitoring Dashboard', tatHint:'TAT due date = registration date + 7 days. Open records are grouped below by days remaining until TAT — closed records are excluded.',
  rejectHeading:'Rejected Defects Dashboard', rejectHint:'Records currently in Reject status only. Use this view to review why items were rejected and reassign a PIC to follow up.',
  rejectKpiTotal:'Total rejected', rejectKpiTotalSub:'{n} in full database', rejectByMarket:'Rejected by market', rejectByReason:'Rejected by defect type', rejectNone:'No rejected defects right now.',
  colMqis:'MQIS Code', mqisPlaceholder:'Enter MQIS code...', colPic:'PIC', picPlaceholder:'Assign PIC...', colFileLink:'CA File Link', fileLinkPlaceholder:'Paste file path or URL...', openFileLink:'Open', colRemark:'Remark', remarkPlaceholder:'Add remark...', copyPathTooltip:'Copy path to clipboard: {path}', openPathTooltip:'Open: {path}', copiedFeedback:'Copied! Paste it into File Explorer or an Open dialog.', copyFailedFeedback:'Could not copy -- select and copy the text manually.', nativeOpenLabel:'Make "Open File" launch the native app (advanced, Windows only)', nativeOpenHint:'By default, Open File uses your browser\'s file:// handling -- this works for PDFs and images, but for Office documents (Word/Excel/PowerPoint) most browsers will download a copy instead of opening the original. The one-time setup below installs a small helper (current-user only, no admin rights, fully removable) that makes Open File launch the original file directly in its normal desktop app instead.', downloadSetupBtn:'1. Download setup (.bat)', downloadRemoveBtn:'Remove setup (.bat)', nativeOpenStep2:'2. Run the downloaded file (double-click it), then come back and enable the switch below.', nativeOpenToggleLabel:'Use native app opening for Open File', nativeOpenNotSetUp:'(run the setup script first)',
  assignDefectCodeFirst:'Assign a Defect Code first', fileLinkSharedHint:'This link is shared by every record with Defect Code {code} — editing it here updates it everywhere, including future imports.', noDefectCodeForLink:'This record has no Defect Code, so no shared file link can be assigned.',
  tatKpiOverdue:'TAT overdue', tatKpiToday:'Due today', tatKpiOrange:'1 day left', tatKpiYellow:'2 days left', tatKpiGreen:'On track', tatKpiTracked:'Open records tracked', tatTrackedSub:'{n} open records tracked',
  tatSecOverdue:'🔴 Overdue (TAT passed)', tatSecToday:'🔴 Due today (TAT reached)', tatSecOrange:'🟠 1 day remaining', tatSecYellow:'🟡 2 days remaining', tatSecGreen:'🟢 On track (more than 2 days remaining)',
  tatNoOverdue:'No overdue TAT records.', tatNoToday:'Nothing due today.', tatNoOrange:'Nothing due in 1 day.', tatNoYellow:'Nothing due in 2 days.', tatNoGreen:'No records currently in this range.',
  tatColTatDue:'TAT due date', tatColDaysLeft:'Days remaining',
  tatOverdueBy:'{n}d overdue', tatDueTodayText:'Due today', tatDayLeft:'{n} day left', tatDaysLeft:'{n} days left',
  colMgmtNo:'Mgmt No', colDate:'Date', colPlant:'Plant', colModelProject:'Model / Project',
  colPartGroup:'Part group', colOccurLocation:'Occurrence location', colDefectType:'Defect type',
  colStatus:'Status', colDueDate:'Due date', colQty:'Qty', colDefectCode:'Defect code',
  recordCount:'{n} record', recordCountPlural:'{n} records',
  noMatchTitle:'No matching defects', noMatchBody:'Try widening your filters or clearing the search.',
  notAnalyzed:'Not analyzed',
  reasonTitle:'Defect type (root cause / 4M1E)', reasonHint:'Máy móc=Machine · Con người=Man · Môi trường=Environment · Vật liệu=Material · Phương pháp=Method',
  occurTitle:'Process / occurrence location', occurHint:'Where the defect was caught',
  partGroupTitle:'Part group', partGroupHint:'Component category',
  projectTitle:'Model line / project', projectHint:'Galaxy project family',
  monthTitle:'Monthly trend', monthHint:'Defects by registration month',
  statusTitle:'Countermeasure status', statusHint:'Current implementation status',
  caOverdue:'Overdue', caDueSoon:'Due within 3 days', caUpcoming:'Upcoming', caCompleted:'Completed',
  caNoOverdue:'Nothing overdue right now.', caNoSoon:'Nothing due imminently.', caNoUpcoming:'No further open items.',
  caNoDueDate:'No due date', caOverdueSuffix:'d overdue', caDueToday:'due today', caDaysLeft:'d left',
  caMoreCompleted:'+ {n} more completed — refine filters to see all.',
  fTitle:'Title', fModelProject:'Model / Project', fBasicModel:'Basic model', fPartGroup:'Part group',
  fPartCode:'Part code', fPartName:'Part name', fDefectDetails:'Defect details', fOccurPlace:'Process / occurrence location',
  fRootCause:'Root cause (4M1E)', fRootCauseDetail:'Root cause detail', fSampleQty:'Sample qty', fDefectQty:'Defect qty',
  fInspector:'Inspector', fApprover:'Approver', fNotYetAnalyzed:'Not yet analyzed',
  caTracking:'Corrective action tracking', fStatus:'Countermeasure status', fDueDateFinal:'Due date (final countermeasure)',
  fCompletedDate:'Completed date', fTat:'TAT (days)', fNotes:'Follow-up notes', fNotesPlaceholder:'Add follow-up notes...',
  saveChanges:'Save changes', close:'Close', removeEntry:'Remove entry',
  registerNewDefect:'Register new defect', mgmtNumber:'Management number', mgmtNumberPlaceholder:'auto-generated if blank',
  plantPlaceholder:'SEV / SEVT / SIEL...', modelProjectPlaceholder:'Galaxy-A...', partGroupPlaceholder:'I/Molding Front...',
  titlePlaceholder:'Short defect title', detailsPlaceholder:'Describe the defect...', occurPlaceholder:'IQC Fail, Outsourcing...',
  cancel:'Cancel', addDefectRecord:'Add defect record',
  addDailyFile:'Add daily TNP file',
  importIntro:'Upload one or more .xlsx/.xls/.csv exports in the same layout as the original TNP export. Records are matched against the whole database by management number (or, if blank, date + plant + part code + title). Matching rows are skipped automatically — only genuinely new records are appended, and nothing already stored is ever duplicated.',
  clickToChoose:'Click to choose file(s)', orDragDrop:'or drag and drop .xlsx / .xls / .csv here',
  importHistory:'Import history', noPreviousImports:'No previous imports yet.', clearLocalData:'Clear all imported data', clearLocalDataConfirm:'This will permanently delete all imported and manually-edited data stored in this browser (this cannot be undone). Continue?', clearLocalDataFailed:'Something went wrong clearing the data. Your browser may be blocking local storage access -- check your browser settings and try again.', localStorageHint:'All imported and edited data is saved automatically in this browser, so it will still be here after you close or refresh the page.',
  localRootLabel:'Local root folder for file links', localRootHint:'Browsers can only open local files from a page that is itself opened as a local file (file://), and only using an absolute path or a path relative to a shared root. Set a root folder here (e.g. C:\\Shared\\CorrectiveActions or \\\\server\\share\\CA) and then CA File Link values can just be a filename like 260702006.pdf -- clicking the copy button will combine the two automatically and copy the full path.', localRootPlaceholder:'e.g. C:\\Shared\\CorrectiveActions', saveRootBtn:'Save folder', localRootSaved:'Saved.', resolvesTo:'Copies: {path}',
  failedImport:'failed', added:'added', duplicatesSkipped:'duplicate', duplicatesSkippedPlural:'duplicates', ofTotal:'of',
  readingFiles:'Reading {n} file(s)...', importFailed:'Import failed:',
  addedRecords:'Added', newRecordWord:'new record', newRecordWordPlural:'new records', skippedWord:'skipped',
  rowsScanned:'rows scanned', rowScanned:'row scanned',
  importResultLine:'Added {added} new · Updated {updated} existing · {unchanged} unchanged · {total} rows scanned',
  historyLineV2:'{added} added, {updated} updated, {unchanged} unchanged (of {total})',
  importIntroV2:'Upload one or more .xlsx/.xls/.csv exports in the same layout as the original TNP export. Each row is matched against the whole database by management number (or, if blank, date + plant + part code + title). A matching row updates that record in place with the latest status, due date, and other fields from the file — it never creates a duplicate. Rows with no match are added as new records.',
  navHome:'← Home',
  marketsHeading:'Markets', marketsHint:'Click a market to view its detailed dashboard',
  homeRejectHeading:'Rejected Defects', homeRejectTotalLabel:'Total rejected', homeRejectViewAll:'View all in Reject dashboard →', homeRejectNone:'No rejected defects right now.', homeRejectHint:'Records currently in Reject status, across all markets.',
  marketOverviewLine:'{markets} markets · {total} total defects · {overdue} overdue across all sites',
  marketTotal:'Total defects', marketPending:'Pending', marketCompleted:'Completed', marketOverdue:'Overdue',
},
ko: {
  appTitle:'TNP 결함 관리 시스템', appSubtitle:'INTOPS 기계 부품 · 통합 결함 및 대책 추적기',
  searchPlaceholder:'제목, 부품, 모델, 관리번호, MQIS 코드 검색...',
  addFile:'파일 추가', exportCsv:'CSV 내보내기', newDefect:'+ 신규 결함',
  filters:'필터', registeredDate:'등록일', month:'월', plant:'공장',
  modelProject:'모델 라인 / 프로젝트', model:'모델', partGroup:'부품 그룹', defectCode:'결함 코드(부품 코드)',
  occurPlace:'공정 / 발생 위치', reason1:'결함 유형(근본 원인)', status:'대책 상태',
  clearFilters:'모든 필터 지우기',
  kpiTotal:'전체 결함(필터 적용)', kpiTotalSub:'전체 데이터베이스 {n}건',
  kpiOpen:'진행 중인 대책', kpiOpenSub:'{n}건 완료',
  kpiOverdue:'기한 초과 대책', kpiOverdueSub:'기한 경과, 미종결',
  kpiOnTime:'정시 종결률', kpiOnTimeSub:'기한 있는 완료건 {n}건 중',
  kpiToday:'오늘', kpiTodaySub:'TAT 계산 기준일',
  tabRecords:'기록', tabAnalysis:'분석', tabCorrective:'시정 조치', tabTat:'TAT 모니터링', tabReject:'반려(Reject)',
  tatHeading:'TAT 모니터링 대시보드', tatHint:'TAT 완료 기한 = 등록일 + 7일. 진행 중인 항목만 TAT 잔여일 기준으로 아래에 그룹화됩니다 (완료 항목 제외).',
  rejectHeading:'반려(Reject) 대시보드', rejectHint:'현재 반려(Reject) 상태인 건만 표시합니다. 반려 사유를 검토하고 담당자(PIC)를 배정해 후속 조치를 진행하세요.',
  rejectKpiTotal:'총 반려 건수', rejectKpiTotalSub:'전체 {n}건 중', rejectByMarket:'법인별 반려 현황', rejectByReason:'결함 유형별 반려 현황', rejectNone:'현재 반려된 결함이 없습니다.',
  colMqis:'MQIS 코드', mqisPlaceholder:'MQIS 코드 입력...', colPic:'담당자(PIC)', picPlaceholder:'담당자 지정...', colFileLink:'대책 파일 링크', fileLinkPlaceholder:'파일 경로 또는 URL 붙여넣기...', openFileLink:'열기', colRemark:'비고', remarkPlaceholder:'비고 입력...', copyPathTooltip:'경로를 클립보드에 복사: {path}', openPathTooltip:'열기: {path}', copiedFeedback:'복사되었습니다! 파일 탐색기나 열기 대화상자에 붙여넣으세요.', copyFailedFeedback:'복사하지 못했습니다 -- 텍스트를 직접 선택해서 복사해주세요.', nativeOpenLabel:'"파일 열기"를 원래 앱으로 실행 (고급, Windows 전용)', nativeOpenHint:'기본적으로 파일 열기를 클릭하면 브라우저의 file:// 처리 방식이 사용됩니다 -- PDF나 이미지에는 잘 동작하지만, Office 문서(Word/Excel/PowerPoint)는 대부분의 브라우저에서 원본을 여는 대신 사본을 다운로드합니다. 아래의 1회성 설정을 실행하면 (현재 사용자 계정에만 적용, 관리자 권한 불필요, 언제든 제거 가능) 파일 열기 클릭 시 원본 파일이 해당 기본 데스크톱 앱에서 바로 열리도록 도와주는 작은 도우미가 설치됩니다.', downloadSetupBtn:'1. 설정 파일 다운로드 (.bat)', downloadRemoveBtn:'설정 제거 (.bat)', nativeOpenStep2:'2. 다운로드한 파일을 실행한 후 (더블클릭), 아래 스위치를 켜주세요.', nativeOpenToggleLabel:'파일 열기에 대해 원래 앱으로 열기 사용', nativeOpenNotSetUp:'(먼저 설정 파일을 실행하세요)',
  assignDefectCodeFirst:'먼저 불량 코드를 지정하세요', fileLinkSharedHint:'이 링크는 불량 코드 {code}를 가진 모든 레코드가 공유합니다 — 여기서 수정하면 향후 가져오기를 포함해 전체에 반영됩니다.', noDefectCodeForLink:'이 레코드에는 불량 코드가 없어 공유 파일 링크를 지정할 수 없습니다.',
  tatKpiOverdue:'TAT 초과', tatKpiToday:'오늘 마감', tatKpiOrange:'1일 남음', tatKpiYellow:'2일 남음', tatKpiGreen:'정상 진행', tatKpiTracked:'추적 중인 진행 항목', tatTrackedSub:'진행 중인 항목 {n}건 추적 중',
  tatSecOverdue:'🔴 기한 초과 (TAT 경과)', tatSecToday:'🔴 오늘 마감 (TAT 도달)', tatSecOrange:'🟠 1일 남음', tatSecYellow:'🟡 2일 남음', tatSecGreen:'🟢 정상 진행 (2일 초과 남음)',
  tatNoOverdue:'TAT 초과 항목이 없습니다.', tatNoToday:'오늘 마감인 항목이 없습니다.', tatNoOrange:'1일 후 마감인 항목이 없습니다.', tatNoYellow:'2일 후 마감인 항목이 없습니다.', tatNoGreen:'해당 범위에 항목이 없습니다.',
  tatColTatDue:'TAT 완료 기한', tatColDaysLeft:'잔여 일수',
  tatOverdueBy:'{n}일 초과', tatDueTodayText:'오늘 마감', tatDayLeft:'{n}일 남음', tatDaysLeft:'{n}일 남음',
  colMgmtNo:'관리번호', colDate:'일자', colPlant:'공장', colModelProject:'모델 / 프로젝트',
  colPartGroup:'부품 그룹', colOccurLocation:'발생 위치', colDefectType:'결함 유형',
  colStatus:'상태', colDueDate:'완료 기한', colQty:'수량', colDefectCode:'결함 코드',
  recordCount:'{n}건', recordCountPlural:'{n}건',
  noMatchTitle:'일치하는 결함 없음', noMatchBody:'필터 범위를 넓히거나 검색어를 지워보세요.',
  notAnalyzed:'미분석',
  reasonTitle:'결함 유형(근본 원인 / 4M1E)', reasonHint:'Máy móc=설비 · Con người=사람 · Môi trường=환경 · Vật liệu=자재 · Phương pháp=방법',
  occurTitle:'공정 / 발생 위치', occurHint:'결함이 발견된 위치',
  partGroupTitle:'부품 그룹', partGroupHint:'구성품 분류',
  projectTitle:'모델 라인 / 프로젝트', projectHint:'Galaxy 프로젝트 계열',
  monthTitle:'월별 추이', monthHint:'등록월 기준 결함 발생 추이',
  statusTitle:'대책 상태', statusHint:'현재 이행 상태',
  caOverdue:'기한 초과', caDueSoon:'3일 이내 마감', caUpcoming:'예정', caCompleted:'완료',
  caNoOverdue:'현재 기한 초과 건이 없습니다.', caNoSoon:'임박한 마감 건이 없습니다.', caNoUpcoming:'추가 진행 중인 건이 없습니다.',
  caNoDueDate:'기한 없음', caOverdueSuffix:'일 초과', caDueToday:'오늘 마감', caDaysLeft:'일 남음',
  caMoreCompleted:'완료 {n}건 더 있음 — 필터를 조정해 모두 확인하세요.',
  fTitle:'제목', fModelProject:'모델 / 프로젝트', fBasicModel:'기본 모델', fPartGroup:'부품 그룹',
  fPartCode:'부품 코드', fPartName:'부품명', fDefectDetails:'결함 상세', fOccurPlace:'공정 / 발생 위치',
  fRootCause:'근본 원인(4M1E)', fRootCauseDetail:'근본 원인 상세', fSampleQty:'샘플 수량', fDefectQty:'결함 수량',
  fInspector:'검사자', fApprover:'승인자', fNotYetAnalyzed:'미분석',
  caTracking:'시정 조치 추적', fStatus:'대책 상태', fDueDateFinal:'완료 기한(최종 대책)',
  fCompletedDate:'완료일', fTat:'TAT(일)', fNotes:'후속 조치 메모', fNotesPlaceholder:'후속 조치 메모 추가...',
  saveChanges:'변경 사항 저장', close:'닫기', removeEntry:'항목 삭제',
  registerNewDefect:'신규 결함 등록', mgmtNumber:'관리번호', mgmtNumberPlaceholder:'비워두면 자동 생성',
  plantPlaceholder:'SEV / SEVT / SIEL...', modelProjectPlaceholder:'Galaxy-A...', partGroupPlaceholder:'I/Molding Front...',
  titlePlaceholder:'결함 제목 (간단히)', detailsPlaceholder:'결함 내용을 설명하세요...', occurPlaceholder:'IQC Fail, Outsourcing...',
  cancel:'취소', addDefectRecord:'결함 기록 추가',
  addDailyFile:'일일 TNP 파일 추가',
  importIntro:'원본 TNP 내보내기와 동일한 형식의 .xlsx/.xls/.csv 파일을 업로드하세요. 레코드는 관리번호(없으면 일자 + 공장 + 부품코드 + 제목)를 기준으로 전체 데이터베이스와 대조됩니다. 일치하는 행은 자동으로 건너뛰며, 신규 레코드만 추가되고 기존 데이터는 중복 저장되지 않습니다.',
  clickToChoose:'클릭하여 파일 선택', orDragDrop:'또는 .xlsx / .xls / .csv 파일을 여기로 드래그하세요',
  importHistory:'가져오기 이력', noPreviousImports:'이전 가져오기 이력이 없습니다.', clearLocalData:'가져온 데이터 전체 삭제', clearLocalDataConfirm:'이 브라우저에 저장된 가져오기/수정 데이터가 모두 영구적으로 삭제됩니다 (복구 불가). 계속하시겠습니까?', clearLocalDataFailed:'데이터를 삭제하는 중 문제가 발생했습니다. 브라우저가 로컬 저장소 접근을 차단하고 있을 수 있습니다 -- 브라우저 설정을 확인한 후 다시 시도해주세요.', localStorageHint:'가져오거나 수정한 모든 데이터는 이 브라우저에 자동으로 저장되므로, 페이지를 닫거나 새로고침해도 그대로 남아 있습니다.',
  localRootLabel:'파일 링크용 로컬 루트 폴더', localRootHint:'브라우저는 페이지 자체가 로컬 파일(file://)로 열려 있을 때만, 그리고 절대 경로이거나 공유 루트 기준 상대 경로일 때만 로컬 파일을 열 수 있습니다. 여기에 루트 폴더를 설정하면 (예: C:\\Shared\\CorrectiveActions 또는 \\\\server\\share\\CA) CA 파일 링크에는 260702006.pdf 처럼 파일명만 입력해도 복사 버튼을 누르면 두 경로가 자동으로 합쳐져 전체 경로가 복사됩니다.', localRootPlaceholder:'예: C:\\Shared\\CorrectiveActions', saveRootBtn:'폴더 저장', localRootSaved:'저장되었습니다.', resolvesTo:'복사할 경로: {path}',
  failedImport:'실패', added:'추가됨', duplicatesSkipped:'중복', duplicatesSkippedPlural:'중복', ofTotal:'/',
  readingFiles:'{n}개 파일 읽는 중...', importFailed:'가져오기 실패:',
  addedRecords:'추가됨', newRecordWord:'신규 레코드', newRecordWordPlural:'신규 레코드', skippedWord:'건너뜀',
  rowsScanned:'행 스캔됨', rowScanned:'행 스캔됨',
  importResultLine:'신규 {added}건 추가 · 기존 {updated}건 갱신 · {unchanged}건 변경 없음 · 총 {total}행 스캔',
  historyLineV2:'{added}건 추가, {updated}건 갱신, {unchanged}건 변경 없음 (총 {total}건)',
  importIntroV2:'원본 TNP 양식과 동일한 형식의 .xlsx/.xls/.csv 파일을 하나 이상 업로드하세요. 각 행은 관리번호(없을 경우 등록일+법인+부품코드+제목 조합)를 기준으로 전체 데이터베이스와 대조됩니다. 일치하는 행이 있으면 해당 레코드를 파일의 최신 상태·마감일 등으로 즉시 갱신하며, 중복을 생성하지 않습니다. 일치하지 않는 행만 신규 레코드로 추가됩니다.',
  navHome:'← 홈',
  marketsHeading:'법인별 현황', marketsHint:'법인을 클릭하면 상세 대시보드로 이동합니다',
  homeRejectHeading:'반려(Reject) 결함', homeRejectTotalLabel:'총 반려 건수', homeRejectViewAll:'반려 대시보드에서 전체 보기 →', homeRejectNone:'현재 반려된 결함이 없습니다.', homeRejectHint:'전체 법인 중 현재 반려(Reject) 상태인 건입니다.',
  marketOverviewLine:'{markets}개 법인 · 전체 불량 {total}건 · 전체 기한초과 {overdue}건',
  marketTotal:'전체 불량', marketPending:'대기 중', marketCompleted:'완료', marketOverdue:'기한 초과',
},
vi: {
  appTitle:'Hệ thống Quản lý Lỗi TNP', appSubtitle:'Linh kiện cơ khí INTOPS · theo dõi lỗi và biện pháp khắc phục tổng hợp',
  searchPlaceholder:'Tìm tiêu đề, linh kiện, model, số quản lý, mã MQIS...',
  addFile:'Thêm file', exportCsv:'Xuất CSV', newDefect:'+ Lỗi mới',
  filters:'Bộ lọc', registeredDate:'Ngày đăng ký', month:'Tháng', plant:'Nhà máy',
  modelProject:'Dòng model / Dự án', model:'Model', partGroup:'Nhóm linh kiện', defectCode:'Mã lỗi (mã linh kiện)',
  occurPlace:'Công đoạn / Vị trí phát sinh', reason1:'Loại lỗi (nguyên nhân gốc)', status:'Trạng thái đối sách',
  clearFilters:'Xoá tất cả bộ lọc',
  kpiTotal:'Tổng số lỗi (đã lọc)', kpiTotalSub:'{n} trong toàn bộ cơ sở dữ liệu',
  kpiOpen:'Đối sách đang xử lý', kpiOpenSub:'{n} đã hoàn thành',
  kpiOverdue:'Đối sách quá hạn', kpiOverdueSub:'quá hạn, chưa đóng',
  kpiOnTime:'Tỷ lệ đóng đúng hạn', kpiOnTimeSub:'trong {n} đã đóng có hạn xử lý',
  kpiToday:'Hôm nay', kpiTodaySub:'ngày tham chiếu tính TAT',
  tabRecords:'Danh sách', tabAnalysis:'Phân tích', tabCorrective:'Hành động khắc phục', tabTat:'Giám sát TAT', tabReject:'Từ chối',
  tatHeading:'Bảng giám sát TAT', tatHint:'Hạn TAT = ngày đăng ký + 7 ngày. Các mục đang xử lý được nhóm bên dưới theo số ngày còn lại đến hạn TAT — mục đã hoàn thành không hiển thị.',
  rejectHeading:'Bảng theo dõi lỗi bị từ chối', rejectHint:'Chỉ hiển thị các bản ghi đang ở trạng thái Từ chối (Reject). Dùng màn hình này để xem lý do bị từ chối và phân công người phụ trách (PIC) xử lý tiếp.',
  rejectKpiTotal:'Tổng số bị từ chối', rejectKpiTotalSub:'trong tổng số {n}', rejectByMarket:'Từ chối theo thị trường', rejectByReason:'Từ chối theo loại lỗi', rejectNone:'Hiện không có lỗi nào bị từ chối.',
  colMqis:'Mã MQIS', mqisPlaceholder:'Nhập mã MQIS...', colPic:'PIC', picPlaceholder:'Gán người phụ trách...', colFileLink:'File đối sách', fileLinkPlaceholder:'Dán đường dẫn file hoặc URL...', openFileLink:'Mở', colRemark:'Ghi chú', remarkPlaceholder:'Nhập ghi chú...', copyPathTooltip:'Sao chép đường dẫn: {path}', openPathTooltip:'Mở: {path}', copiedFeedback:'Đã sao chép! Dán vào File Explorer hoặc hộp thoại Open.', copyFailedFeedback:'Không sao chép được -- hãy chọn và sao chép văn bản theo cách thủ công.', nativeOpenLabel:'Cho "Mở file" khởi chạy ứng dụng gốc (nâng cao, chỉ Windows)', nativeOpenHint:'Theo mặc định, nhấn Mở file sẽ dùng cơ chế file:// của trình duyệt -- cách này hoạt động tốt với PDF và hình ảnh, nhưng với tài liệu Office (Word/Excel/PowerPoint) hầu hết trình duyệt sẽ tải về một bản sao thay vì mở file gốc. Thiết lập một lần dưới đây sẽ cài một trình trợ giúp nhỏ (chỉ áp dụng cho tài khoản hiện tại, không cần quyền quản trị, có thể gỡ bỏ bất cứ lúc nào) để nút Mở file sẽ khởi chạy file gốc trực tiếp trong ứng dụng desktop mặc định của nó.', downloadSetupBtn:'1. Tải file thiết lập (.bat)', downloadRemoveBtn:'Gỡ bỏ thiết lập (.bat)', nativeOpenStep2:'2. Chạy file vừa tải (nhấp đúp), sau đó quay lại bật công tắc bên dưới.', nativeOpenToggleLabel:'Dùng ứng dụng gốc cho Mở file', nativeOpenNotSetUp:'(hãy chạy file thiết lập trước)',
  assignDefectCodeFirst:'Vui lòng gán Mã lỗi trước', fileLinkSharedHint:'Liên kết này được chia sẻ bởi mọi bản ghi có Mã lỗi {code} — chỉnh sửa ở đây sẽ áp dụng cho tất cả, kể cả các lần nhập dữ liệu sau này.', noDefectCodeForLink:'Bản ghi này không có Mã lỗi, do đó không thể gán liên kết file dùng chung.',
  tatKpiOverdue:'TAT quá hạn', tatKpiToday:'Đến hạn hôm nay', tatKpiOrange:'Còn 1 ngày', tatKpiYellow:'Còn 2 ngày', tatKpiGreen:'Đúng tiến độ', tatKpiTracked:'Số mục đang theo dõi', tatTrackedSub:'Đang theo dõi {n} mục đang xử lý',
  tatSecOverdue:'🔴 Quá hạn (đã qua TAT)', tatSecToday:'🔴 Đến hạn hôm nay (đạt TAT)', tatSecOrange:'🟠 Còn 1 ngày', tatSecYellow:'🟡 Còn 2 ngày', tatSecGreen:'🟢 Đúng tiến độ (còn hơn 2 ngày)',
  tatNoOverdue:'Không có mục nào quá hạn TAT.', tatNoToday:'Không có mục nào đến hạn hôm nay.', tatNoOrange:'Không có mục nào đến hạn trong 1 ngày.', tatNoYellow:'Không có mục nào đến hạn trong 2 ngày.', tatNoGreen:'Hiện không có mục nào trong khoảng này.',
  tatColTatDue:'Hạn TAT', tatColDaysLeft:'Số ngày còn lại',
  tatOverdueBy:'quá hạn {n} ngày', tatDueTodayText:'Đến hạn hôm nay', tatDayLeft:'còn {n} ngày', tatDaysLeft:'còn {n} ngày',
  colMgmtNo:'Số quản lý', colDate:'Ngày', colPlant:'Nhà máy', colModelProject:'Model / Dự án',
  colPartGroup:'Nhóm linh kiện', colOccurLocation:'Vị trí phát sinh', colDefectType:'Loại lỗi',
  colStatus:'Trạng thái', colDueDate:'Hạn xử lý', colQty:'SL', colDefectCode:'Mã lỗi',
  recordCount:'{n} bản ghi', recordCountPlural:'{n} bản ghi',
  noMatchTitle:'Không có lỗi phù hợp', noMatchBody:'Hãy nới rộng bộ lọc hoặc xoá từ khoá tìm kiếm.',
  notAnalyzed:'Chưa phân tích',
  reasonTitle:'Loại lỗi (nguyên nhân gốc / 4M1E)', reasonHint:'Máy móc=Machine · Con người=Man · Môi trường=Environment · Vật liệu=Material · Phương pháp=Method',
  occurTitle:'Công đoạn / Vị trí phát sinh', occurHint:'Nơi phát hiện lỗi',
  partGroupTitle:'Nhóm linh kiện', partGroupHint:'Phân loại linh kiện',
  projectTitle:'Dòng model / dự án', projectHint:'Dòng dự án Galaxy',
  monthTitle:'Xu hướng theo tháng', monthHint:'Số lỗi theo tháng đăng ký',
  statusTitle:'Trạng thái đối sách', statusHint:'Tình trạng triển khai hiện tại',
  caOverdue:'Quá hạn', caDueSoon:'Sắp đến hạn (3 ngày)', caUpcoming:'Sắp tới', caCompleted:'Hoàn thành',
  caNoOverdue:'Hiện không có mục nào quá hạn.', caNoSoon:'Không có mục nào sắp đến hạn.', caNoUpcoming:'Không còn mục nào đang mở.',
  caNoDueDate:'Không có hạn xử lý', caOverdueSuffix:' ngày quá hạn', caDueToday:'đến hạn hôm nay', caDaysLeft:' ngày còn lại',
  caMoreCompleted:'+ {n} mục hoàn thành khác — hãy tinh chỉnh bộ lọc để xem tất cả.',
  fTitle:'Tiêu đề', fModelProject:'Model / Dự án', fBasicModel:'Model cơ bản', fPartGroup:'Nhóm linh kiện',
  fPartCode:'Mã linh kiện', fPartName:'Tên linh kiện', fDefectDetails:'Chi tiết lỗi', fOccurPlace:'Công đoạn / Vị trí phát sinh',
  fRootCause:'Nguyên nhân gốc (4M1E)', fRootCauseDetail:'Chi tiết nguyên nhân gốc', fSampleQty:'SL mẫu', fDefectQty:'SL lỗi',
  fInspector:'Người kiểm tra', fApprover:'Người phê duyệt', fNotYetAnalyzed:'Chưa phân tích',
  caTracking:'Theo dõi hành động khắc phục', fStatus:'Trạng thái đối sách', fDueDateFinal:'Hạn xử lý (đối sách cuối cùng)',
  fCompletedDate:'Ngày hoàn thành', fTat:'TAT (ngày)', fNotes:'Ghi chú theo dõi', fNotesPlaceholder:'Thêm ghi chú theo dõi...',
  saveChanges:'Lưu thay đổi', close:'Đóng', removeEntry:'Xoá mục này',
  registerNewDefect:'Đăng ký lỗi mới', mgmtNumber:'Số quản lý', mgmtNumberPlaceholder:'để trống sẽ tự tạo',
  plantPlaceholder:'SEV / SEVT / SIEL...', modelProjectPlaceholder:'Galaxy-A...', partGroupPlaceholder:'I/Molding Front...',
  titlePlaceholder:'Tiêu đề ngắn gọn', detailsPlaceholder:'Mô tả lỗi...', occurPlaceholder:'IQC Fail, Outsourcing...',
  cancel:'Huỷ', addDefectRecord:'Thêm bản ghi lỗi',
  addDailyFile:'Thêm file TNP hàng ngày',
  importIntro:'Tải lên một hoặc nhiều file .xlsx/.xls/.csv có cùng bố cục với file TNP gốc. Bản ghi được đối chiếu với toàn bộ cơ sở dữ liệu theo số quản lý (hoặc nếu trống, theo ngày + nhà máy + mã linh kiện + tiêu đề). Các dòng trùng khớp sẽ tự động bị bỏ qua — chỉ những bản ghi thực sự mới được thêm vào, không có dữ liệu nào bị trùng lặp.',
  clickToChoose:'Nhấp để chọn file', orDragDrop:'hoặc kéo thả file .xlsx / .xls / .csv vào đây',
  importHistory:'Lịch sử nhập file', noPreviousImports:'Chưa có lần nhập file nào trước đây.', clearLocalData:'Xoá toàn bộ dữ liệu đã nhập', clearLocalDataConfirm:'Thao tác này sẽ xoá vĩnh viễn toàn bộ dữ liệu đã nhập/chỉnh sửa được lưu trong trình duyệt này (không thể hoàn tác). Tiếp tục?', clearLocalDataFailed:'Đã xảy ra lỗi khi xoá dữ liệu. Trình duyệt của bạn có thể đang chặn quyền truy cập bộ nhớ cục bộ -- hãy kiểm tra cài đặt trình duyệt và thử lại.', localStorageHint:'Toàn bộ dữ liệu đã nhập hoặc chỉnh sửa được tự động lưu trong trình duyệt này, nên vẫn còn nguyên sau khi bạn đóng hoặc tải lại trang.',
  localRootLabel:'Thư mục gốc cục bộ cho liên kết file', localRootHint:'Trình duyệt chỉ có thể mở file cục bộ khi trang này được mở dưới dạng file cục bộ (file://), và chỉ với đường dẫn tuyệt đối hoặc đường dẫn tương đối theo thư mục gốc dùng chung. Đặt thư mục gốc tại đây (vd: C:\\Shared\\CorrectiveActions hoặc \\\\server\\share\\CA), sau đó ô File đối sách chỉ cần nhập tên file như 260702006.pdf -- nhấn nút sao chép sẽ tự động ghép hai đường dẫn và sao chép đường dẫn đầy đủ.', localRootPlaceholder:'vd: C:\\Shared\\CorrectiveActions', saveRootBtn:'Lưu thư mục', localRootSaved:'Đã lưu.', resolvesTo:'Sao chép: {path}',
  failedImport:'lỗi', added:'đã thêm', duplicatesSkipped:'bản trùng', duplicatesSkippedPlural:'bản trùng', ofTotal:'trong tổng',
  readingFiles:'Đang đọc {n} file...', importFailed:'Nhập file thất bại:',
  addedRecords:'Đã thêm', newRecordWord:'bản ghi mới', newRecordWordPlural:'bản ghi mới', skippedWord:'đã bỏ qua',
  rowsScanned:'dòng đã quét', rowScanned:'dòng đã quét',
  importResultLine:'Đã thêm {added} mới · Đã cập nhật {updated} bản ghi · {unchanged} không đổi · đã quét {total} dòng',
  historyLineV2:'{added} đã thêm, {updated} đã cập nhật, {unchanged} không đổi (trên tổng {total})',
  importIntroV2:'Tải lên một hoặc nhiều file .xlsx/.xls/.csv có cùng định dạng với file TNP gốc. Mỗi dòng sẽ được đối chiếu với toàn bộ cơ sở dữ liệu theo số quản lý (hoặc, nếu để trống, theo ngày + nhà máy + mã linh kiện + tiêu đề). Nếu khớp, bản ghi đó sẽ được cập nhật ngay với trạng thái, hạn xử lý và các thông tin mới nhất từ file — không bao giờ tạo bản trùng. Chỉ những dòng không khớp mới được thêm làm bản ghi mới.',
  navHome:'← Trang chủ',
  marketsHeading:'Theo nhà máy', marketsHint:'Nhấp vào một nhà máy để xem bảng chi tiết',
  homeRejectHeading:'Lỗi bị từ chối', homeRejectTotalLabel:'Tổng số bị từ chối', homeRejectViewAll:'Xem tất cả trong bảng Từ chối →', homeRejectNone:'Hiện không có lỗi nào bị từ chối.', homeRejectHint:'Các bản ghi đang ở trạng thái Từ chối, trên toàn bộ nhà máy.',
  marketOverviewLine:'{markets} nhà máy · tổng {total} lỗi · {overdue} lỗi quá hạn trên toàn hệ thống',
  marketTotal:'Tổng số lỗi', marketPending:'Đang xử lý', marketCompleted:'Đã hoàn thành', marketOverdue:'Quá hạn',
},
};
function t(key){
  const dict = I18N[state.lang] || I18N.en;
  return (dict && dict[key]!==undefined) ? dict[key] : (I18N.en[key]!==undefined ? I18N.en[key] : key);
}
function tf(key, vars){
  let s = t(key);
  Object.keys(vars||{}).forEach(k=>{ s = s.replace('{'+k+'}', vars[k]); });
  return s;
}

/* ============ State ============ */
const state = {
  overrides: {},        // id -> partial patch for base records
  newRecords: [],        // all imported/added records (base file + daily imports + manual adds)
  importLog: [],         // history of import batches: {id, fileName, importedAt, added, duplicates, total}
  lang: 'en',            // ui language: 'en' | 'ko' | 'vi'
  view: 'home',          // 'home' (market cards) | 'dashboard' (existing filtered sidebar+tabs view)
  filters: {
    search:'', dateFrom:'', dateTo:'',
    plant:new Set(), project:new Set(), partGroup:new Set(), model:new Set(),
    occurPlace:new Set(), reason1:new Set(), status:new Set(), month:new Set(), defectCode:new Set()
  },
  sortKey:'registeredDate', sortDir:'desc',
  activeTab:'records',
  drawerId:null,
  localRoot: '',   // optional local root folder, used to resolve relative file-link paths
  defectCodeLinks: {}, // Defect Code (Part Code) -> file link string, shared across every record with that code
  useNativeOpen: false, // once the one-time Windows helper is installed, Open File launches the native app instead of downloading
};

/* ============ Storage: IndexedDB (primary) with localStorage fallback ============ */
// Everything imported or manually edited lives in the browser's own storage
// for this origin -- no network, no account, no cloud service. This used to
// be plain localStorage, which caps out around 5-10MB per origin in most
// browsers; a growing history of daily imports can realistically approach
// that limit over time. IndexedDB has a much larger practical quota (usually
// hundreds of MB or more, tied to available disk space) and stores actual
// JS objects directly rather than JSON strings, so it's now the primary
// store. localStorage is kept only as an automatic-migration source (for
// anyone who already had data saved there) and as a fallback for the rare
// case IndexedDB itself is unavailable or blocked.
const LS_KEYS = {
  overrides: 'tnp_dms_overrides_v1',
  newRecords: 'tnp_dms_new_records_v1',
  importLog: 'tnp_dms_import_log_v1',
  lang: 'tnp_dms_lang_v1',
  localRoot: 'tnp_dms_local_root_v1',
  defectCodeLinks: 'tnp_dms_defect_code_links_v1',
  useNativeOpen: 'tnp_dms_use_native_open_v1',
};
const IDB_NAME = 'tnp_dms_db';
const IDB_STORE = 'kv';
let idbConnPromise = null;
function openIdb(){
  if(idbConnPromise) return idbConnPromise;
  idbConnPromise = new Promise((resolve, reject)=>{
    if(!window.indexedDB){ reject(new Error('IndexedDB is not available in this browser.')); return; }
    let req;
    try{ req = indexedDB.open(IDB_NAME, 1); }
    catch(e){ reject(e); return; }
    req.onupgradeneeded = (e)=>{
      const db = e.target.result;
      if(!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
    };
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error || new Error('Could not open IndexedDB.'));
    req.onblocked = ()=> reject(new Error('IndexedDB open was blocked (another tab may be holding an old version open).'));
  });
  return idbConnPromise;
}
function idbGet(key){
  return openIdb().then(db => new Promise((resolve, reject)=>{
    const tx = db.transaction(IDB_STORE, 'readonly');
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error);
  }));
}
function idbSet(key, value){
  return openIdb().then(db => new Promise((resolve, reject)=>{
    const tx = db.transaction(IDB_STORE, 'readwrite');
    const req = tx.objectStore(IDB_STORE).put(value, key);
    req.onsuccess = ()=> resolve();
    req.onerror = ()=> reject(req.error);
  }));
}
function idbDelete(key){
  return openIdb().then(db => new Promise((resolve, reject)=>{
    const tx = db.transaction(IDB_STORE, 'readwrite');
    const req = tx.objectStore(IDB_STORE).delete(key);
    req.onsuccess = ()=> resolve();
    req.onerror = ()=> reject(req.error);
  }));
}
// Reads one persisted value. Tries IndexedDB first; if it has nothing for
// this key but an older localStorage copy exists (pre-IndexedDB installs),
// that value is migrated into IndexedDB on the spot and the old localStorage
// key is removed, so the migration only ever happens once per key.
async function loadPersistedValue(key, isJSON){
  try{
    const idbVal = await idbGet(key);
    if(idbVal !== undefined) return idbVal;
  }catch(e){ console.error('IndexedDB read failed for', key, e); }
  // Not in IndexedDB yet -- check for a legacy localStorage copy to migrate.
  try{
    const raw = localStorage.getItem(key);
    if(raw !== null){
      const parsed = isJSON ? JSON.parse(raw) : raw;
      try{ await idbSet(key, parsed); localStorage.removeItem(key); }
      catch(e){ /* migration best-effort; keep using the localStorage value either way */ }
      return parsed;
    }
  }catch(e){ console.error('localStorage read failed for', key, e); }
  return undefined;
}
// Saves one value, preferring IndexedDB; falls back to localStorage only if
// IndexedDB itself is unavailable, so data still persists somehow.
async function savePersistedValue(key, value, isJSON){
  try{
    await idbSet(key, value);
    return true;
  }catch(e){
    console.error('IndexedDB write failed for', key, '-- falling back to localStorage:', e);
    try{
      localStorage.setItem(key, isJSON ? JSON.stringify(value) : value);
      return true;
    }catch(e2){
      console.error('localStorage fallback also failed for', key, e2);
      return false;
    }
  }
}
async function deletePersistedValue(key){
  let ok = true;
  try{ await idbDelete(key); }catch(e){ console.error('IndexedDB delete failed for', key, e); ok = false; }
  try{ localStorage.removeItem(key); }catch(e){ /* ignore */ }
  return ok;
}
async function loadFromLocalStorage(){
  const o = await loadPersistedValue(LS_KEYS.overrides, true);
  if(o) state.overrides = o;
  const n = await loadPersistedValue(LS_KEYS.newRecords, true);
  if(n) state.newRecords = n;
  const l = await loadPersistedValue(LS_KEYS.importLog, true);
  if(l) state.importLog = l;
  const lg = await loadPersistedValue(LS_KEYS.lang, false);
  if(lg && I18N[lg]) state.lang = lg;
  const root = await loadPersistedValue(LS_KEYS.localRoot, false);
  if(root) state.localRoot = root;
  const links = await loadPersistedValue(LS_KEYS.defectCodeLinks, true);
  if(links) state.defectCodeLinks = links;
  const nat = await loadPersistedValue(LS_KEYS.useNativeOpen, false);
  if(nat !== undefined) state.useNativeOpen = nat === '1' || nat === true;
  migrateSharedFileLinksToPerRecord();
}
// One-time migration: CA File Link used to be shared across every record
// with the same Defect Code, which meant editing one record's link silently
// changed it for every other record with that code too. Each record now
// keeps its own independent link (r.caFileLink), same as PIC/Remark. This
// copies each Defect Code's old shared value onto every record that was
// showing it -- so nothing anyone already typed in gets lost -- and then
// retires the shared lookup table. Safe to call on every load: once
// state.defectCodeLinks is empty there is nothing left to migrate, so this
// is a no-op after the first run.
function migrateSharedFileLinksToPerRecord(){
  const sharedLinks = state.defectCodeLinks;
  if(!sharedLinks || Object.keys(sharedLinks).length===0) return;
  const all = getAllRecords();
  for(const r of all){
    if(r.caFileLink) continue; // already has its own value, don't overwrite
    const code = r.partCode || '';
    const shared = code ? sharedLinks[code] : null;
    if(!shared) continue;
    const idStr = String(r.id);
    const newIdx = state.newRecords.findIndex(x=>String(x.id)===idStr);
    if(newIdx>-1){
      state.newRecords[newIdx] = Object.assign({}, state.newRecords[newIdx], {caFileLink: shared});
    } else {
      state.overrides[idStr] = Object.assign({}, state.overrides[idStr]||{}, {caFileLink: shared});
    }
  }
  state.defectCodeLinks = {};
  persistOverrides();
  persistNewRecords();
  persistDefectCodeLinks();
}
function persistOverrides(){
  return savePersistedValue(LS_KEYS.overrides, state.overrides, true);
}
function persistNewRecords(){
  return savePersistedValue(LS_KEYS.newRecords, state.newRecords, true);
}
function persistImportLog(){
  return savePersistedValue(LS_KEYS.importLog, state.importLog, true);
}
function persistLang(){
  return savePersistedValue(LS_KEYS.lang, state.lang, false);
}
function persistLocalRoot(){
  return savePersistedValue(LS_KEYS.localRoot, state.localRoot || '', false);
}
function persistDefectCodeLinks(){
  return savePersistedValue(LS_KEYS.defectCodeLinks, state.defectCodeLinks, true);
}
function persistUseNativeOpen(){
  return savePersistedValue(LS_KEYS.useNativeOpen, state.useNativeOpen ? '1' : '0', false);
}
// Destructive, user-initiated reset: wipes everything imported/edited from
// both in-memory state and persisted storage, leaving only the original seed
// dataset (BASE_DATA). Requires explicit confirmation before running.
// Also resets active filters/search: without this, a filter or search term
// that only matched imported data would keep the table looking "empty"
// after the reset too, which looks exactly like the button doing nothing.
// Returns true/false so the caller can show an error if anything goes wrong,
// rather than silently leaving stale data behind.
async function clearLocalData(){
  state.overrides = {};
  state.newRecords = [];
  state.importLog = [];
  state.defectCodeLinks = {}; // legacy per-defect-code links, retired but still worth clearing out
  state.filters = freshFilters();
  const results = await Promise.all([
    deletePersistedValue(LS_KEYS.overrides),
    deletePersistedValue(LS_KEYS.newRecords),
    deletePersistedValue(LS_KEYS.importLog),
    deletePersistedValue(LS_KEYS.defectCodeLinks),
  ]);
  return results.every(Boolean);
}

/* ============ Data merge ============ */
// BASE_DATA is the original historical export (read-only seed, always present).
// state.newRecords holds everything imported/added since: daily "Add File"
// imports plus manually-added defects. Both are persisted to the browser's
// local storage (see above) so they survive a refresh or closing the tab.
function getAllRecords(){
  const base = BASE_DATA.map(r=>{
    const o = state.overrides[r.id];
    return o ? Object.assign({}, r, o) : r;
  });
  return base.concat(state.newRecords);
}
// Shared patch-apply used by every manual edit path (drawer save, inline PIC
// edit in the Records table, inline PIC edit in the Reject dashboard, etc.):
// base-seed records get their edits stored as an override patch (BASE_DATA
// itself is never mutated); records added via import/manual-entry are patched
// directly in state.newRecords. Both paths persist to local storage immediately.
function updateRecordField(id, patch){
  const idStr = String(id);
  const newIdx = state.newRecords.findIndex(x=>String(x.id)===idStr);
  if(newIdx>-1){
    state.newRecords[newIdx] = Object.assign({}, state.newRecords[newIdx], patch);
    persistNewRecords();
  } else {
    state.overrides[idStr] = Object.assign({}, state.overrides[idStr]||{}, patch);
    persistOverrides();
  }
}
// Generic inline-editable cell input, used for PIC, Remark, and the text part
// of the CA File Link cell. Saves on blur/Enter via the 'change' event (see
// wireEvents) rather than on every keystroke. data-field tells the shared
// change handler which record property to patch.
function inlineEditInputHtml(r, field, placeholder){
  return `<input type="text" class="inline-edit-input" data-field="${esc(field)}" data-id="${esc(r.id)}" value="${esc(r[field]||'')}" placeholder="${esc(placeholder)}"/>`;
}
// Back-compat thin wrapper (kept so any existing callers/behavior stay identical).
function picInputHtml(r){
  return inlineEditInputHtml(r, 'pic', t('picPlaceholder'));
}
function remarkInputHtml(r){
  return inlineEditInputHtml(r, 'notes', t('remarkPlaceholder'));
}
function mqisInputHtml(r){
  return inlineEditInputHtml(r, 'mqisCode', t('mqisPlaceholder'));
}
// Joins a relative path onto the configured local root folder (if one is set
// and the path isn't already absolute or a URL); returns the plain path with
// its original separators, no URI encoding. This is what gets copied to the
// clipboard, and it's also the first step toFileUri() uses before turning
// the result into a proper file:// URI.
function resolveLocalPath(raw){
  if(!raw) return null;
  let p = String(raw).trim();
  if(!p) return null;
  if(/^javascript:/i.test(p)) return null;
  if(/^(https?|file|ftp|mailto):/i.test(p)) return p; // already a full URL, leave alone

  const isAbsWin = /^[a-zA-Z]:[\\/]/.test(p);
  const isUNC = /^\\\\/.test(p) || /^\/\/[^/]/.test(p);
  const isAbsUnix = /^\//.test(p);

  if(!isAbsWin && !isUNC && !isAbsUnix && state.localRoot){
    const root = state.localRoot.trim();
    const rootEndsSep = /[\\/]$/.test(root);
    const sepChar = root.includes('\\') && !root.includes('/') ? '\\' : '/';
    p = root + (rootEndsSep ? '' : sepChar) + p;
  }
  return p;
}
// Resolves whatever the user typed into the CA File Link field into something
// a browser can actually navigate to:
//  - a full http(s):// or file:// URL is used as-is
//  - an absolute Windows path (C:\...) or UNC path (\\server\share\...) is
//    converted to the equivalent file:// URI
//  - a bare relative path/filename (no drive letter, no leading slash) is
//    first joined onto the configured "local root folder" (state.localRoot),
//    if one is set, then converted the same way
// Browsers only allow file:// navigation from a page that is itself file://
// (or, for some browsers, restrict it further) -- direct filesystem access
// from an http(s) page is blocked by design and there is no workaround for
// that; this resolves the path as well as any browser possibly can.
function toFileUri(raw){
  const p = resolveLocalPath(raw);
  if(!p) return null;
  if(/^(https?|file|ftp|mailto):/i.test(p)) return p; // already a full URL

  if(/^\\\\/.test(p)){ // UNC: \\server\share\path -> file://server/share/path
    const encoded = p.slice(2).split(/[\\/]/).filter(Boolean).map(encodeURIComponent).join('/');
    return 'file://' + encoded;
  }
  if(/^\/\/[^/]/.test(p)){ // UNC written with forward slashes: //server/share/path
    const encoded = p.slice(2).split('/').filter(Boolean).map(encodeURIComponent).join('/');
    return 'file://' + encoded;
  }
  if(/^[a-zA-Z]:[\\/]/.test(p)){ // C:\folder\file.pdf -> file:///C:/folder/file.pdf
    const drive = p.slice(0,2);
    const rest = p.slice(2).split(/[\\/]/).filter(Boolean).map(encodeURIComponent).join('/');
    return 'file:///' + drive + '/' + rest;
  }
  if(/^\//.test(p)){ // /home/user/file.pdf -> file:///home/user/file.pdf
    const encoded = p.split('/').filter(Boolean).map(encodeURIComponent).join('/');
    return 'file:///' + encoded;
  }
  // Relative path with no root folder configured -- nothing sensible to
  // resolve it against, so hand it back as typed (browser will likely treat
  // it as relative to the current page, which is rarely what's wanted, but
  // it's the most literal interpretation of what the user entered).
  return p;
}
// Converts a resolved file:// URI into the custom "tnpopen://" URI understood
// by the optional one-time Windows helper (see the "Open File setup" section
// in the Add-file modal) so clicking Open launches the file in its normal
// associated desktop app (Excel/Word/etc.) directly from its original
// location, instead of the browser downloading a copy. Only meaningful for
// local file:// URIs -- http(s)/ftp/mailto links pass through untouched.
function fileUriToNativeProtocol(fileUri){
  if(!fileUri || !/^file:\/\//i.test(fileUri)) return fileUri;
  if(/^file:\/\/\/[a-zA-Z]:\//.test(fileUri)){
    // file:///C:/folder/file.ext -> tnpopen://C:/folder/file.ext
    return 'tnpopen://' + fileUri.slice('file:///'.length);
  }
  // file://server/share/file.ext -> tnpopen://UNC/server/share/file.ext
  return 'tnpopen://UNC/' + fileUri.slice('file://'.length);
}
// The single function the "Open File" button uses to build its href:
// resolves the raw path/URL the same way toFileUri does, then -- only if the
// person has completed the optional native-open setup -- rewrites local
// file:// links to the tnpopen:// protocol so they launch the original file
// in its default desktop app rather than being downloaded.
function resolveOpenLink(raw){
  const fileUri = toFileUri(raw);
  if(!fileUri) return null;
  if(state.useNativeOpen && /^file:\/\//i.test(fileUri)) return fileUriToNativeProtocol(fileUri);
  return fileUri;
}
// Copies text to the clipboard with a fallback for contexts where the modern
// async Clipboard API isn't available (older browsers, some file:// setups).
// Returns a promise that resolves to true/false so callers can show
// success/failure feedback.
function copyTextToClipboard(text){
  if(!text) return Promise.resolve(false);
  if(navigator.clipboard && navigator.clipboard.writeText){
    return navigator.clipboard.writeText(text).then(()=>true).catch(()=>copyTextToClipboardFallback(text));
  }
  return Promise.resolve(copyTextToClipboardFallback(text));
}
function copyTextToClipboardFallback(text){
  try{
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  }catch(e){ return false; }
}

function downloadTextFile(filename, content, mime){
  const blob = new Blob([content], {type: mime || 'text/plain;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
// One-time Windows setup for the "Open File" button: registers a
// "tnpopen://" link type (current-user only, no admin rights) that hands
// local file links off to a tiny VBScript helper, which launches the file in
// its normal default app (Excel, Word, Adobe Reader, etc.) directly from its
// original location -- no download, no copy. See fileUriToNativeProtocol()/
// resolveOpenLink() for the JS side that builds these links once this is
// installed and the toggle is enabled.
//
// Implementation note: this used to shell out to "reg add" with manually
// doubled quotes to embed the VBS path inside the registry value. That broke
// for any Windows username containing a space (e.g. "C:\Users\binh qc\...")
// because cmd.exe's quote handling for that many nested quotes is unreliable
// -- reg.exe would reject it with "ERROR: Invalid syntax." All registry and
// file-system work now goes through a single PowerShell -EncodedCommand
// instead, using PowerShell's own (much more robust) string handling, so
// spaces or special characters anywhere in the user's profile path are no
// longer a problem.
//
// Second fix baked into the VBS helper itself: file paths with accented
// characters (Vietnamese, etc.) were coming out as mojibake -- e.g. "Đối
// sách" turning into "Ä'á»'i sÃ¡ch" -- because the percent-decoding step
// converted each raw UTF-8 byte straight into a character with Chr(), which
// only works for single-byte (ASCII) text. Multi-byte UTF-8 sequences need
// to be reassembled properly, which the VBS now does via an ADODB.Stream
// charset round-trip (write the raw bytes as iso-8859-1, then re-read the
// same bytes as utf-8) before building the final path.
function downloadNativeOpenSetupScript(){
  downloadTextFile('tnpopen_setup.bat', "@echo off\necho ============================================================\necho  TNP Defect Management System - Open File Native Setup\necho ============================================================\necho.\necho This will let the \"Open File\" button launch corrective-action\necho files directly in their normal desktop app (Excel, Word, etc.)\necho instead of the browser downloading a copy.\necho.\necho A small helper script will be created in your user folder, and\necho a \"tnpopen://\" link type will be registered for your Windows\necho user account only (no admin rights needed, fully removable\necho later with Remove-Native-Open.bat).\necho.\npause\n\npowershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQAgAD0AIAAnAFMAdABvAHAAJwAKAHQAcgB5ACAAewAKACAAIAAkAHYAYgBzACAAPQAgAEAAJwAKAEQAaQBtACAAcgBhAHcAVQByAGwALAAgAHAALAAgAHAAcgBlAGYAaQB4ACwAIABpACwAIABjAGgALAAgAGgAZQB4AFYAYQBsAAoAcgBhAHcAVQByAGwAIAA9ACAAVwBTAGMAcgBpAHAAdAAuAEEAcgBnAHUAbQBlAG4AdABzACgAMAApAAoACgBwAHIAZQBmAGkAeAAgAD0AIAAiAHQAbgBwAG8AcABlAG4AOgAvAC8AIgAKAEkAZgAgAEwAQwBhAHMAZQAoAEwAZQBmAHQAKAByAGEAdwBVAHIAbAAsACAATABlAG4AKABwAHIAZQBmAGkAeAApACkAKQAgAD0AIABwAHIAZQBmAGkAeAAgAFQAaABlAG4ACgAgACAAIAAgAHAAIAA9ACAATQBpAGQAKAByAGEAdwBVAHIAbAAsACAATABlAG4AKABwAHIAZQBmAGkAeAApACAAKwAgADEAKQAKAEUAbABzAGUACgAgACAAIAAgAHAAIAA9ACAAcgBhAHcAVQByAGwACgBFAG4AZAAgAEkAZgAKAAoARABpAG0AIABpAHMAVQBOAEMACgBpAHMAVQBOAEMAIAA9ACAARgBhAGwAcwBlAAoASQBmACAATABDAGEAcwBlACgATABlAGYAdAAoAHAALAAgADQAKQApACAAPQAgACIAdQBuAGMALwAiACAAVABoAGUAbgAKACAAIAAgACAAaQBzAFUATgBDACAAPQAgAFQAcgB1AGUACgAgACAAIAAgAHAAIAA9ACAATQBpAGQAKABwACwAIAA1ACkACgBFAG4AZAAgAEkAZgAKAAoAJwAgAFAAZQByAGMAZQBuAHQALQBkAGUAYwBvAGQAZQAgAGkAbgB0AG8AIABhACAAcgBhAHcAIABiAHkAdABlACAAcwB0AHIAaQBuAGcAIABmAGkAcgBzAHQAIAAoAG8AbgBlACAAYwBoAGEAcgBhAGMAdABlAHIAIABoAGUAcgBlACAAPQAgAG8AbgBlACAAcgBhAHcACgAnACAAYgB5AHQAZQAgADAALQAyADUANQAsACAATgBPAFQAIAB5AGUAdAAgAGEAIAByAGUAYQBsACAAVQBuAGkAYwBvAGQAZQAgAGMAaABhAHIAYQBjAHQAZQByACAALQAtACAAQwBoAHIAKAAwAC0AMgA1ADUAKQAgAGgAYQBwAHAAZQBuAHMAIAB0AG8AIABlAHEAdQBhAGwACgAnACAAdABoAGUAIABtAGEAdABjAGgAaQBuAGcAIABMAGEAdABpAG4ALQAxACAAYwBvAGQAZQBwAG8AaQBuAHQALAAgAHcAaABpAGMAaAAgAGkAcwAgAGUAeABhAGMAdABsAHkAIAB3AGgAYQB0ACAAVQBUAEYAOABEAGUAYwBvAGQAZQAgAGIAZQBsAG8AdwAKACcAIABlAHgAcABlAGMAdABzACAAYQBzACAAaQB0AHMAIABpAG4AcAB1AHQAKQAuAAoARABpAG0AIAByAGEAdwBCAHkAdABlAHMACgByAGEAdwBCAHkAdABlAHMAIAA9ACAAIgAiAAoAaQAgAD0AIAAxAAoARABvACAAVwBoAGkAbABlACAAaQAgADwAPQAgAEwAZQBuACgAcAApAAoAIAAgACAAIABjAGgAIAA9ACAATQBpAGQAKABwACwAIABpACwAIAAxACkACgAgACAAIAAgAEkAZgAgAGMAaAAgAD0AIAAiACUAIgAgAEEAbgBkACAAaQAgACsAIAAyACAAPAA9ACAATABlAG4AKABwACkAIABUAGgAZQBuAAoAIAAgACAAIAAgACAAIAAgAGgAZQB4AFYAYQBsACAAPQAgAE0AaQBkACgAcAAsACAAaQAgACsAIAAxACwAIAAyACkACgAgACAAIAAgACAAIAAgACAAcgBhAHcAQgB5AHQAZQBzACAAPQAgAHIAYQB3AEIAeQB0AGUAcwAgACYAIABDAGgAcgAoAEMATABuAGcAKAAiACYASAAiACAAJgAgAGgAZQB4AFYAYQBsACkAKQAKACAAIAAgACAAIAAgACAAIABpACAAPQAgAGkAIAArACAAMwAKACAAIAAgACAARQBsAHMAZQAKACAAIAAgACAAIAAgACAAIAByAGEAdwBCAHkAdABlAHMAIAA9ACAAcgBhAHcAQgB5AHQAZQBzACAAJgAgAGMAaAAKACAAIAAgACAAIAAgACAAIABpACAAPQAgAGkAIAArACAAMQAKACAAIAAgACAARQBuAGQAIABJAGYACgBMAG8AbwBwAAoACgAnACAAVABoAGUAIABwAGEAdABoACAAbQBhAHkAIABjAG8AbgB0AGEAaQBuACAAbQB1AGwAdABpAC0AYgB5AHQAZQAgAFUAVABGAC0AOAAgAHMAZQBxAHUAZQBuAGMAZQBzACAAKABhAGMAYwBlAG4AdABlAGQALwBWAGkAZQB0AG4AYQBtAGUAcwBlAAoAJwAgAGMAaABhAHIAYQBjAHQAZQByAHMAIAB0AGEAawBlACAAMgAtADMAIABiAHkAdABlAHMAIABlAGEAYwBoACkAIAAtAC0AIABkAGUAYwBvAGQAZQAgAHQAaABvAHMAZQAgAGIAeQB0AGUAcwAgAHAAcgBvAHAAZQByAGwAeQAgAGkAbgBzAHQAZQBhAGQAIABvAGYACgAnACAAdAByAGUAYQB0AGkAbgBnACAAZQBhAGMAaAAgAGIAeQB0AGUAIABhAHMAIABpAHQAcwAgAG8AdwBuACAAYwBoAGEAcgBhAGMAdABlAHIALAAgAG8AcgAgAG4AbwBuAC0AQQBTAEMASQBJACAAbgBhAG0AZQBzACAAYwBvAG0AZQAgAG8AdQB0ACAAYQBzAAoAJwAgAG0AbwBqAGkAYgBhAGsAZQAgACgAZQAuAGcALgAgACIAxAAYIOEAuwAnAGkAIABzAMMAoQBjAGgAIgAgAGkAbgBzAHQAZQBhAGQAIABvAGYAIAAiABAB0R5pACAAcwDhAGMAaAAiACkALgAKAEYAdQBuAGMAdABpAG8AbgAgAFUAVABGADgARABlAGMAbwBkAGUAKAByAGEAdwBCAHkAdABlAHMAVABlAHgAdAApAAoAIAAgACAAIABEAGkAbQAgAHMAdAByAGUAYQBtAAoAIAAgACAAIABTAGUAdAAgAHMAdAByAGUAYQBtACAAPQAgAEMAcgBlAGEAdABlAE8AYgBqAGUAYwB0ACgAIgBBAEQATwBEAEIALgBTAHQAcgBlAGEAbQAiACkACgAgACAAIAAgAHMAdAByAGUAYQBtAC4AVAB5AHAAZQAgAD0AIAAyACAAIAAgACAAIAAgACcAIAB0AGUAeAB0AAoAIAAgACAAIABzAHQAcgBlAGEAbQAuAE0AbwBkAGUAIAA9ACAAMwAgACAAIAAgACAAIAAgACcAIAByAGUAYQBkAC8AdwByAGkAdABlAAoAIAAgACAAIABzAHQAcgBlAGEAbQAuAE8AcABlAG4ACgAgACAAIAAgAHMAdAByAGUAYQBtAC4AQwBoAGEAcgBzAGUAdAAgAD0AIAAiAGkAcwBvAC0AOAA4ADUAOQAtADEAIgAgACAAJwAgADEALQBiAHkAdABlAC0AcABlAHIALQBjAGgAYQByACwAIABzAG8AIABXAHIAaQB0AGUAVABlAHgAdAAgAHAAcgBlAHMAZQByAHYAZQBzACAAZQB2AGUAcgB5ACAAcgBhAHcAIABiAHkAdABlACAAYQBzAC0AaQBzAAoAIAAgACAAIABzAHQAcgBlAGEAbQAuAFcAcgBpAHQAZQBUAGUAeAB0ACAAcgBhAHcAQgB5AHQAZQBzAFQAZQB4AHQACgAgACAAIAAgAHMAdAByAGUAYQBtAC4AUABvAHMAaQB0AGkAbwBuACAAPQAgADAACgAgACAAIAAgAHMAdAByAGUAYQBtAC4AQwBoAGEAcgBzAGUAdAAgAD0AIAAiAHUAdABmAC0AOAAiACAAIAAgACAAIAAgACAAJwAgAG4AbwB3ACAAcgBlAC0AcgBlAGEAZAAgAHQAaABvAHMAZQAgAHMAYQBtAGUAIABiAHkAdABlAHMAIABpAG4AdABlAHIAcAByAGUAdABlAGQAIABhAHMAIABVAFQARgAtADgACgAgACAAIAAgAFUAVABGADgARABlAGMAbwBkAGUAIAA9ACAAcwB0AHIAZQBhAG0ALgBSAGUAYQBkAFQAZQB4AHQACgAgACAAIAAgAHMAdAByAGUAYQBtAC4AQwBsAG8AcwBlAAoARQBuAGQAIABGAHUAbgBjAHQAaQBvAG4ACgAKAEQAaQBtACAAZABlAGMAbwBkAGUAZAAKAGQAZQBjAG8AZABlAGQAIAA9ACAAVQBUAEYAOABEAGUAYwBvAGQAZQAoAHIAYQB3AEIAeQB0AGUAcwApAAoAZABlAGMAbwBkAGUAZAAgAD0AIABSAGUAcABsAGEAYwBlACgAZABlAGMAbwBkAGUAZAAsACAAIgAvACIALAAgACIAXAAiACkACgAKAEQAaQBtACAAZgBpAG4AYQBsAFAAYQB0AGgACgBJAGYAIABpAHMAVQBOAEMAIABUAGgAZQBuAAoAIAAgACAAIABmAGkAbgBhAGwAUABhAHQAaAAgAD0AIAAiAFwAXAAiACAAJgAgAGQAZQBjAG8AZABlAGQACgBFAGwAcwBlAAoAIAAgACAAIABmAGkAbgBhAGwAUABhAHQAaAAgAD0AIABkAGUAYwBvAGQAZQBkAAoARQBuAGQAIABJAGYACgAKAEQAaQBtACAAbwBiAGoAUwBoAGUAbABsAAoAUwBlAHQAIABvAGIAagBTAGgAZQBsAGwAIAA9ACAAQwByAGUAYQB0AGUATwBiAGoAZQBjAHQAKAAiAFMAaABlAGwAbAAuAEEAcABwAGwAaQBjAGEAdABpAG8AbgAiACkACgBvAGIAagBTAGgAZQBsAGwALgBTAGgAZQBsAGwARQB4AGUAYwB1AHQAZQAgAGYAaQBuAGEAbABQAGEAdABoACwAIAAiACIALAAgACIAIgAsACAAIgBvAHAAZQBuACIALAAgADEACgAKACcAQAAKAAoAIAAgACQAdgBiAHMAUABhAHQAaAAgAD0AIABKAG8AaQBuAC0AUABhAHQAaAAgACQAZQBuAHYAOgBVAFMARQBSAFAAUgBPAEYASQBMAEUAIAAnAHQAbgBwAG8AcABlAG4AXwBoAGEAbgBkAGwAZQByAC4AdgBiAHMAJwAKACAAIABbAFMAeQBzAHQAZQBtAC4ASQBPAC4ARgBpAGwAZQBdADoAOgBXAHIAaQB0AGUAQQBsAGwAVABlAHgAdAAoACQAdgBiAHMAUABhAHQAaAAsACAAJAB2AGIAcwApAAoACgAgACAATgBlAHcALQBJAHQAZQBtACAALQBQAGEAdABoACAAJwBIAEsAQwBVADoAXABTAG8AZgB0AHcAYQByAGUAXABDAGwAYQBzAHMAZQBzAFwAdABuAHAAbwBwAGUAbgAnACAALQBGAG8AcgBjAGUAIAB8ACAATwB1AHQALQBOAHUAbABsAAoAIAAgAE4AZQB3AC0ASQB0AGUAbQBQAHIAbwBwAGUAcgB0AHkAIAAtAFAAYQB0AGgAIAAnAEgASwBDAFUAOgBcAFMAbwBmAHQAdwBhAHIAZQBcAEMAbABhAHMAcwBlAHMAXAB0AG4AcABvAHAAZQBuACcAIAAtAE4AYQBtAGUAIAAnACgAZABlAGYAYQB1AGwAdAApACcAIAAtAFYAYQBsAHUAZQAgACcAVQBSAEwAOgBUAE4AUAAgAE8AcABlAG4AIABMAG8AYwBhAGwAIABGAGkAbABlACAAUAByAG8AdABvAGMAbwBsACcAIAAtAFAAcgBvAHAAZQByAHQAeQBUAHkAcABlACAAUwB0AHIAaQBuAGcAIAAtAEYAbwByAGMAZQAgAHwAIABPAHUAdAAtAE4AdQBsAGwACgAgACAATgBlAHcALQBJAHQAZQBtAFAAcgBvAHAAZQByAHQAeQAgAC0AUABhAHQAaAAgACcASABLAEMAVQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwAQwBsAGEAcwBzAGUAcwBcAHQAbgBwAG8AcABlAG4AJwAgAC0ATgBhAG0AZQAgACcAVQBSAEwAIABQAHIAbwB0AG8AYwBvAGwAJwAgAC0AVgBhAGwAdQBlACAAJwAnACAALQBQAHIAbwBwAGUAcgB0AHkAVAB5AHAAZQAgAFMAdAByAGkAbgBnACAALQBGAG8AcgBjAGUAIAB8ACAATwB1AHQALQBOAHUAbABsAAoACgAgACAATgBlAHcALQBJAHQAZQBtACAALQBQAGEAdABoACAAJwBIAEsAQwBVADoAXABTAG8AZgB0AHcAYQByAGUAXABDAGwAYQBzAHMAZQBzAFwAdABuAHAAbwBwAGUAbgBcAHMAaABlAGwAbABcAG8AcABlAG4AXABjAG8AbQBtAGEAbgBkACcAIAAtAEYAbwByAGMAZQAgAHwAIABPAHUAdAAtAE4AdQBsAGwACgAgACAAJABjAG0AZABWAGEAbAB1AGUAIAA9ACAAJwB3AHMAYwByAGkAcAB0AC4AZQB4AGUAIAAiACcAIAArACAAJAB2AGIAcwBQAGEAdABoACAAKwAgACcAIgAgACIAJQAxACIAJwAKACAAIABOAGUAdwAtAEkAdABlAG0AUAByAG8AcABlAHIAdAB5ACAALQBQAGEAdABoACAAJwBIAEsAQwBVADoAXABTAG8AZgB0AHcAYQByAGUAXABDAGwAYQBzAHMAZQBzAFwAdABuAHAAbwBwAGUAbgBcAHMAaABlAGwAbABcAG8AcABlAG4AXABjAG8AbQBtAGEAbgBkACcAIAAtAE4AYQBtAGUAIAAnACgAZABlAGYAYQB1AGwAdAApACcAIAAtAFYAYQBsAHUAZQAgACQAYwBtAGQAVgBhAGwAdQBlACAALQBQAHIAbwBwAGUAcgB0AHkAVAB5AHAAZQAgAFMAdAByAGkAbgBnACAALQBGAG8AcgBjAGUAIAB8ACAATwB1AHQALQBOAHUAbABsAAoACgAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACIAIgAKACAAIABXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQAiAAoAIAAgAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiACAAUwBlAHQAdQBwACAAYwBvAG0AcABsAGUAdABlACEAIgAKACAAIABXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQAiAAoAIAAgAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiAEgAZQBsAHAAZQByACAAcwBjAHIAaQBwAHQAIABjAHIAZQBhAHQAZQBkACAAYQB0ADoAIAAkAHYAYgBzAFAAYQB0AGgAIgAKACAAIABXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgBDAGwAbwBzAGUAIAB0AGgAaQBzACAAdwBpAG4AZABvAHcALAAgAHQAaABlAG4AIAByAGUAcwB0AGEAcgB0ACAAeQBvAHUAcgAgAGIAcgBvAHcAcwBlAHIALgAgAFQAaABlACAAJwBPAHAAZQBuACAARgBpAGwAZQAnACIACgAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACIAYgB1AHQAdABvAG4AIAB3AGkAbABsACAAbgBvAHcAIABsAGEAdQBuAGMAaAAgAGwAbwBjAGEAbAAgAGYAaQBsAGUAcwAgAGQAaQByAGUAYwB0AGwAeQAgAGkAbgAgAHQAaABlAGkAcgAgAGQAZQBmAGEAdQBsAHQAIABhAHAAcAAuACIACgB9ACAAYwBhAHQAYwBoACAAewAKACAAIABXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgAiAAoAIAAgAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiAD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9ACIACgAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACIAIABTAGUAdAB1AHAAIABGAEEASQBMAEUARAAiAAoAIAAgAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiAD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9ACIACgAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACQAXwAuAEUAeABjAGUAcAB0AGkAbwBuAC4ATQBlAHMAcwBhAGcAZQAKACAAIABXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgBOAG8AIABjAGgAYQBuAGcAZQBzACAAdABoAGEAdAAgAGQAaQBkACAAYwBvAG0AcABsAGUAdABlACAAbgBlAGUAZAAgAHQAbwAgAGIAZQAgAHUAbgBkAG8AbgBlACAALQAtACAAagB1AHMAdAAgAHIAZQAtAHIAdQBuACAAdABoAGkAcwAgAHMAYwByAGkAcAB0AC4AIgAKAH0ACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgAiAAoAVwByAGkAdABlAC0ASABvAHMAdAAgACIAUAByAGUAcwBzACAARQBuAHQAZQByACAAdABvACAAYwBsAG8AcwBlACAAdABoAGkAcwAgAHcAaQBuAGQAbwB3AC4ALgAuACIACgBSAGUAYQBkAC0ASABvAHMAdAAgAHwAIABPAHUAdAAtAE4AdQBsAGwACgA=\n", 'application/bat');
}
function downloadNativeOpenRemoveScript(){
  downloadTextFile('tnpopen_remove.bat', "@echo off\npowershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQAgAD0AIAAnAFMAaQBsAGUAbgB0AGwAeQBDAG8AbgB0AGkAbgB1AGUAJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiAFIAZQBtAG8AdgBpAG4AZwAgAFQATgBQACAAbgBhAHQAaQB2AGUAIABmAGkAbABlAC0AbwBwAGUAbgAgAHIAZQBnAGkAcwB0AHIAYQB0AGkAbwBuACAAYQBuAGQAIABoAGUAbABwAGUAcgAgAHMAYwByAGkAcAB0AC4ALgAuACIACgBSAGUAbQBvAHYAZQAtAEkAdABlAG0AIAAtAFAAYQB0AGgAIAAnAEgASwBDAFUAOgBcAFMAbwBmAHQAdwBhAHIAZQBcAEMAbABhAHMAcwBlAHMAXAB0AG4AcABvAHAAZQBuACcAIAAtAFIAZQBjAHUAcgBzAGUAIAAtAEYAbwByAGMAZQAKACQAdgBiAHMAUABhAHQAaAAgAD0AIABKAG8AaQBuAC0AUABhAHQAaAAgACQAZQBuAHYAOgBVAFMARQBSAFAAUgBPAEYASQBMAEUAIAAnAHQAbgBwAG8AcABlAG4AXwBoAGEAbgBkAGwAZQByAC4AdgBiAHMAJwAKAGkAZgAgACgAVABlAHMAdAAtAFAAYQB0AGgAIAAkAHYAYgBzAFAAYQB0AGgAKQAgAHsAIABSAGUAbQBvAHYAZQAtAEkAdABlAG0AIAAtAFAAYQB0AGgAIAAkAHYAYgBzAFAAYQB0AGgAIAAtAEYAbwByAGMAZQAgAH0ACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgAiAAoAVwByAGkAdABlAC0ASABvAHMAdAAgACIARABvAG4AZQAuACAAJwBPAHAAZQBuACAARgBpAGwAZQAnACAAdwBpAGwAbAAgAGcAbwAgAGIAYQBjAGsAIAB0AG8AIAB1AHMAaQBuAGcAIAB5AG8AdQByACAAYgByAG8AdwBzAGUAcgAnAHMAIABuAG8AcgBtAGEAbAAiAAoAVwByAGkAdABlAC0ASABvAHMAdAAgACIAZgBpAGwAZQA6AC8ALwAgAGgAYQBuAGQAbABpAG4AZwAgACgAdwBoAGkAYwBoACAAZABvAHcAbgBsAG8AYQBkAHMAIABhACAAYwBvAHAAeQAgAGYAbwByACAAbgBvAG4ALQBiAHIAbwB3AHMAZQByACAAZgBpAGwAZQAgAHQAeQBwAGUAcwApAC4AIgAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiACIACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAIgBQAHIAZQBzAHMAIABFAG4AdABlAHIAIAB0AG8AIABjAGwAbwBzAGUAIAB0AGgAaQBzACAAdwBpAG4AZABvAHcALgAuAC4AIgAKAFIAZQBhAGQALQBIAG8AcwB0ACAAfAAgAE8AdQB0AC0ATgB1AGwAbAAKAA==\n", 'application/bat');
}
// CA File Link cell: an editable text field (paste a path or URL) plus two
// small actions -- Copy Link (puts the resolved path/URL on the clipboard,
// works everywhere with zero setup) and Open File (navigates straight to the
// file, which opens PDFs/images in place with no download; for other file
// types, whether it opens directly or downloads a copy depends entirely on
// the browser's own handling of file:// links -- see the optional one-time
// "Open File setup" in the Add-file modal for a way to make Office documents
// open natively too).
// Each record's file link is its own independent value (stored per-record,
// same as PIC/Remark) -- editing one record's link never affects any other
// record, even ones that happen to share the same Defect Code.
function fileLinkCellHtml(r){
  const val = r.caFileLink || '';
  const copyText = resolveLocalPath(val);
  const openHref = resolveOpenLink(val);
  const copyBtn = copyText
    ? `<button type="button" class="file-copy-btn" data-copy-text="${esc(copyText)}" title="${esc(tf('copyPathTooltip',{path:copyText}))}">⧉</button>`
    : '';
  const openBtn = openHref
    ? `<a class="file-open-btn" href="${esc(openHref)}" target="_blank" rel="noopener noreferrer" title="${esc(tf('openPathTooltip',{path:toFileUri(val)}))}">↗</a>`
    : '';
  return `<div class="filelink-cell-inner">${inlineEditInputHtml(r,'caFileLink',t('fileLinkPlaceholder'))}${copyBtn}${openBtn}</div>`;
}
// Statuses that count as "Completed" for all tracking/reporting purposes:
// Waiting for Review (Đợi xét), Waiting for Approval (Đợi duyệt), and Completed (Hoàn thành) itself.
// Only "Waiting for Corrective Action" (Đợi đối sách) and "Reject" (Rejected (xét)) are treated as
// not completed / requiring follow-up. This single source of truth is used everywhere: Home
// Dashboard, TAT Monitoring Dashboard, pending counts, stats/charts, filters, and reports.
const COMPLETED_STATUSES = new Set(['Hoàn thành', 'Đợi duyệt', 'Đợi xét']);
function isCompletedStatus(r){ return COMPLETED_STATUSES.has(r.status); }
function isOverdue(r){ return !isCompletedStatus(r) && r.dueDate && daysUntil(r.dueDate) < 0; }
function isDueSoon(r){ return !isCompletedStatus(r) && r.dueDate && daysUntil(r.dueDate) >=0 && daysUntil(r.dueDate) <=3; }
// The "Reject" status gets its own dedicated dashboard (separate from the
// general completed/not-completed bucketing above).
function isRejectedStatus(r){ return r.status === 'Rejected (xét)'; }

/* ============ TAT monitoring (Registered date + 7 days) ============ */
function addDaysStr(dateStr, days){
  if(!dateStr) return null;
  const d = new Date(dateStr+'T00:00:00');
  if(isNaN(d.getTime())) return null;
  d.setDate(d.getDate()+days);
  return d.toISOString().slice(0,10);
}
function tatDueDate(r){ return addDaysStr(r.registeredDate, 7); }
function tatDaysRemaining(r){
  const due = tatDueDate(r);
  return due ? daysUntil(due) : null;
}
// Tier for the *open* TAT clock: null once the record is closed (no more alerting needed).
function tatTier(r){
  if(isCompletedStatus(r)) return null;
  const d = tatDaysRemaining(r);
  if(d===null) return null;
  if(d<0) return 'overdue';
  if(d===0) return 'red';
  if(d===1) return 'orange';
  if(d===2) return 'yellow';
  return 'green';
}
const TAT_TIER_META = {
  overdue:{ cls:'tat-red',    pill:'tat-pill-red',    dot:'dot-red' },
  red:    { cls:'tat-red',    pill:'tat-pill-red',    dot:'dot-red' },
  orange: { cls:'tat-orange', pill:'tat-pill-orange', dot:'dot-overdue' },
  yellow: { cls:'tat-yellow', pill:'tat-pill-yellow', dot:'dot-soon' },
  green:  { cls:'tat-green',  pill:'tat-pill-green',  dot:'dot-ok' },
};

function uniqueSorted(arr){ return Array.from(new Set(arr.filter(v=>v!==null && v!==undefined && v!=='' ))).sort(); }

function filterOptions(all){
  return {
    plant: uniqueSorted(all.map(r=>r.plant)),
    project: uniqueSorted(all.map(r=>r.project)),
    partGroup: uniqueSorted(all.map(r=>r.partGroup)),
    model: uniqueSorted(all.map(r=>r.model)),
    occurPlace: uniqueSorted(all.map(r=>r.occurPlace)),
    reason1: uniqueSorted(all.map(r=>r.reason1)),
    status: uniqueSorted(all.map(r=>r.status)),
    month: uniqueSorted(all.map(r=> r.registeredDate ? r.registeredDate.slice(0,7) : null)).sort().reverse(),
    defectCode: uniqueSorted(all.map(r=>r.partCode)),
  };
}

function applyFilters(all){
  const f = state.filters;
  const q = f.search.trim().toLowerCase();
  return all.filter(r=>{
    if(q){
      const hay = [r.mgmtNo,r.mqisCode,r.title,r.defectDetails,r.partName,r.partCode,r.model,r.project,r.inspector]
        .map(v=>String(v||'').toLowerCase()).join(' | ');
      if(!hay.includes(q)) return false;
    }
    if(f.dateFrom && r.registeredDate && r.registeredDate < f.dateFrom) return false;
    if(f.dateTo && r.registeredDate && r.registeredDate > f.dateTo) return false;
    if(f.plant.size && !f.plant.has(r.plant)) return false;
    if(f.project.size && !f.project.has(r.project)) return false;
    if(f.partGroup.size && !f.partGroup.has(r.partGroup)) return false;
    if(f.model.size && !f.model.has(r.model)) return false;
    if(f.occurPlace.size && !f.occurPlace.has(r.occurPlace)) return false;
    if(f.reason1.size && !f.reason1.has(r.reason1)) return false;
    if(f.status.size && !f.status.has(r.status)) return false;
    if(f.month.size && !f.month.has(r.registeredDate ? r.registeredDate.slice(0,7) : null)) return false;
    if(f.defectCode.size && !f.defectCode.has(r.partCode)) return false;
    return true;
  });
}

function sortRecords(list){
  const {sortKey, sortDir} = state;
  const dir = sortDir==='asc'?1:-1;
  return list.slice().sort((a,b)=>{
    let av=a[sortKey], bv=b[sortKey];
    if(av===null||av===undefined) av='';
    if(bv===null||bv===undefined) bv='';
    if(typeof av==='number' && typeof bv==='number') return (av-bv)*dir;
    return String(av).localeCompare(String(bv))*dir;
  });
}

/* ============ Rendering ============ */
function render(){
  const all = getAllRecords();
  const opts = filterOptions(all);
  const filtered = applyFilters(all);

  renderTopbar();
  renderHomeView(all);
  renderSidebar(opts, all);
  renderKPIs(filtered);
  renderTabs();
  if(state.activeTab==='records') renderRecordsTab(filtered);
  else if(state.activeTab==='analysis') renderAnalysisTab(filtered);
  else if(state.activeTab==='tat') renderTatTab(filtered);
  else if(state.activeTab==='reject') renderRejectTab(filtered);
  else renderCorrectiveTab(filtered);
  renderDrawer(all);

  // Home and Dashboard are two full-page modes sharing one shell; toggle which is visible.
  const homeEl = document.getElementById('homeView');
  const sidebarEl = document.getElementById('sidebar');
  const mainEl = document.querySelector('.main');
  const isHome = state.view==='home';
  if(homeEl) homeEl.style.display = isHome ? 'block' : 'none';
  if(sidebarEl) sidebarEl.style.display = isHome ? 'none' : 'block';
  if(mainEl) mainEl.style.display = isHome ? 'none' : 'flex';
}

/* ============ Home dashboard (per-market cards) ============ */
// Reuses the exact same "pending / completed / overdue" semantics as the
// KPI row and Corrective Actions tab elsewhere, so numbers never disagree
// between the Home overview and a market's detailed dashboard.
function computeMarketStats(all){
  const byPlant = {};
  all.forEach(r=>{
    const p = r.plant || t('notAnalyzed');
    if(!byPlant[p]) byPlant[p] = { total:0, pending:0, completed:0, overdue:0 };
    byPlant[p].total++;
    if(isCompletedStatus(r)) byPlant[p].completed++; else byPlant[p].pending++;
    if(isOverdue(r)) byPlant[p].overdue++;
  });
  return byPlant;
}

function renderHomeView(all){
  const el = document.getElementById('homeView');
  if(!el) return;
  const stats = computeMarketStats(all);
  const markets = Object.keys(stats).sort((a,b)=> stats[b].total - stats[a].total);
  const grandOverdue = all.filter(isOverdue).length;

  el.innerHTML = `
    <div class="home-overview">${esc(tf('marketOverviewLine',{markets:markets.length, total:all.length, overdue:grandOverdue}))}</div>
    <h2 class="home-heading">${esc(t('marketsHeading'))}</h2>
    <p class="home-hint">${esc(t('marketsHint'))}</p>
    <div class="market-grid">
      ${markets.map(m=>{
        const s = stats[m];
        return `<div class="market-card ${s.overdue>0?'has-overdue':''}" data-market="${esc(m)}">
          <div class="market-name">${esc(m)}</div>
          <div class="market-stats">
            <div class="mstat"><div class="mstat-val">${s.total}</div><div class="mstat-lbl">${esc(t('marketTotal'))}</div></div>
            <div class="mstat"><div class="mstat-val" style="color:var(--amber)">${s.pending}</div><div class="mstat-lbl">${esc(t('marketPending'))}</div></div>
            <div class="mstat"><div class="mstat-val" style="color:var(--green)">${s.completed}</div><div class="mstat-lbl">${esc(t('marketCompleted'))}</div></div>
            <div class="mstat"><div class="mstat-val" style="color:var(--orange)">${s.overdue}</div><div class="mstat-lbl">${esc(t('marketOverdue'))}</div></div>
          </div>
        </div>`;
      }).join('')}
    </div>
    ${renderHomeRejectSection(all)}
  `;
}
// Compact "Rejected Defects" overview on the Home page: total count across
// every market, plus a quick-glance list (capped at 8 rows so Home stays a
// fast overview) linking through to the full Reject dashboard for the rest.
// Rows are clickable (same data-id row pattern as every other table) and
// open the record detail drawer directly.
function renderHomeRejectSection(all){
  const rejected = all.filter(isRejectedStatus).sort((a,b)=>(b.registeredDate||'').localeCompare(a.registeredDate||''));
  if(rejected.length===0){
    return `
    <h2 class="home-heading" style="margin-top:36px;">${esc(t('homeRejectHeading'))}</h2>
    <p class="home-hint">${esc(t('homeRejectHint'))}</p>
    <div class="empty-state">${esc(t('homeRejectNone'))}</div>
    `;
  }
  const CAP = 8;
  const shown = rejected.slice(0, CAP);
  return `
    <div style="display:flex;align-items:baseline;justify-content:space-between;gap:16px;margin-top:36px;flex-wrap:wrap;">
      <div>
        <h2 class="home-heading" style="margin-bottom:4px;">${esc(t('homeRejectHeading'))}</h2>
        <p class="home-hint" style="margin:0;">${esc(t('homeRejectHint'))}</p>
      </div>
      <div style="text-align:right;">
        <div style="font-family:var(--mono);font-size:28px;font-weight:600;color:var(--red);line-height:1;">${rejected.length}</div>
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.03em;color:var(--ink-faint);">${esc(t('homeRejectTotalLabel'))}</div>
      </div>
    </div>
    <table class="data-table" style="margin-top:14px;">
      <thead><tr>
        <th>${esc(t('colMgmtNo'))}</th>
        <th>${esc(t('colMqis'))}</th>
        <th>${esc(t('colPlant'))}</th>
        <th>${esc(t('colModelProject'))}</th>
        <th>${esc(t('colDefectType'))}</th>
        <th>${esc(t('colDate'))}</th>
      </tr></thead>
      <tbody>
        ${shown.map(r=>`<tr data-id="${esc(r.id)}" class="row-reject">
          <td class="mono">${esc(r.mgmtNo)}</td>
          <td class="mono">${esc(r.mqisCode||'—')}</td>
          <td>${esc(r.plant)}</td>
          <td>${esc(r.project)}<div style="color:var(--ink-faint);font-size:11px;">${esc(r.model)}</div></td>
          <td>${r.reason1?esc(r.reason1):'<span style="color:var(--ink-faint)">'+esc(t('notAnalyzed'))+'</span>'}</td>
          <td class="mono">${esc(r.registeredDate)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
    <button class="btn btn-line" id="homeRejectViewAllBtn" style="margin-top:12px;">${esc(t('homeRejectViewAll'))}</button>
  `;
}

function freshFilters(){
  return { search:'', dateFrom:'', dateTo:'', plant:new Set(), project:new Set(), partGroup:new Set(),
    model:new Set(), occurPlace:new Set(), reason1:new Set(), status:new Set(), month:new Set(), defectCode:new Set() };
}
function goHome(){
  state.view = 'home';
  state.filters = freshFilters();
  render();
}
function openMarket(marketCode){
  state.filters = freshFilters();
  state.filters.plant = new Set([marketCode]);
  state.view = 'dashboard';
  state.activeTab = 'records';
  render();
}

const LANG_OPTIONS = [['en','EN'],['ko','KO'],['vi','VI']];
function renderTopbar(){
  const el = document.getElementById('topbar');
  el.innerHTML = `
    <div class="brand" id="brandLogo" title="${esc(t('navHome'))}">
      <div class="stamp-mark">TNP</div>
      <div class="brand-text">
        <h1>${esc(t('appTitle'))}</h1>
        <p>${esc(t('appSubtitle'))}</p>
      </div>
    </div>
    ${state.view==='dashboard' ? `<button class="btn btn-ghost" id="goHomeBtn">${esc(t('navHome'))}</button>` : ''}
    <div class="spacer"></div>
    <div class="lang-switch" style="display:flex;gap:2px;background:rgba(244,244,238,0.08);border:1px solid rgba(244,244,238,0.22);border-radius:8px;padding:2px;">
      ${LANG_OPTIONS.map(([code,label])=>`<button type="button" class="btn" data-lang="${code}" style="padding:6px 10px;font-size:11.5px;border-radius:6px;background:${state.lang===code?'var(--orange)':'transparent'};color:${state.lang===code?'#FBF2EC':'#F4F4EE'};">${label}</button>`).join('')}
    </div>
    ${state.view==='dashboard' ? `<div class="global-search">
      <span>&#128269;</span>
      <input id="searchInput" type="text" placeholder="${esc(t('searchPlaceholder'))}" value="${esc(state.filters.search)}"/>
    </div>` : ''}
    <button class="btn btn-ghost" id="addFileBtn">${esc(t('addFile'))}</button>
    <input type="file" id="fileInput" accept=".xlsx,.xls,.csv" multiple style="display:none;"/>
    <button class="btn btn-ghost" id="exportBtn">${esc(t('exportCsv'))}</button>
    <button class="btn btn-primary" id="newDefectBtn">${esc(t('newDefect'))}</button>
  `;
}

function checklistBlock(title, key, opts, all, countFn){
  const f = state.filters[key];
  return `
    <div class="filter-block">
      <div class="filter-label"><span>${title}</span></div>
      <div class="chk-list">
        ${opts.map(o=>{
          const n = countFn(o);
          const checked = f.has(o) ? 'checked' : '';
          return `<label class="chk-item">
            <input type="checkbox" data-filter="${key}" value="${esc(o)}" ${checked}/>
            <span>${esc(o)}</span><span class="n">${n}</span>
          </label>`;
        }).join('')}
      </div>
    </div>
  `;
}

function renderSidebar(opts, all){
  const el = document.getElementById('sidebar');
  const countBy = (key) => (val) => all.filter(r=>r[key]===val).length;
  const countByMonth = (val) => all.filter(r=>(r.registeredDate?r.registeredDate.slice(0,7):null)===val).length;
  const countByDefectCode = (val) => all.filter(r=>r.partCode===val).length;
  el.innerHTML = `
    <h2>${esc(t('filters'))}</h2>
    <div class="filter-block">
      <div class="filter-label"><span>${esc(t('registeredDate'))}</span></div>
      <div class="date-row">
        <input type="date" id="dateFrom" value="${esc(state.filters.dateFrom)}"/>
        <input type="date" id="dateTo" value="${esc(state.filters.dateTo)}"/>
      </div>
    </div>
    ${checklistBlock(t('month'),'month',opts.month, all, countByMonth)}
    ${checklistBlock(t('plant'),'plant',opts.plant, all, countBy('plant'))}
    ${checklistBlock(t('modelProject'),'project',opts.project, all, countBy('project'))}
    ${checklistBlock(t('model'),'model',opts.model, all, countBy('model'))}
    ${checklistBlock(t('partGroup'),'partGroup',opts.partGroup, all, countBy('partGroup'))}
    ${checklistBlock(t('defectCode'),'defectCode',opts.defectCode, all, countByDefectCode)}
    ${checklistBlock(t('occurPlace'),'occurPlace',opts.occurPlace, all, countBy('occurPlace'))}
    ${checklistBlock(t('reason1'),'reason1',opts.reason1, all, countBy('reason1'))}
    ${checklistBlock(t('status'),'status',opts.status, all, countBy('status'))}
    <button class="btn btn-line clear-filters" id="clearFiltersBtn">${esc(t('clearFilters'))}</button>
  `;
}

function renderKPIs(filtered){
  const el = document.getElementById('kpiRow');
  const total = filtered.length;
  const open = filtered.filter(r=>!isCompletedStatus(r)).length;
  const overdue = filtered.filter(isOverdue).length;
  const completed = filtered.filter(isCompletedStatus).length;
  const withCompletion = filtered.filter(r=>r.completedDate && r.dueDate);
  const onTime = withCompletion.filter(r=>r.completedDate <= r.dueDate).length;
  const onTimeRate = withCompletion.length ? Math.round(onTime/withCompletion.length*100) : null;

  el.innerHTML = `
    <div class="kpi-card">
      <div class="lbl">${esc(t('kpiTotal'))}</div>
      <div class="val">${total}</div>
      <div class="sub">${esc(tf('kpiTotalSub',{n:BASE_DATA.length + state.newRecords.length}))}</div>
    </div>
    <div class="kpi-card">
      <div class="lbl">${esc(t('kpiOpen'))}</div>
      <div class="val">${open}</div>
      <div class="sub">${esc(tf('kpiOpenSub',{n:completed}))}</div>
    </div>
    <div class="kpi-card ${overdue>0?'warn':''}">
      <div class="lbl">${esc(t('kpiOverdue'))}</div>
      <div class="val">${overdue}</div>
      <div class="sub">${esc(t('kpiOverdueSub'))}</div>
    </div>
    <div class="kpi-card good">
      <div class="lbl">${esc(t('kpiOnTime'))}</div>
      <div class="val">${onTimeRate===null?'—':onTimeRate+'%'}</div>
      <div class="sub">${esc(tf('kpiOnTimeSub',{n:withCompletion.length}))}</div>
    </div>
    <div class="kpi-card">
      <div class="lbl">${esc(t('kpiToday'))}</div>
      <div class="val" style="font-size:18px;">${todayStr()}</div>
      <div class="sub">${esc(t('kpiTodaySub'))}</div>
    </div>
  `;
}

function renderTabs(){
  const el = document.getElementById('tabs');
  const tabs = [['records',t('tabRecords')],['analysis',t('tabAnalysis')],['corrective',t('tabCorrective')],['tat',t('tabTat')],['reject',t('tabReject')]];
  el.innerHTML = tabs.map(([k,label])=>
    `<button class="tab-btn ${state.activeTab===k?'active':''}" data-tab="${k}">${esc(label)}</button>`
  ).join('');
}

function tableCols(){
  return [
    {key:'mgmtNo', label:t('colMgmtNo')},
    {key:'mqisCode', label:t('colMqis')},
    {key:'registeredDate', label:t('colDate')},
    {key:'plant', label:t('colPlant')},
    {key:'project', label:t('colModelProject')},
    {key:'partGroup', label:t('colPartGroup')},
    {key:'occurPlace', label:t('colOccurLocation')},
    {key:'reason1', label:t('colDefectType')},
    {key:'status', label:t('colStatus')},
    {key:'dueDate', label:t('colDueDate')},
    {key:'defectQty', label:t('colQty')},
    {key:'pic', label:t('colPic')},
    {key:'caFileLink', label:t('colFileLink')},
    {key:'notes', label:t('colRemark')},
  ];
}

function renderRecordsTab(filtered){
  const el = document.getElementById('tabPanel');
  const sorted = sortRecords(filtered);
  const cols = tableCols();
  el.innerHTML = `
    <div class="table-toolbar">
      <span class="result-count">${esc(tf(filtered.length===1?'recordCount':'recordCountPlural',{n:filtered.length}))}</span>
    </div>
    ${sorted.length===0 ? `<div class="empty-state"><h3>${esc(t('noMatchTitle'))}</h3><p>${esc(t('noMatchBody'))}</p></div>` : `
    <table class="data-table">
      <thead><tr>
        ${cols.map(c=>`<th data-sort="${c.key}" class="${state.sortKey===c.key?('sorted '+state.sortDir):''}">${esc(c.label)}</th>`).join('')}
      </tr></thead>
      <tbody>
        ${sorted.map(r=>{
          const sm = statusMeta(r.status);
          const dueBadgeDot = isOverdue(r) ? 'dot-overdue' : isDueSoon(r) ? 'dot-soon' : isCompletedStatus(r) ? 'dot-ok' : 'dot-none';
          return `<tr data-id="${esc(r.id)}">
            <td class="mono">${esc(r.mgmtNo)}</td>
            <td class="pic-cell mono">${mqisInputHtml(r)}</td>
            <td class="mono">${esc(r.registeredDate)}</td>
            <td>${esc(r.plant)}</td>
            <td>${esc(r.project)}<div style="color:var(--ink-faint);font-size:11px;">${esc(r.model)}</div></td>
            <td>${esc(r.partGroup)}</td>
            <td>${esc(r.occurPlace)}</td>
            <td>${r.reason1?esc(r.reason1)+' <span style="color:var(--ink-faint)">('+esc(REASON_GLOSS[r.reason1]||'')+')</span>':'<span style="color:var(--ink-faint)">'+esc(t('notAnalyzed'))+'</span>'}</td>
            <td><span class="badge ${sm.cls}">${esc(r.status||'Unspecified')}</span></td>
            <td class="mono"><span class="dot ${dueBadgeDot}"></span> ${esc(r.dueDate)}</td>
            <td class="mono">${r.defectQty??'—'}</td>
            <td class="pic-cell">${picInputHtml(r)}</td>
            <td class="pic-cell">${fileLinkCellHtml(r)}</td>
            <td class="pic-cell">${remarkInputHtml(r)}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>`}
  `;
}

function barList(counts, total){
  const entries = Object.entries(counts).sort((a,b)=>b[1]-a[1]);
  const max = entries.length ? entries[0][1] : 1;
  return entries.map(([label,count])=>`
    <div class="bar-row">
      <div class="b-label" title="${esc(label)}">${esc(label)}</div>
      <div class="bar-track"><div class="bar-fill" style="width:${Math.round(count/max*100)}%"></div></div>
      <div class="b-count">${count}</div>
    </div>
  `).join('');
}

function groupCount(list, keyFn){
  const out = {};
  list.forEach(r=>{
    const k = keyFn(r) || 'Not specified';
    out[k] = (out[k]||0) + 1;
  });
  return out;
}

function renderAnalysisTab(filtered){
  const el = document.getElementById('tabPanel');
  const byReason = groupCount(filtered, r=> r.reason1 ? `${r.reason1} (${REASON_GLOSS[r.reason1]||''})` : null);
  const byOccur = groupCount(filtered, r=>r.occurPlace);
  const byPartGroup = groupCount(filtered, r=>r.partGroup);
  const byProject = groupCount(filtered, r=>r.project);
  const byMonth = groupCount(filtered, r=> r.registeredDate ? r.registeredDate.slice(0,7) : null);
  const byStatus = groupCount(filtered, r=>r.status);

  el.innerHTML = `
    <div class="report-grid">
      <div class="report-card">
        <h3>${esc(t('reasonTitle'))}</h3>
        <div class="hint">${esc(t('reasonHint'))}</div>
        ${barList(byReason)}
      </div>
      <div class="report-card">
        <h3>${esc(t('occurTitle'))}</h3>
        <div class="hint">${esc(t('occurHint'))}</div>
        ${barList(byOccur)}
      </div>
      <div class="report-card">
        <h3>${esc(t('partGroupTitle'))}</h3>
        <div class="hint">${esc(t('partGroupHint'))}</div>
        ${barList(byPartGroup)}
      </div>
      <div class="report-card">
        <h3>${esc(t('projectTitle'))}</h3>
        <div class="hint">${esc(t('projectHint'))}</div>
        ${barList(byProject)}
      </div>
      <div class="report-card">
        <h3>${esc(t('monthTitle'))}</h3>
        <div class="hint">${esc(t('monthHint'))}</div>
        ${barList(byMonth)}
      </div>
      <div class="report-card">
        <h3>${esc(t('statusTitle'))}</h3>
        <div class="hint">${esc(t('statusHint'))}</div>
        ${barList(byStatus)}
      </div>
    </div>
  `;
}

function renderCorrectiveTab(filtered){
  const el = document.getElementById('tabPanel');
  const open = filtered.filter(r=>!isCompletedStatus(r));
  const overdue = open.filter(isOverdue).sort((a,b)=>daysUntil(a.dueDate)-daysUntil(b.dueDate));
  const soon = open.filter(isDueSoon).sort((a,b)=>daysUntil(a.dueDate)-daysUntil(b.dueDate));
  const upcoming = open.filter(r=>!isOverdue(r)&&!isDueSoon(r)).sort((a,b)=> (a.dueDate||'9999').localeCompare(b.dueDate||'9999'));
  const completed = filtered.filter(isCompletedStatus).sort((a,b)=>(b.completedDate||'').localeCompare(a.completedDate||''));

  function row(r, kind){
    const d = daysUntil(r.dueDate);
    let dueText = r.dueDate ? esc(r.dueDate) : t('caNoDueDate');
    if(kind!=='completed' && d!==null){
      dueText += d<0 ? ` (${Math.abs(d)}${t('caOverdueSuffix')})` : d===0 ? ` (${t('caDueToday')})` : ` (${d}${t('caDaysLeft')})`;
    }
    return `<div class="ca-row ${kind==='overdue'?'overdue':kind==='soon'?'soon':kind==='completed'?'':'ok'}" data-id="${esc(r.id)}">
      <div class="ca-mgmt">${esc(r.mgmtNo)}</div>
      <div class="ca-title" title="${esc(r.title)}">${esc(r.title)}</div>
      <div class="ca-model">${esc(r.project)}</div>
      <div class="ca-due">${dueText}</div>
      <div><span class="badge ${statusMeta(r.status).cls}">${esc(r.status||'Unspecified')}</span></div>
    </div>`;
  }

  el.innerHTML = `
    <div class="ca-section">
      <h3>${esc(t('caOverdue'))} <span class="n">${overdue.length}</span></h3>
      ${overdue.length? overdue.map(r=>row(r,'overdue')).join('') : `<div class="empty-state">${esc(t('caNoOverdue'))}</div>`}
    </div>
    <div class="ca-section">
      <h3>${esc(t('caDueSoon'))} <span class="n">${soon.length}</span></h3>
      ${soon.length? soon.map(r=>row(r,'soon')).join('') : `<div class="empty-state">${esc(t('caNoSoon'))}</div>`}
    </div>
    <div class="ca-section">
      <h3>${esc(t('caUpcoming'))} <span class="n">${upcoming.length}</span></h3>
      ${upcoming.length? upcoming.map(r=>row(r,'upcoming')).join('') : `<div class="empty-state">${esc(t('caNoUpcoming'))}</div>`}
    </div>
    <div class="ca-section">
      <h3>${esc(t('caCompleted'))} <span class="n">${completed.length}</span></h3>
      ${completed.slice(0,25).map(r=>row(r,'completed')).join('')}
      ${completed.length>25 ? `<div class="empty-state">${esc(tf('caMoreCompleted',{n:completed.length-25}))}</div>` : ''}
    </div>
  `;
}

/* ============ TAT Monitoring dashboard ============ */
function renderTatTab(filtered){
  const el = document.getElementById('tabPanel');
  const tracked = filtered.filter(r=>!isCompletedStatus(r) && r.registeredDate);
  const groups = { overdue:[], red:[], orange:[], yellow:[], green:[] };
  tracked.forEach(r=>{
    const tier = tatTier(r);
    if(tier) groups[tier].push(r);
  });
  Object.keys(groups).forEach(k=> groups[k].sort((a,b)=> tatDaysRemaining(a)-tatDaysRemaining(b)));

  function tatRow(r){
    const meta = TAT_TIER_META[tatTier(r)];
    const d = tatDaysRemaining(r);
    let daysText;
    if(d<0) daysText = tf('tatOverdueBy',{n:Math.abs(d)});
    else if(d===0) daysText = t('tatDueTodayText');
    else daysText = tf(d===1?'tatDayLeft':'tatDaysLeft',{n:d});
    return `<div class="ca-row ${meta.cls}" data-id="${esc(r.id)}">
      <div class="ca-mgmt">${esc(r.mgmtNo)}</div>
      <div class="ca-title" title="${esc(r.title)}">${esc(r.title)}</div>
      <div class="ca-model">${esc(r.project)}<span style="color:var(--ink-faint)"> · reg ${esc(r.registeredDate)}</span></div>
      <div class="ca-due mono">${esc(tatDueDate(r))}</div>
      <div><span class="tat-pill ${meta.pill}"><span class="dot ${meta.dot}"></span> ${esc(daysText)}</span></div>
    </div>`;
  }

  function section(key, titleKey, emptyKey){
    const list = groups[key];
    return `
    <div class="ca-section">
      <h3>${esc(t(titleKey))} <span class="n">${list.length}</span></h3>
      ${list.length ? list.map(tatRow).join('') : `<div class="empty-state">${esc(t(emptyKey))}</div>`}
    </div>`;
  }

  el.innerHTML = `
    <div style="margin-bottom:16px;">
      <h2 style="font-family:var(--disp);margin:0 0 4px;">${esc(t('tatHeading'))}</h2>
      <p style="font-size:12.5px;color:var(--ink-soft);margin:0;">${esc(t('tatHint'))}</p>
    </div>
    <div class="kpi-row" style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:20px;">
      <div class="kpi-card danger">
        <div class="lbl">${esc(t('tatKpiOverdue'))}</div>
        <div class="val">${groups.overdue.length}</div>
      </div>
      <div class="kpi-card danger">
        <div class="lbl">${esc(t('tatKpiToday'))}</div>
        <div class="val">${groups.red.length}</div>
      </div>
      <div class="kpi-card warn">
        <div class="lbl">${esc(t('tatKpiOrange'))}</div>
        <div class="val">${groups.orange.length}</div>
      </div>
      <div class="kpi-card">
        <div class="lbl">${esc(t('tatKpiYellow'))}</div>
        <div class="val">${groups.yellow.length}</div>
      </div>
      <div class="kpi-card good">
        <div class="lbl">${esc(t('tatKpiGreen'))}</div>
        <div class="val">${groups.green.length}</div>
        <div class="sub">${esc(tf('tatTrackedSub',{n:tracked.length}))}</div>
      </div>
    </div>
    ${section('overdue','tatSecOverdue','tatNoOverdue')}
    ${section('red','tatSecToday','tatNoToday')}
    ${section('orange','tatSecOrange','tatNoOrange')}
    ${section('yellow','tatSecYellow','tatNoYellow')}
    ${section('green','tatSecGreen','tatNoGreen')}
  `;
}

/* ============ Reject dashboard (records currently in Reject status) ============ */
function renderRejectTab(filtered){
  const el = document.getElementById('tabPanel');
  const rejected = filtered.filter(isRejectedStatus).sort((a,b)=>(b.registeredDate||'').localeCompare(a.registeredDate||''));
  const byMarket = groupCount(rejected, r=>r.plant);
  const byReason = groupCount(rejected, r=> r.reason1 ? `${r.reason1} (${REASON_GLOSS[r.reason1]||''})` : null);
  const cols = [
    {key:'mgmtNo', label:t('colMgmtNo')},
    {key:'mqisCode', label:t('colMqis')},
    {key:'registeredDate', label:t('colDate')},
    {key:'plant', label:t('colPlant')},
    {key:'project', label:t('colModelProject')},
    {key:'partCode', label:t('colDefectCode')},
    {key:'reason1', label:t('colDefectType')},
    {key:'occurPlace', label:t('colOccurLocation')},
    {key:'pic', label:t('colPic')},
    {key:'caFileLink', label:t('colFileLink')},
    {key:'notes', label:t('colRemark')},
  ];

  el.innerHTML = `
    <div style="margin-bottom:16px;">
      <h2 style="font-family:var(--disp);margin:0 0 4px;">${esc(t('rejectHeading'))}</h2>
      <p style="font-size:12.5px;color:var(--ink-soft);margin:0;">${esc(t('rejectHint'))}</p>
    </div>
    <div class="kpi-row" style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;">
      <div class="kpi-card danger">
        <div class="lbl">${esc(t('rejectKpiTotal'))}</div>
        <div class="val">${rejected.length}</div>
        <div class="sub">${esc(tf('rejectKpiTotalSub',{n:getAllRecords().length}))}</div>
      </div>
      <div class="report-card" style="margin:0;">
        <h3 style="margin-top:0;">${esc(t('rejectByMarket'))}</h3>
        ${Object.keys(byMarket).length? barList(byMarket) : `<div class="empty-state">${esc(t('rejectNone'))}</div>`}
      </div>
      <div class="report-card" style="margin:0;">
        <h3 style="margin-top:0;">${esc(t('rejectByReason'))}</h3>
        ${Object.keys(byReason).length? barList(byReason) : `<div class="empty-state">${esc(t('rejectNone'))}</div>`}
      </div>
    </div>
    ${rejected.length===0 ? `<div class="empty-state"><h3>${esc(t('rejectNone'))}</h3></div>` : `
    <table class="data-table">
      <thead><tr>
        ${cols.map(c=>`<th>${esc(c.label)}</th>`).join('')}
      </tr></thead>
      <tbody>
        ${rejected.map(r=>`<tr data-id="${esc(r.id)}" class="row-reject">
          <td class="mono">${esc(r.mgmtNo)}</td>
          <td class="pic-cell mono">${mqisInputHtml(r)}</td>
          <td class="mono">${esc(r.registeredDate)}</td>
          <td>${esc(r.plant)}</td>
          <td>${esc(r.project)}<div style="color:var(--ink-faint);font-size:11px;">${esc(r.model)}</div></td>
          <td class="mono">${esc(r.partCode)}</td>
          <td>${r.reason1?esc(r.reason1)+' <span style="color:var(--ink-faint)">('+esc(REASON_GLOSS[r.reason1]||'')+')</span>':'<span style="color:var(--ink-faint)">'+esc(t('notAnalyzed'))+'</span>'}</td>
          <td>${esc(r.occurPlace)}</td>
          <td class="pic-cell">${picInputHtml(r)}</td>
          <td class="pic-cell">${fileLinkCellHtml(r)}</td>
          <td class="pic-cell">${remarkInputHtml(r)}</td>
        </tr>`).join('')}
      </tbody>
    </table>`}
  `;
}

/* ============ Drawer (record detail / edit) ============ */
function renderDrawer(all){
  const overlay = document.getElementById('overlay');
  const drawer = document.getElementById('drawer');
  if(!state.drawerId){
    overlay.classList.remove('show'); drawer.classList.remove('show');
    drawer.innerHTML=''; return;
  }
  const r = all.find(x=>String(x.id)===String(state.drawerId));
  if(!r){ state.drawerId=null; overlay.classList.remove('show'); drawer.classList.remove('show'); return; }
  overlay.classList.add('show'); drawer.classList.add('show');
  const isNew = state.newRecords.some(x=>String(x.id)===String(r.id));
  const sm = statusMeta(r.status);
  const overdueTag = isOverdue(r) ? `<div class="stamp stamp-overdue">OVERDUE</div>` :
                     isCompletedStatus(r) ? `<div class="stamp stamp-complete">CLOSED</div>` : '';

  drawer.innerHTML = `
    <div class="drawer-head">
      <div>
        <h2>${esc(r.mgmtNo)}</h2>
        <p>${esc(r.plant)} &middot; registered ${esc(r.registeredDate)}</p>
      </div>
      ${overdueTag}
      <button class="drawer-close" id="drawerCloseBtn">&times;</button>
    </div>
    <div class="drawer-body">
      <div class="field full"><label>${esc(t('fTitle'))}</label><div class="v">${esc(r.title)}</div></div>
      <div class="field-grid">
        <div class="field"><label>${esc(t('fModelProject'))}</label><div class="v">${esc(r.project)}</div></div>
        <div class="field"><label>${esc(t('fBasicModel'))}</label><div class="v">${esc(r.model)}</div></div>
        <div class="field"><label>${esc(t('fPartGroup'))}</label><div class="v">${esc(r.partGroup)}</div></div>
        <div class="field"><label>${esc(t('fPartCode'))}</label><div class="v mono">${esc(r.partCode)}</div></div>
        <div class="field full"><label>${esc(t('fPartName'))}</label><div class="v">${esc(r.partName)}</div></div>
        <div class="field full"><label>${esc(t('fDefectDetails'))}</label><div class="v">${esc(r.defectDetails)}</div></div>
        <div class="field"><label>${esc(t('fOccurPlace'))}</label><div class="v">${esc(r.occurPlace)}</div></div>
        <div class="field"><label>${esc(t('fRootCause'))}</label><div class="v">${r.reason1?esc(r.reason1)+' — '+esc(REASON_GLOSS[r.reason1]||''):esc(t('fNotYetAnalyzed'))}</div></div>
        <div class="field full"><label>${esc(t('fRootCauseDetail'))}</label><div class="v">${esc(r.reason2)||'—'}</div></div>
        <div class="field"><label>${esc(t('fSampleQty'))}</label><div class="v mono">${r.sampleQty??'—'}</div></div>
        <div class="field"><label>${esc(t('fDefectQty'))}</label><div class="v mono">${r.defectQty??'—'}</div></div>
        <div class="field"><label>${esc(t('fInspector'))}</label><div class="v">${esc(r.inspector)||'—'}</div></div>
        <div class="field"><label>${esc(t('fApprover'))}</label><div class="v">${esc(r.approver)||'—'}</div></div>
      </div>

      <div class="section-title">${esc(t('caTracking'))}</div>
      <div class="field-grid">
        <div class="field">
          <label>${esc(t('fStatus'))}</label>
          <select id="editStatus">
            ${STATUS_OPTIONS.map(s=>`<option value="${esc(s)}" ${r.status===s?'selected':''}>${esc(s)} — ${statusMeta(s).gloss}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>${esc(t('fDueDateFinal'))}</label>
          <input type="date" id="editDueDate" value="${esc(r.dueDate||'')}"/>
        </div>
        <div class="field">
          <label>${esc(t('fCompletedDate'))}</label>
          <input type="date" id="editCompletedDate" value="${esc(r.completedDate||'')}"/>
        </div>
        <div class="field">
          <label>${esc(t('fTat'))}</label>
          <div class="v mono">${r.tatDays ?? '—'}</div>
        </div>
        <div class="field">
          <label>${esc(t('colMqis'))}</label>
          <input type="text" id="editMqisCode" value="${esc(r.mqisCode||'')}" placeholder="${esc(t('mqisPlaceholder'))}"/>
        </div>
        <div class="field">
          <label>${esc(t('colPic'))}</label>
          <input type="text" id="editPic" value="${esc(r.pic||'')}" placeholder="${esc(t('picPlaceholder'))}"/>
        </div>
        <div class="field full">
          <label>${esc(t('colFileLink'))}</label>
          <div style="display:flex;align-items:center;gap:6px;">
            <input type="text" id="editFileLink" style="flex:1;" value="${esc(r.caFileLink||'')}" placeholder="${esc(t('fileLinkPlaceholder'))}"/>
            ${resolveLocalPath(r.caFileLink) ? `<button type="button" class="file-copy-btn" data-copy-text="${esc(resolveLocalPath(r.caFileLink))}" title="${esc(tf('copyPathTooltip',{path:resolveLocalPath(r.caFileLink)}))}">⧉</button>` : ''}
            ${resolveOpenLink(r.caFileLink) ? `<a class="file-open-btn" href="${esc(resolveOpenLink(r.caFileLink))}" target="_blank" rel="noopener noreferrer" title="${esc(tf('openPathTooltip',{path:toFileUri(r.caFileLink)}))}">↗</a>` : ''}
          </div>
          ${r.caFileLink && state.localRoot && !/^([a-zA-Z]:[\\/]|\\\\|\/\/|\/|https?:|file:)/i.test(r.caFileLink.trim())
            ? `<div style="font-size:11px;color:var(--ink-faint);margin-top:2px;">${esc(tf('resolvesTo',{path:resolveLocalPath(r.caFileLink)}))}</div>`
            : ''}
        </div>
        <div class="field full">
          <label>${esc(t('colRemark'))}</label>
          <textarea id="editNotes" placeholder="${esc(t('remarkPlaceholder'))}">${esc(r.notes||'')}</textarea>
        </div>
      </div>
      <div class="drawer-actions">
        <button class="btn btn-primary" id="saveRecordBtn">${esc(t('saveChanges'))}</button>
        <button class="btn btn-line" id="closeDrawerBtn2">${esc(t('close'))}</button>
        ${isNew ? `<button class="btn btn-line" id="deleteRecordBtn" style="margin-left:auto;color:var(--orange);border-color:var(--orange);">${esc(t('removeEntry'))}</button>` : ''}
      </div>
    </div>
  `;
}

/* ============ New defect modal ============ */
function openNewDefectModal(){
  document.getElementById('modalOverlay').classList.add('show');
  const modal = document.getElementById('newDefectModal');
  modal.classList.add('show');
  modal.innerHTML = `
    <div class="modal-head"><h2>${esc(t('registerNewDefect'))}</h2><button class="drawer-close" id="modalCloseBtn">&times;</button></div>
    <div class="modal-body">
      <div class="field-grid">
        <div class="field"><label>${esc(t('mgmtNumber'))}</label><input id="nMgmtNo" type="text" placeholder="${esc(t('mgmtNumberPlaceholder'))}"/></div>
        <div class="field"><label>${esc(t('registeredDate'))}</label><input id="nDate" type="date" value="${todayStr()}"/></div>
        <div class="field"><label>${esc(t('plant'))}</label><input id="nPlant" type="text" placeholder="${esc(t('plantPlaceholder'))}"/></div>
        <div class="field"><label>${esc(t('modelProject'))}</label><input id="nProject" type="text" placeholder="${esc(t('modelProjectPlaceholder'))}"/></div>
        <div class="field"><label>${esc(t('fBasicModel'))}</label><input id="nModel" type="text"/></div>
        <div class="field"><label>${esc(t('partGroup'))}</label><input id="nPartGroup" type="text" placeholder="${esc(t('partGroupPlaceholder'))}"/></div>
        <div class="field"><label>${esc(t('fPartCode'))}</label><input id="nPartCode" type="text"/></div>
        <div class="field"><label>${esc(t('fPartName'))}</label><input id="nPartName" type="text"/></div>
        <div class="field full"><label>${esc(t('fTitle'))}</label><input id="nTitle" type="text" placeholder="${esc(t('titlePlaceholder'))}"/></div>
        <div class="field full"><label>${esc(t('fDefectDetails'))}</label><textarea id="nDetails" placeholder="${esc(t('detailsPlaceholder'))}"></textarea></div>
        <div class="field"><label>${esc(t('occurPlace'))}</label><input id="nOccur" type="text" placeholder="${esc(t('occurPlaceholder'))}"/></div>
        <div class="field">
          <label>${esc(t('reason1'))}</label>
          <select id="nReason1"><option value="">${esc(t('fNotYetAnalyzed'))}</option>${REASON_OPTIONS.map(r=>`<option value="${esc(r)}">${esc(r)} — ${REASON_GLOSS[r]}</option>`).join('')}</select>
        </div>
        <div class="field"><label>${esc(t('fSampleQty'))}</label><input id="nSampleQty" type="number" min="0"/></div>
        <div class="field"><label>${esc(t('fDefectQty'))}</label><input id="nDefectQty" type="number" min="0"/></div>
        <div class="field"><label>${esc(t('fInspector'))}</label><input id="nInspector" type="text"/></div>
        <div class="field">
          <label>${esc(t('status'))}</label>
          <select id="nStatus">${STATUS_OPTIONS.map(s=>`<option value="${esc(s)}" ${s==='Đợi đối sách'?'selected':''}>${esc(s)}</option>`).join('')}</select>
        </div>
        <div class="field"><label>${esc(t('colDueDate'))}</label><input id="nDueDate" type="date"/></div>
      </div>
      <div class="modal-actions">
        <button class="btn btn-line" id="cancelNewBtn">${esc(t('cancel'))}</button>
        <button class="btn btn-primary" id="submitNewBtn">${esc(t('addDefectRecord'))}</button>
      </div>
    </div>
  `;
}
function closeNewDefectModal(){
  document.getElementById('modalOverlay').classList.remove('show');
  document.getElementById('newDefectModal').classList.remove('show');
}

/* ============ Import results modal ============ */
function renderImportLogHistory(){
  if(!state.importLog.length) return `<p style="color:var(--ink-faint);font-size:12.5px;">${esc(t('noPreviousImports'))}</p>`;
  return state.importLog.slice(0,8).map(log=>{
    const when = new Date(log.importedAt);
    const whenStr = isNaN(when.getTime()) ? log.importedAt : when.toLocaleString();
    const fileLines = log.files.map(f=>{
      if(f.error) return `<div style="color:var(--orange);">${esc(f.fileName)} \u2014 ${esc(t('failedImport'))}: ${esc(f.error)}</div>`;
      return `<div>${esc(f.fileName)} \u2014 ${esc(tf('historyLineV2',{added:f.added, updated:f.updated, unchanged:f.unchanged, total:f.total}))}</div>`;
    }).join('');
    return `<div style="border-bottom:1px dashed var(--line);padding:8px 0;font-size:12px;">
      <div class="mono" style="color:var(--ink-faint);margin-bottom:3px;">${esc(whenStr)}</div>
      ${fileLines}
    </div>`;
  }).join('');
}

function openImportModal(){
  document.getElementById('modalOverlay').classList.add('show');
  const modal = document.getElementById('newDefectModal');
  modal.classList.add('show');
  modal.innerHTML = `
    <div class="modal-head"><h2>${esc(t('addDailyFile'))}</h2><button class="drawer-close" id="modalCloseBtn">&times;</button></div>
    <div class="modal-body">
      <p style="font-size:12.5px;color:var(--ink-soft);margin-top:0;">
        ${esc(t('importIntroV2'))}
      </p>
      <div id="importDropZone" style="border:2px dashed var(--line-strong);border-radius:10px;padding:26px;text-align:center;cursor:pointer;background:var(--panel);">
        <div style="font-size:13px;font-weight:600;margin-bottom:4px;">${esc(t('clickToChoose'))}</div>
        <div style="font-size:11.5px;color:var(--ink-faint);">${esc(t('orDragDrop'))}</div>
      </div>
      <div id="importStatus" style="margin-top:14px;"></div>
      <p style="font-size:11.5px;color:var(--ink-faint);margin:14px 0 0;">${esc(t('localStorageHint'))}</p>
      <div class="section-title">${esc(t('localRootLabel'))}</div>
      <p style="font-size:11.5px;color:var(--ink-faint);margin:0 0 8px;">${esc(t('localRootHint'))}</p>
      <div style="display:flex;align-items:center;gap:8px;">
        <input type="text" id="localRootInput" style="flex:1;" value="${esc(state.localRoot||'')}" placeholder="${esc(t('localRootPlaceholder'))}"/>
        <button class="btn btn-line" id="saveRootBtn">${esc(t('saveRootBtn'))}</button>
      </div>
      <div id="localRootSavedMsg" style="font-size:11.5px;color:var(--green);margin-top:6px;height:14px;"></div>

      <div class="section-title">${esc(t('nativeOpenLabel'))}</div>
      <p style="font-size:11.5px;color:var(--ink-faint);margin:0 0 8px;">${esc(t('nativeOpenHint'))}</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
        <button class="btn btn-line" id="downloadSetupBtn">${esc(t('downloadSetupBtn'))}</button>
        <button class="btn btn-line" id="downloadRemoveBtn">${esc(t('downloadRemoveBtn'))}</button>
      </div>
      <p style="font-size:11.5px;color:var(--ink-faint);margin:0 0 8px;">${esc(t('nativeOpenStep2'))}</p>
      <label style="display:flex;align-items:center;gap:8px;font-size:12.5px;cursor:pointer;">
        <input type="checkbox" id="nativeOpenToggle" ${state.useNativeOpen?'checked':''}/>
        ${esc(t('nativeOpenToggleLabel'))}
      </label>

      <div class="section-title">${esc(t('importHistory'))}</div>
      <div id="importHistory">${renderImportLogHistory()}</div>
      <div class="modal-actions" style="justify-content:space-between;">
        <button class="btn btn-line" id="clearLocalDataBtn" style="color:var(--red);border-color:var(--red-bg);">${esc(t('clearLocalData'))}</button>
        <button class="btn btn-line" id="cancelNewBtn">${esc(t('close'))}</button>
      </div>
    </div>
  `;
}

function collectNewRecord(){
  const val = id => document.getElementById(id).value.trim();
  const id = 'n'+Date.now()+Math.floor(Math.random()*1000);
  return {
    id, no:'', mgmtNo: val('nMgmtNo')||('NEW-'+id.slice(-6)),
    registeredDate: val('nDate')||todayStr(),
    writtenBy:'', status: val('nStatus'), plant: val('nPlant'),
    title: val('nTitle')||'(untitled defect)', occurPlace: val('nOccur'),
    supplier:'', vendorGroup:'', partCode: val('nPartCode'), partName: val('nPartName'),
    partGroup: val('nPartGroup'), project: val('nProject'), model: val('nModel'),
    defectDetails: val('nDetails'),
    sampleQty: val('nSampleQty')? Number(val('nSampleQty')) : null,
    defectQty: val('nDefectQty')? Number(val('nDefectQty')) : null,
    defectRate: null, reason1: val('nReason1')||null, reason2:null,
    inspector: val('nInspector'), approver:null, approvalDate:null,
    issueYN:null, claimYN:null, reoccur3M:null,
    dueDate: val('nDueDate')||null, completedDate:null, tatDays:null, tatCompliance:null,
    transactionType:null, locatedCorp: val('nPlant'),
  };
}

/* ============ File import (Add File) ============ */
// Header aliases: source exports (like the original Excel) use verbose /
// Korean-mixed column names. Map every alias we might see onto our schema.
const IMPORT_HEADER_MAP = {
  'no':'no', 'management number':'mgmtNo', 'registered date':'registeredDate',
  'mqis code':'mqisCode', 'mqis no':'mqisCode', 'mqis number':'mqisCode', 'mqis':'mqisCode',
  'written by':'writtenBy', 'approval▼':'status', 'approval':'status', 'status':'status',
  'plant':'plant', 'title':'title', 'occur place':'occurPlace',
  'supplier':'supplier', 'v/code':'vCode', 'vendor_g':'vendorGroup', 'vendor_s':'vendorSub',
  'part code':'partCode', 'part name':'partName', 'part group':'partGroup',
  'main category':'mainCategory', 'project':'project', 'basic model':'model',
  'defect details':'defectDetails', "sample q'ty":'sampleQty', "sample q\u2019ty":'sampleQty',
  "defect q'ty":'defectQty', "defect q\u2019ty":'defectQty', 'defect rate(%)':'defectRate',
  'reason1':'reason1', 'reason2':'reason2', 'inspector':'inspector', 'audit date':'auditDate',
  'approver':'approver', 'approval date':'approvalDate', 'issue \uc0ac\uc720':'issueReason',
  'issue y/n':'issueYN', 'parts problem':'partsProblem', 'reoccur 3m':'reoccur3M',
  'system qtr':'systemQtr', 'claim y/n':'claimYN', 'input stop':'inputStop',
  'effectiveness verification':'effectivenessVerification',
  'reply expeced date for final countermeasure':'dueDate',
  'reply expected date for final countermeasure':'dueDate',
  'final countermeasure input date':'completedDate',
  'tat(day)':'tatDays', 'tat compliance':'tatCompliance',
  'transaction type':'transactionType', 'located corp':'locatedCorp',
  // --- Korean-header aliases used by the live TNP production export ---
  // (the sheet's actual column headers are Korean for most fields; only a
  // handful, like PLANT/Project/Basic Model, are already in English)
  "관리번호":'mgmtNo', // 관리번호 = management number
  "등록일":'registeredDate', // 등록일 = registered date
  "등록자":'writtenBy', // 등록자 = written by
  "승인단계":'status', // 승인단계 = approval stage
  "승인상태":'status', // 승인상태 = approval status (alternate wording used in some exports)
  "제목":'title', // 제목 = title
  "발생장소":'occurPlace', // 발생장소 = occurrence place
  "협력사":'supplier', // 협력사 = supplier
  "업체명":'supplier', // 업체명 = company/supplier name (alternate wording)
  "부품코드":'partCode', // 부품코드 = part code
  "부품명":'partName', // 부품명 = part name
  "부품군":'partGroup', // 부품군 = part group
  "대분류":'mainCategory', // 대분류 = main category
  "불량현상":'defectDetails', // 불량현상 = defect phenomenon/details
  "검사수":'sampleQty', // 검사수 = inspected qty
  "불량수":'defectQty', // 불량수 = defect qty
  "불량률(%)":'defectRate', // 불량률(%) = defect rate
  "불량율(%)":'defectRate', // 불량율(%) = defect rate (alternate spelling)
  "원인1(4m+1e)":'reason1', // 원인1(4M+1E) = reason1
  "원인1":'reason1', // 원인1 = reason1 (short form, no suffix)
  "원인2(발생원인)":'reason2', // 원인2(발생원인) = reason2
  "원인2":'reason2', // 원인2 = reason2 (short form, no suffix)
  "심사자":'inspector', // 심사자 = inspector
  "심사일":'auditDate', // 심사일 = audit date
  "승인자":'approver', // 승인자 = approver
  "승인일":'approvalDate', // 승인일 = approval date
  "부품문제":'partsProblem', // 부품문제 = parts problem
  "qtr 3개월내 재발":'reoccur3M', // QTR 3개월내 재발 = reoccur within 3 months
  "3개월내 재발생":'reoccur3M', // 3개월내 재발생 = reoccur within 3 months (alternate wording, no "QTR" prefix)
  "투입중지":'inputStop', // 투입중지 = input stop
  "유효성 검증":'effectivenessVerification', // 유효성 검증 = effectiveness verification
  "유효성검증":'effectivenessVerification', // 유효성검증 = effectiveness verification (no space)
  "최종대책회답예정일":'dueDate', // 최종대책회답예정일 = final countermeasure due date
  "최종대책입력일":'completedDate', // 최종대책입력일 = final countermeasure input date
  "tat(일)":'tatDays', // TAT(일) = TAT (days)
  "tat 준수":'tatCompliance', // TAT 준수 = TAT compliance
  "sqci/plm-no":'sqciPlmNo', // SQCI/PLM-NO = SQCI/PLM number
  "plm 대책":'plmCountermeasure', // PLM 대책 = PLM countermeasure
  "의뢰자/시료번호/비고":'sourceRemarks', // 의뢰자/시료번호/비고 = requester/sample no./remarks (source system)
  "최초대책예정일":'initialDueDate', // 최초대책예정일 = initial countermeasure due date
  "최초 대책 입력일":'initialCompletedDate', // 최초 대책 입력일 = initial countermeasure input date
  "최초대책입력일":'initialCompletedDate', // 최초대책입력일 = initial countermeasure input date (no spaces)
  "최초tat 준수(y/n)":'initialTatCompliance', // 최초TAT 준수(Y/N) = initial TAT compliance (Y/N)
  "거래유형":'transactionType', // 거래유형 = transaction type
  "업체구분_승락일":'vendorApprovalDate', // 업체구분_승락일 = vendor classification approval date
  "권역법인":'locatedCorp', // 권역법인 = regional corp entity
  "사용멤버":'usedMember', // 사용멤버 = used member
};
function normHeader(h){ return String(h||'').trim().toLowerCase().replace(/\s+/g,' '); }
function excelDateToStr(v){
  if(v===null||v===undefined||v==='') return null;
  if(v instanceof Date) return v.toISOString().slice(0,10);
  if(typeof v==='number'){
    const d = new Date(Math.round((v-25569)*86400*1000));
    if(!isNaN(d.getTime())) return d.toISOString().slice(0,10);
  }
  const s = String(v).trim();
  const m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if(m) return `${m[1]}-${String(m[2]).padStart(2,'0')}-${String(m[3]).padStart(2,'0')}`;
  const d2 = new Date(s);
  if(!isNaN(d2.getTime())) return d2.toISOString().slice(0,10);
  return s;
}
function rowsToRecords(headerRow, dataRows){
  const cols = headerRow.map(h=>IMPORT_HEADER_MAP[normHeader(h)] || null);
  return dataRows.filter(r=>r.some(c=>c!==null && c!=='' && c!==undefined)).map(r=>{
    const rec = {};
    cols.forEach((key,i)=>{ if(key) rec[key] = r[i]; });
    ['registeredDate','dueDate','completedDate','approvalDate','auditDate'].forEach(f=>{
      if(rec[f]!==undefined) rec[f] = excelDateToStr(rec[f]);
    });
    ['sampleQty','defectQty'].forEach(f=>{
      if(rec[f]!==undefined && rec[f]!==null && rec[f]!=='') rec[f] = Number(rec[f]);
    });
    rec.id = 'i'+Date.now()+Math.floor(Math.random()*100000)+Math.floor(Math.random()*100000);
    return rec;
  });
}
// Lightweight CSV parser (handles quoted fields, escaped quotes, and CRLF/LF).
// Used for .csv files so they never depend on the XLSX library at all --
// this keeps the most common "daily export" import path working even in the
// rare case a browser blocks the bundled script from executing.
function parseCSVText(text){
  const rows = [];
  let row = [], field = '', inQuotes = false;
  for(let i=0;i<text.length;i++){
    const c = text[i];
    if(inQuotes){
      if(c==='"'){
        if(text[i+1]==='"'){ field+='"'; i++; }
        else inQuotes = false;
      } else field += c;
    } else {
      if(c==='"') inQuotes = true;
      else if(c===','){ row.push(field); field=''; }
      else if(c==='\r'){ /* skip, \n handles the line break */ }
      else if(c==='\n'){ row.push(field); rows.push(row); row=[]; field=''; }
      else field += c;
    }
  }
  if(field!=='' || row.length){ row.push(field); rows.push(row); }
  return rows;
}
function findHeaderRowIdx(grid){
  for(let i=0;i<Math.min(grid.length,10);i++){
    const hits = (grid[i]||[]).filter(c=>IMPORT_HEADER_MAP[normHeader(c)]).length;
    if(hits>=3) return i;
  }
  return -1;
}
// Some exports ship a corrupted <dimension> tag that understates the sheet's
// real size (e.g. claiming "A1:AX1" when data actually runs to row 218).
// SheetJS trusts that declared range by default and would silently truncate
// everything outside it. We recompute the true range directly from the
// worksheet's actual cell addresses so nothing gets lost.
function fixSheetRange(sheet){
  let minRow=Infinity, minCol=Infinity, maxRow=-1, maxCol=-1;
  for(const key in sheet){
    if(key[0]==='!') continue;
    let addr;
    try{ addr = XLSX.utils.decode_cell(key); } catch(e){ continue; }
    if(addr.r<minRow) minRow=addr.r;
    if(addr.c<minCol) minCol=addr.c;
    if(addr.r>maxRow) maxRow=addr.r;
    if(addr.c>maxCol) maxCol=addr.c;
  }
  if(maxRow>=0 && maxCol>=0){
    sheet['!ref'] = XLSX.utils.encode_range({s:{r:minRow,c:minCol}, e:{r:maxRow,c:maxCol}});
  }
}
async function parseWorkbookFile(file){
  const isCsv = /\.csv$/i.test(file.name);
  let fullGrid;
  if(isCsv){
    const text = (await file.text()).replace(/^\uFEFF/, '');
    fullGrid = parseCSVText(text);
  } else {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, {type:'array', cellDates:true});
    const sheet = wb.Sheets[wb.SheetNames[0]];
    fixSheetRange(sheet);
    fullGrid = XLSX.utils.sheet_to_json(sheet, {header:1, defval:null, raw:true});
  }
  // Row 1 of the current export template is a blank spacer row and is always
  // ignored -- real content (the header row, then the data rows) starts from
  // Row 2. We still fall back to scanning the untouched grid (including Row 1)
  // if that doesn't turn up a header, so older exports that put the header
  // directly on Row 1 keep working too.
  const trimmedGrid = fullGrid.slice(1);
  let grid = trimmedGrid;
  let headerIdx = findHeaderRowIdx(trimmedGrid);
  if(headerIdx===-1){
    grid = fullGrid;
    headerIdx = findHeaderRowIdx(fullGrid);
  }
  if(headerIdx===-1) throw new Error('Could not find a recognizable header row in "'+file.name+'".');
  const headerRow = grid[headerIdx];
  const dataRows = grid.slice(headerIdx+1);
  return rowsToRecords(headerRow, dataRows);
}

// Builds a lookup from fingerprint -> a reference telling us WHERE that record
// currently lives, so an incoming import row can update it in place:
//  - {kind:'base', id}   -> a seed record from BASE_DATA; updates are stored as
//                           an override patch (BASE_DATA itself is never mutated)
//  - {kind:'new', idx}   -> a record already living in state.newRecords; updated
//                           directly in that array
function buildRecordIndex(){
  const idx = new Map();
  BASE_DATA.forEach(r=>{
    const o = state.overrides[r.id];
    const merged = o ? Object.assign({}, r, o) : r;
    idx.set(recordFingerprint(merged), {kind:'base', id:r.id});
  });
  state.newRecords.forEach((r,i)=>{
    idx.set(recordFingerprint(r), {kind:'new', idx:i});
  });
  return idx;
}
function getRecordByRef(ref){
  if(ref.kind==='base'){
    const base = BASE_DATA.find(r=>r.id===ref.id);
    const o = state.overrides[ref.id];
    return o ? Object.assign({}, base, o) : base;
  }
  return state.newRecords[ref.idx];
}
// Applies every field present on the freshly-imported row onto the existing
// record (status, due date, completed date, TAT fields, etc. all get synced
// to the latest snapshot from the file). Fields that only exist locally --
// like manual follow-up notes added via the drawer -- are never present on
// an imported row, so a plain key-by-key merge leaves them untouched.
// Returns true if any field's value actually changed (vs. was just re-confirmed).
function applyUpdateByRef(ref, importedRec){
  const existing = getRecordByRef(ref);
  const patch = {};
  let changed = false;
  Object.keys(importedRec).forEach(k=>{
    if(k==='id') return; // never reassign identity
    patch[k] = importedRec[k];
    const before = existing ? existing[k] : undefined;
    if(String(before ?? '') !== String(importedRec[k] ?? '')) changed = true;
  });
  if(ref.kind==='base'){
    state.overrides[ref.id] = Object.assign({}, state.overrides[ref.id]||{}, patch);
  } else {
    state.newRecords[ref.idx] = Object.assign({}, state.newRecords[ref.idx], patch);
  }
  return changed;
}

async function importFiles(fileList){
  const recordIndex = buildRecordIndex();
  let added = 0, updated = 0, unchanged = 0, total = 0;
  const summaries = [];
  for(const file of fileList){
    let recs = [];
    try{ recs = await parseWorkbookFile(file); }
    catch(err){ summaries.push({fileName:file.name, error: err.message||String(err)}); continue; }
    let fAdded=0, fUpdated=0, fUnchanged=0;
    recs.forEach(rec=>{
      total++;
      const fp = recordFingerprint(rec);
      const match = recordIndex.get(fp);
      if(match){
        // Existing defect (whether from the seed data or a previous import):
        // sync it to the latest status/due-date/etc. from this file instead
        // of creating a second copy. Covers same-fingerprint rows appearing
        // more than once within this batch too (last row in the file wins).
        const didChange = applyUpdateByRef(match, rec);
        if(didChange){ updated++; fUpdated++; } else { unchanged++; fUnchanged++; }
      } else {
        state.newRecords.push(rec);
        const newRef = {kind:'new', idx: state.newRecords.length-1};
        recordIndex.set(fp, newRef);
        added++; fAdded++;
      }
    });
    summaries.push({fileName:file.name, added:fAdded, updated:fUpdated, unchanged:fUnchanged, total:recs.length});
  }
  state.importLog.unshift({
    id:'log'+Date.now(), importedAt:new Date().toISOString(),
    files: summaries, added, updated, unchanged, total
  });
  persistOverrides();
  persistNewRecords();
  persistImportLog();
  return {added, updated, unchanged, total, summaries};
}

/* ============ CSV export ============ */
function exportCSV(){
  const all = getAllRecords();
  const filtered = sortRecords(applyFilters(all));
  const cols = ['mgmtNo','mqisCode','registeredDate','plant','project','model','partGroup','partCode','partName',
    'occurPlace','reason1','reason2','title','defectDetails','sampleQty','defectQty','status','dueDate','completedDate','tatDays','inspector','approver','pic','caFileLink','notes'];
  const header = cols.join(',');
  const rows = filtered.map(r=> cols.map(c=>{
    let v = r[c]; if(v===null||v===undefined) v='';
    v = String(v).replace(/"/g,'""');
    return /[",\n]/.test(v) ? `"${v}"` : v;
  }).join(','));
  const csv = [header].concat(rows).join('\n');
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'tnp_defects_export_'+todayStr()+'.csv';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}


/* ============ Event wiring (delegation) ============ */
function wireEvents(){
  const app = document.getElementById('app');

  app.addEventListener('click', async (e)=>{
    if(e.target.classList && e.target.classList.contains('inline-edit-input')) return;
    if(e.target.closest && e.target.closest('.file-open-btn')) return;
    const copyBtn = e.target.closest && e.target.closest('.file-copy-btn');
    if(copyBtn){
      const text = copyBtn.dataset.copyText;
      const original = copyBtn.textContent;
      copyTextToClipboard(text).then(ok=>{
        copyBtn.textContent = ok ? '✓' : '✕';
        copyBtn.classList.add(ok ? 'copy-success' : 'copy-fail');
        copyBtn.title = ok ? t('copiedFeedback') : t('copyFailedFeedback');
        setTimeout(()=>{
          copyBtn.textContent = original;
          copyBtn.classList.remove('copy-success','copy-fail');
          copyBtn.title = tf('copyPathTooltip',{path:text});
        }, 1400);
      });
      return;
    }
    const marketCard = e.target.closest('.market-card[data-market]');
    if(marketCard){ openMarket(marketCard.dataset.market); return; }
    if(e.target.id==='goHomeBtn' || e.target.closest('#brandLogo')){ goHome(); return; }
    if(e.target.id==='homeRejectViewAllBtn'){
      state.view = 'dashboard';
      state.filters = freshFilters();
      state.activeTab = 'reject';
      render();
      return;
    }

    const tabBtn = e.target.closest('[data-tab]');
    if(tabBtn){ state.activeTab = tabBtn.dataset.tab; render(); return; }

    if(e.target.id==='newDefectBtn'){ openNewDefectModal(); return; }
    if(e.target.id==='addFileBtn'){ openImportModal(); return; }
    if(e.target.id==='clearLocalDataBtn'){
      if(window.confirm(t('clearLocalDataConfirm'))){
        const ok = await clearLocalData();
        openImportModal();
        render();
        if(!ok) window.alert(t('clearLocalDataFailed'));
      }
      return;
    }
    if(e.target.id==='saveRootBtn'){
      const input = document.getElementById('localRootInput');
      state.localRoot = input.value.trim();
      persistLocalRoot();
      const msg = document.getElementById('localRootSavedMsg');
      if(msg) msg.textContent = t('localRootSaved');
      render();
      return;
    }
    if(e.target.id==='downloadSetupBtn'){ downloadNativeOpenSetupScript(); return; }
    if(e.target.id==='downloadRemoveBtn'){ downloadNativeOpenRemoveScript(); return; }
    if(e.target.id==='exportBtn'){ exportCSV(); return; }
    if(e.target.closest && e.target.closest('#importDropZone')){ document.getElementById('fileInput').click(); return; }
    const langBtn = e.target.closest('[data-lang]');
    if(langBtn){
      const code = langBtn.dataset.lang;
      if(I18N[code] && state.lang!==code){ state.lang = code; persistLang(); render(); }
      return;
    }
    if(e.target.id==='clearFiltersBtn'){
      state.filters = freshFilters();
      render(); return;
    }

    const th = e.target.closest('th[data-sort]');
    if(th){
      const key = th.dataset.sort;
      if(state.sortKey===key) state.sortDir = state.sortDir==='asc'?'desc':'asc';
      else { state.sortKey = key; state.sortDir='asc'; }
      render(); return;
    }

    const tr = e.target.closest('tr[data-id]');
    if(tr){ state.drawerId = tr.dataset.id; render(); return; }
    const caRow = e.target.closest('.ca-row[data-id]');
    if(caRow){ state.drawerId = caRow.dataset.id; render(); return; }

    if(e.target.id==='drawerCloseBtn' || e.target.id==='closeDrawerBtn2' || e.target.classList.contains('overlay')){
      state.drawerId = null; render(); return;
    }
    if(e.target.id==='saveRecordBtn'){
      const patch = {
        status: document.getElementById('editStatus').value,
        dueDate: document.getElementById('editDueDate').value || null,
        completedDate: document.getElementById('editCompletedDate').value || null,
        notes: document.getElementById('editNotes').value,
        pic: document.getElementById('editPic').value || null,
        caFileLink: document.getElementById('editFileLink').value || null,
        mqisCode: document.getElementById('editMqisCode').value || null,
      };
      updateRecordField(state.drawerId, patch);
      render(); return;
    }
    if(e.target.id==='deleteRecordBtn'){
      const idStr = String(state.drawerId);
      state.newRecords = state.newRecords.filter(x=>String(x.id)!==idStr);
      persistNewRecords();
      state.drawerId = null; render(); return;
    }

    if(e.target.id==='modalCloseBtn' || e.target.id==='cancelNewBtn' || e.target.classList.contains('modal-overlay')){
      closeNewDefectModal(); return;
    }
    if(e.target.id==='submitNewBtn'){
      const rec = collectNewRecord();
      state.newRecords.push(rec);
      persistNewRecords();
      closeNewDefectModal();
      render(); return;
    }
  });

  app.addEventListener('input', (e)=>{
    if(e.target.id==='searchInput'){ state.filters.search = e.target.value; render(); return; }
    if(e.target.id==='dateFrom'){ state.filters.dateFrom = e.target.value; render(); return; }
    if(e.target.id==='dateTo'){ state.filters.dateTo = e.target.value; render(); return; }
    const cb = e.target.closest('input[data-filter]');
    if(cb){
      const set = state.filters[cb.dataset.filter];
      if(cb.checked) set.add(cb.value); else set.delete(cb.value);
      render(); return;
    }
  });

  app.addEventListener('change', (e)=>{
    if(e.target.classList && e.target.classList.contains('inline-edit-input')){
      const field = e.target.dataset.field;
      updateRecordField(e.target.dataset.id, {[field]: e.target.value || null});
      render(); return;
    }
    if(e.target.id==='fileInput'){
      const files = Array.from(e.target.files||[]);
      if(files.length) handleImportFiles(files);
      e.target.value = '';
      return;
    }
    if(e.target.id==='nativeOpenToggle'){
      state.useNativeOpen = e.target.checked;
      persistUseNativeOpen();
      render();
      return;
    }
  });

  app.addEventListener('keydown', (e)=>{
    if(e.key==='Enter' && e.target.classList && e.target.classList.contains('inline-edit-input')){
      e.preventDefault();
      e.target.blur();
    }
    if(e.key==='Enter' && e.target.id==='localRootInput'){
      e.preventDefault();
      document.getElementById('saveRootBtn').click();
    }
  });

  // Drag-and-drop onto the drop zone (delegated via dragover/drop on the app root).
  app.addEventListener('dragover', (e)=>{
    if(e.target.closest && e.target.closest('#importDropZone')) e.preventDefault();
  });
  app.addEventListener('drop', (e)=>{
    const zone = e.target.closest && e.target.closest('#importDropZone');
    if(!zone) return;
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files||[]);
    if(files.length) handleImportFiles(files);
  });
}

async function handleImportFiles(files){
  const statusEl = document.getElementById('importStatus');
  if(statusEl) statusEl.innerHTML = `<p class="mono" style="font-size:12px;color:var(--ink-soft);">${esc(tf('readingFiles',{n:files.length}))}</p>`;
  let result;
  try{
    result = await importFiles(files);
  }catch(err){
    if(statusEl) statusEl.innerHTML = `<p style="color:var(--orange);font-size:12.5px;">${esc(t('importFailed'))} ${esc(err.message||String(err))}</p>`;
    return;
  }
  if(statusEl){
    const failed = result.summaries.filter(s=>s.error);
    statusEl.innerHTML = `
      <div style="background:var(--green-bg);border:1px solid var(--green);border-radius:8px;padding:10px 12px;font-size:12.5px;color:var(--green);">
        ${esc(tf('importResultLine',{added:result.added, updated:result.updated, unchanged:result.unchanged, total:result.total}))}
      </div>
      ${failed.length ? `<div style="margin-top:8px;color:var(--orange);font-size:12px;">${failed.map(f=>esc(f.fileName)+': '+esc(f.error)).join('<br/>')}</div>` : ''}
    `;
  }
  const historyEl = document.getElementById('importHistory');
  if(historyEl) historyEl.innerHTML = renderImportLogHistory();
  render();
}

/* ============ Init ============ */
async function init(){
  await loadFromLocalStorage();
  document.getElementById('app').innerHTML = `
    <div class="topbar" id="topbar"></div>
    <div class="body-shell">
      <div class="home-view" id="homeView"></div>
      <div class="sidebar" id="sidebar"></div>
      <div class="main">
        <div class="kpi-row" id="kpiRow"></div>
        <div class="tabs" id="tabs"></div>
        <div class="tab-panel" id="tabPanel"></div>
      </div>
    </div>
    <div class="overlay" id="overlay"></div>
    <div class="drawer" id="drawer"></div>
    <div class="overlay" id="modalOverlay"></div>
    <div class="modal" id="newDefectModal"></div>
  `;
  wireEvents();
  render();
}
init();

